﻿using System;

using System.Collections;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

using System.Runtime.InteropServices;

//using TwainLib;
using GdiPlusLib;
using PdfSharp.Pdf;
using PdfSharp.Drawing;

namespace TwainLib
{
    partial class Twain
    {
        //public bool PreFilterMessage(ref Message m)
        public bool FilterMessage(ref Message m)
        {
            //TwEvent eventMessage;
            Twain.WINMSG winMessage;

            //TwainCommand cmd = tw.PassMessage(ref m);
            //if (cmd == TwainCommand.Not)
            //    return false;

            if (Twain.DataSource.Id == IntPtr.Zero)
                return false;

            int pos = Twain.GetMessagePos();

            winMessage.hwnd = m.HWnd;
            winMessage.message = m.Msg;
            winMessage.wParam = m.WParam;
            winMessage.lParam = m.LParam;
            winMessage.time = Twain.GetMessageTime();
            winMessage.x = (short)pos;
            winMessage.y = (short)(pos >> 16);

            _eventMessage.EventPtr = Marshal.AllocHGlobal(Marshal.SizeOf(winMessage));
            
            Marshal.StructureToPtr(winMessage, _eventMessage.EventPtr, false);
            _eventMessage.Message = 0;
            TwRC rc = Twain.DSevent(Twain.ApplicationId, Twain.DataSource, TwDG.Control, TwDAT.Event, TwMSG.ProcessEvent, ref _eventMessage);

            if (rc == TwRC.NotDSEvent)
                return false;

            switch (_eventMessage.Message)
            {
                case (short)TwMSG.XFerReady:
                    _f.toolStripStatusLabelError.Text += System.Threading.Thread.CurrentThread.ManagedThreadId.ToString() + " filter message | ";

                    Exception exception = null;
                    ArrayList pics = null;
                    try
                    {
                        _f.GetQueue.Add(Tuple.Create<bool, Action>(true, () => TransferImages(out pics)));
                        //pics = TransferImages();
                        //TransferImageEventArgs args = new TransferImageEventArgs(pics);
                        //TransferImage(this, args);
                    }
                    catch (Exception e)
                    {
                        exception = e;
                    }
                    //CloseSrc();
                    break;

                case (short)TwMSG.CloseDS:
                case (short)TwMSG.CloseDSOK:
                case (short)TwMSG.CloseDSReq:
                    CloseSrc();
                    break;

                case (short)TwMSG.DeviceEvent:
                    break;

                default:
                    break;
            }

            return true;
        }


        public void TransferImages(out ArrayList pics)
        {
            _f.toolStripStatusLabelError.Text += System.Threading.Thread.CurrentThread.ManagedThreadId.ToString() + " transfer | ";

            pics = new ArrayList();
            if (Twain.DataSource.Id == IntPtr.Zero)
                return;

            TwRC rc;
            IntPtr hbitmap = IntPtr.Zero;
            TwPendingXfers pxfr = new TwPendingXfers();

            do
            {

                //TwSetUpFileXfer xfer = new TwSetUpFileXfer();
                //xfer.FileName = System.Text.Encoding.UTF8.GetBytes("c:\\temp\\doc.pdf");
                //xfer.Format = 10;       // TWFF_PDF 10
                //xfer.VrefNum = 0xffff;  // TWON_DONTCARE16
                //rc = DSxfer(appid, srcds, TwDG.Control, TwDAT.SetupFileXfer, TwMSG.Get, xfer);
                //if (rc != TwRC.Success)
                //{
                //    short retCode = HandleError();
                //    return pics;
                //}

                pxfr.Count = 0;
                hbitmap = IntPtr.Zero;

                TwImageInfo iinfo = new TwImageInfo();
                rc = Twain.DSiinf(Twain.ApplicationId, Twain.DataSource, TwDG.Image, TwDAT.ImageInfo, TwMSG.Get, iinfo);
                if (rc != TwRC.Success)
                {
                    //HandleError();
                    return;
                }

                //iinfo.ImageWidth = 100;
                //iinfo.ImageLength = 100;

                //rc = DSiinf(appid, srcds, TwDG.Image, TwDAT.ImageInfo, TwMSG.Set, iinfo);
                //if (rc != TwRC.Success)
                //{
                //    HandleError();
                //    return pics;
                //}

                rc = Twain.DSixfer(Twain.ApplicationId, Twain.DataSource, TwDG.Image, TwDAT.ImageNativeXfer, TwMSG.Get, ref hbitmap);
                if (rc != TwRC.XferDone)
                {
                    //HandleError();
                    return;
                }

                rc = Twain.DSpxfer(Twain.ApplicationId, Twain.DataSource, TwDG.Control, TwDAT.PendingXfers, TwMSG.EndXfer, pxfr);
                if (rc != TwRC.Success)
                {
                    CloseSrc();
                    return;
                }

                pics.Add(hbitmap);
            }
            while (pxfr.Count != 0);

            rc = Twain.DSpxfer(Twain.ApplicationId, Twain.DataSource, TwDG.Control, TwDAT.PendingXfers, TwMSG.Reset, pxfr);

            TransferImageEventArgs args = new TransferImageEventArgs(pics);
            TransferImage(this, args);

            CloseSrc();

            //return pics;
        }
/*
        public void CloseSrc()
        {
            EndingScan();

            TwRC rc;
            if (Twain.DataSource.Id != IntPtr.Zero)
            {
                TwUserInterface ui = new TwUserInterface();
                rc = Twain.DSuserif(Twain.ApplicationId, Twain.DataSource, TwDG.Control, TwDAT.UserInterface, TwMSG.DisableDS, ui);
                rc = Twain.DSMident(Twain.ApplicationId, IntPtr.Zero, TwDG.Control, TwDAT.Identity, TwMSG.CloseDS, Twain.DataSource);

                Twain.DataSource.Id = IntPtr.Zero;
            }
        }

        private void EndingScan()
        {
            //if (msgfilter)
            {
                Application.RemoveMessageFilter(this);
                //msgfilter = false;
                //this.Enabled = true;
                //this.Activate();
            }
        }
*/

/*
            switch (cmd)
            {
                case TwainCommand.CloseRequest:
                    {
                        EndingScan();
                        tw.CloseSrc();
                        break;
                    }
                case TwainCommand.CloseOk:
                    {
                        EndingScan();
                        tw.CloseSrc();
                        break;
                    }
                case TwainCommand.DeviceEvent:
                    {
                        break;
                    }
                case TwainCommand.TransferReady:
                    {
                        MemoryStream ms = null;
                        ArrayList pics = tw.TransferPictures();
                        EndingScan();
                        tw.CloseSrc();
                        //ArrayList pics = new ArrayList();

                        for (int i = 0; i < pics.Count; i++)
                        {
                            IntPtr imgPtr = (IntPtr)pics[i];
                            IntPtr bmpPtr = Gdip.GlobalLock(imgPtr);
                            IntPtr pixPtr = GetPixelInfo(bmpPtr);

                            Guid clsid;
                            //String strFileName = @"c:\" + Environment.MachineName + i.ToString() + DateTime.Now.Millisecond + ".jpg";
                            String inFileName = "temp.jpg";
                            if (Gdip.GetCodecClsid(inFileName, out clsid))
                            {
                                IntPtr imgPtr2 = IntPtr.Zero;
                                Gdip.GdipCreateBitmapFromGdiDib(bmpPtr, pixPtr, ref imgPtr2);

                                Gdip.GdipSaveImageToFile(imgPtr2, inFileName, ref clsid, IntPtr.Zero);

                                Gdip.GdipDisposeImage(imgPtr2);
                                Gdip.GlobalFree(imgPtr);
                                imgPtr = IntPtr.Zero;
                                imgPtr2 = IntPtr.Zero;

                                XImage ximg = XImage.FromFile(inFileName);
                                PdfDocument doc = new PdfDocument();
                                PdfPage page = new PdfPage();
                                page.Width = ximg.PixelWidth;
                                page.Height = ximg.PixelHeight;
                                doc.Pages.Add(page);
                                XGraphics xgr = XGraphics.FromPdfPage(doc.Pages[0]);

                                xgr.DrawImage(ximg, 0, 0);

                                ms = new MemoryStream();
                                doc.Save(ms, false);
                                byte[] buffer_pdf = ms.ToArray();

                                //var ms4 = new MemoryStream(buffer_pdf);
                                //PdfDocument doc4 = new PdfDocument();
                                //doc4 = PdfSharp.Pdf.IO.PdfReader.Open(ms4);
                                //doc4.Save("doc4.pdf");

                                //String outFileName = "temp.pdf";
                                //doc.Save(outFileName);
                                ximg.Dispose();
                                doc.Close();
                                ms.Close();
                                ms = null;

                                FileStream fs = new FileStream(inFileName, FileMode.Open, FileAccess.Read);
                                BinaryReader br = new BinaryReader(fs);
                                byte[] buffer = br.ReadBytes((int)fs.Length);

                                //fs.Close();
                                //fs = null;
                                //Image image = Image.FromFile(strFileName);
                                ms = new MemoryStream(buffer);
                                Image image = Image.FromStream(ms);
                                Image image2 = resizeImage(image, 480);

                                ms.Close();
                                ms = null;
                                ms = new MemoryStream();
                                image2.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                                byte[] buffer2 = ms.ToArray();

                                Form1.DbHelper db = new Form1.DbHelper();
                                try
                                {
                                    db.SaveAttachment(_mainForm.User, ref buffer_pdf, ref buffer2);
                                    Image img = Image.FromStream(fs);
                                    _mainForm.pictureBox1.Image = img;
                                    _mainForm.txtAttachmentTitle.Text = _mainForm.User.Title;
                                    _mainForm.txtAttachmentUser.Text = _mainForm.User.DisplayName;
                                    _mainForm.txtAttachmentDate.Text = DateTime.Now.ToString("dd/MM/yyyy");

                                    //pictureBox1.Image = image2;
                                }
                                catch (Exception ex)
                                {
                                    _mainForm.toolStripStatusLabelError.Text = ex.Message;
                                }
                                finally
                                {
                                    if (fs != null)
                                        fs.Close();
                                    if (ms != null)
                                        ms.Close();

                                    if (image != null)
                                        image.Dispose();
                                    if (image2 != null)
                                        image2.Dispose();

                                    File.Delete(inFileName);
                                }
                            }
                            else
                            {
                                //toolStripStatusLabelError.Text = "No codec found for the file: " + inFileName;
                                break;
                            }

                            //fs.Close();
                            //try
                            //{
                            //    //File.Delete(strFileName);
                            //}
                            //catch { }
                        }

                        //this.Enabled = true;
                        //_mainForm.Activate();
                        _mainForm.Cursor = Cursors.Default;
                        _mainForm.enableButtons(true);
                        _mainForm.stopProgressBar();

                        break;
                    }
            }

            return true;
        }
*/
/*
        private IntPtr GetPixelInfo(IntPtr bmpptr)
        {
            BITMAPINFOHEADER bmi;
            Rectangle bmprect = new Rectangle(0, 0, 0, 0);

            bmi = new BITMAPINFOHEADER();
            Marshal.PtrToStructure(bmpptr, bmi);

            bmprect.X = bmprect.Y = 0;
            bmprect.Width = bmi.biWidth;
            bmprect.Height = bmi.biHeight;

            if (bmi.biSizeImage == 0)
                bmi.biSizeImage = ((((bmi.biWidth * bmi.biBitCount) + 31) & ~31) >> 3) * bmi.biHeight;

            int p = bmi.biClrUsed;
            if ((p == 0) && (bmi.biBitCount <= 8))
                p = 1 << bmi.biBitCount;
            p = (p * 4) + bmi.biSize + (int)bmpptr;
            return (IntPtr)p;
        }

        //private static Image resizeImage(Image imgToResize, Size size)
        private static Image resizeImage(Image imgToResize, int height)
        {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;

            //float nPercent = 0;
            //float nPercentW = 0;
            //float nPercentH = 0;

            //nPercentW = ((float)size.Width / (float)sourceWidth);
            //nPercentH = ((float)size.Height / (float)sourceHeight);
            float nPercent = ((float)height / (float)sourceHeight);

            //if (nPercentH < nPercentW)
            //    nPercent = nPercentH;
            //else
            //    nPercent = nPercentW;

            int destWidth = (int)(sourceWidth * nPercent);
            int destHeight = (int)(sourceHeight * nPercent);

            Bitmap b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage((Image)b);
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();

            return (Image)b;
        }

        internal bool msgfilter;
        //internal Twain tw;
        internal IntPtr imgPtr = IntPtr.Zero;
        //private LinkLabel linkLabel1;

        [StructLayout(LayoutKind.Sequential, Pack = 2)]
        internal class BITMAPINFOHEADER
        {
            public int biSize;
            public int biWidth;
            public int biHeight;
            public short biPlanes;
            public short biBitCount;
            public int biCompression;
            public int biSizeImage;
            public int biXPelsPerMeter;
            public int biYPelsPerMeter;
            public int biClrUsed;
            public int biClrImportant;
        }
*/
    }
}
