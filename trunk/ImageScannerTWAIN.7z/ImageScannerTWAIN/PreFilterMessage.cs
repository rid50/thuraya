﻿using System;

using System.Collections;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

using System.Runtime.InteropServices;

//using TwainLib;
using GdiPlusLib;
using PdfSharp.Pdf;
using PdfSharp.Drawing;

namespace TwainLib
{
    partial class Twain
    {
        public ArrayList _pics = null;

        //public bool PreFilterMessage(ref Message m)
        public bool FilterMessage(ref Message m)
        {
            //TwEvent eventMessage;
            //Twain.WINMSG winMessage;

            //TwainCommand cmd = tw.PassMessage(ref m);
            //if (cmd == TwainCommand.Not)
            //    return false;

            if (Twain.DataSource.Id == IntPtr.Zero)
                return false;

            int pos = Twain.GetMessagePos();

            _winMessage.hwnd = m.HWnd;
            _winMessage.message = m.Msg;
            _winMessage.wParam = m.WParam;
            _winMessage.lParam = m.LParam;
            _winMessage.time = Twain.GetMessageTime();
            _winMessage.x = (short)pos;
            _winMessage.y = (short)(pos >> 16);

            //_eventMessage.EventPtr = Marshal.AllocHGlobal(Marshal.SizeOf(winMessage));
            
            Marshal.StructureToPtr(_winMessage, _eventMessage.EventPtr, false);
            _eventMessage.Message = 0;
            TwRC rc = Twain.DSevent(Twain.ApplicationId, Twain.DataSource, TwDG.Control, TwDAT.Event, TwMSG.ProcessEvent, ref _eventMessage);

            if (rc == TwRC.NotDSEvent)
                return false;

            switch (_eventMessage.Message)
            {
                case (short)TwMSG.XFerReady:
                    DisplayCurrentThreadId("message filter"); 

                    //ArrayList pics = null;

                    Exception exception = null;
                    try
                    {
                        MainForm.GetQueue.Add(Tuple.Create<bool, Action>(true, () => TransferImages(out _pics)));
                        //pics = TransferImages();
                        //TransferImageEventArgs args = new TransferImageEventArgs(pics);
                        //TransferImage(this, args);
                    }
                    catch (Exception e)
                    {
                        exception = e;
                    }
                    //CloseSrc();
                    break;

                case (short)TwMSG.CloseDS:
                case (short)TwMSG.CloseDSOK:
                case (short)TwMSG.CloseDSReq:
                    CloseSrc();
                    break;

                case (short)TwMSG.DeviceEvent:
                    break;

                default:
                    break;
            }

            return true;
        }


        public void TransferImages(out ArrayList pics)
        {
            bool error = false;
            DisplayCurrentThreadId("transfer");

            pics = new ArrayList();
            if (Twain.DataSource.Id == IntPtr.Zero)
                return;

            TwRC rc;
            IntPtr hbitmap = IntPtr.Zero;
            TwPendingXfers pendingTransfer = new TwPendingXfers();

            do
            {

                //TwSetUpFileXfer xfer = new TwSetUpFileXfer();
                //xfer.FileName = System.Text.Encoding.UTF8.GetBytes("c:\\temp\\doc.pdf");
                //xfer.Format = 10;       // TWFF_PDF 10
                //xfer.VrefNum = 0xffff;  // TWON_DONTCARE16
                //rc = DSxfer(appid, srcds, TwDG.Control, TwDAT.SetupFileXfer, TwMSG.Get, xfer);
                //if (rc != TwRC.Success)
                //{
                //    short retCode = HandleError();
                //    return pics;
                //}

                pendingTransfer.Count = 0;
                hbitmap = IntPtr.Zero;

                //TwImageInfo iinfo = new TwImageInfo();
                //rc = Twain.DSiinf(Twain.ApplicationId, Twain.DataSource, TwDG.Image, TwDAT.ImageInfo, TwMSG.Get, iinfo);
                //if (rc != TwRC.Success)
                //{
                //    error = true;
                //    break;
                //}

                rc = Twain.DSixfer(Twain.ApplicationId, Twain.DataSource, TwDG.Image, TwDAT.ImageNativeXfer, TwMSG.Get, ref hbitmap);
                if (rc != TwRC.XferDone)
                {
                    error = true;
                    break;
                }

                rc = Twain.DSpxfer(Twain.ApplicationId, Twain.DataSource, TwDG.Control, TwDAT.PendingXfers, TwMSG.EndXfer, pendingTransfer);
                if (rc != TwRC.Success)
                {
                    error = true;
                    break;
                }

                pics.Add(hbitmap);
            }
            while (pendingTransfer.Count != 0);

            TransferImageEventArgs args = new TransferImageEventArgs(pics, error);
            TransferImage(this, args);

            Twain.DSpxfer(Twain.ApplicationId, Twain.DataSource, TwDG.Control, TwDAT.PendingXfers, TwMSG.Reset, pendingTransfer);

            CloseSrc();
        }
    }
}
