using System;
using System.Data;
using System.Data.OleDb;
using System.Data.Common;

using System.Configuration;

using System.Data.SqlClient;
using Microsoft.HostIntegration.MsDb2Client;
using IBM.Data.DB2;

namespace ImageScanner
{
    public class DBUtils
    {
/*
        CREATE TABLE [T_STD_PHOTO_BASE] ([CIVL_ID] decimal (12,0) NOT NULL, 
                                [STD_ROWID] binary (40) NOT NULL, 
                                [STD_PHOTO_LOB] image NULL, 
                                [USER_ID] nvarchar (50) NULL, 
                                [CRTD_BY] nvarchar (50) NOT NULL, 
                                [CRTD_AT] smalldatetime NOT NULL, 
                                [MOD_BY] nvarchar (50) NULL, 
                                [MOD_AT] smalldatetime NULL )
*/

        internal void GetUserProfile(UserProfile user)
        {

            MsDb2Connection conn = null;
            MsDb2Command cmd = null;
            MsDb2DataReader reader = null;

            try
            {
                conn = new MsDb2Connection(getConnectionString("MSProviderToDB2"));
                conn.Open();

                cmd = new MsDb2Command();
                cmd.Connection = conn;

//            cmd.CommandText = "SELECT AD_Students.user_id, AD_Students.first_name, AD_Students.middle_name, AD_Students.third_name, AD_Students.last_name, AD_Institutes.name_a, AD_Major.name_a " + 
//                                "FROM (AD_Students INNER JOIN AD_Institutes ON AD_Students.inst_code = AD_Institutes.inst_code) INNER JOIN AD_Major ON (AD_Students.major_code = AD_Major.major_code) AND (AD_Students.inst_code = AD_Major.inst_code) " +
//                                "WHERE (((AD_Students.civil_id)=?))";
//            "WHERE (((AD_Students.civil_id)=287062301977))";


                cmd.CommandText = "SELECT T1.FRST_NAME, T1.SEC_NAME, T1.THRD_NAME, T1.LST_NAME, T3.INST_NAME, T4.MAJ_PRG_NAME, T1.CIVL_ID_REAL" +
                                " FROM T_PERSON AS T1, T_STDNT_MAJOR_REG AS T2, T_INSTITUTION AS T3, T_MAJOR_PROGRAM AS T4" +
                                " WHERE T1.CIVL_ID=T2.CIVL_ID AND T2.MP_INST_ID=T3.INST_ID AND T2.MP_INST_ID=T4.INST_ID AND T2.MAJ_PRG_ID=T4.MAJ_PRG_ID AND T2.EFF_SMSTR_ID=(SELECT MAX(T5.EFF_SMSTR_ID) FROM T_STDNT_MAJOR_REG T5 WHERE T5.CIVL_ID=T1.CIVL_ID) AND T1.CIVL_ID_REAL=?";
//282033000734

                cmd.Parameters.Add("@civil_id", MsDb2Type.Decimal);
                cmd.Parameters["@civil_id"].Value = user.CivilId;

                reader = cmd.ExecuteReader();
                reader.Read();

                if (reader.HasRows)
                {
//                    user.UserId = reader.GetString(0);
                    if (!reader.IsDBNull(0))
                        user.FirstName = reader.GetString(0);
                    if (!reader.IsDBNull(1))
                        user.SecondName = reader.GetString(1);
                    if (!reader.IsDBNull(2))
                        user.ThirdName = reader.GetString(2);
                    if (!reader.IsDBNull(3))
                        user.LastName = reader.GetString(3);
                    if (!reader.IsDBNull(4))
                        user.InstituteName = reader.GetString(4);
                    if (!reader.IsDBNull(5))
                        user.MajorName = reader.GetString(5);
                    user.Status = "ok";
                }
                else
                {
                    user.Status = "Not found";
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try
                {
                    if (reader != null)
                        reader.Close();

                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                    if (conn != null)
                        conn = null;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

        }

        internal byte[] GetUserPicture(Decimal civilId)
        {

            String connectionString = "IBMProviderToDB2";
//            String connectionString = "MSSQLServerProvider";

            String tableName;

            DbConnection conn = null;
            DbCommand cmd = null;

            if (connectionString == "IBMProviderToDB2")
            {
                tableName = "SRSD.T_STD_PHOTO_BASE";
                conn = new DB2Connection();
                cmd = new DB2Command();
                ((DB2Command)cmd).Parameters.Add("@civil_id", DB2Type.Decimal);
                cmd.Parameters["@civil_id"].Value = civilId;
                cmd.CommandText = "SELECT STD_PHOTO_LOB FROM " + tableName + " WHERE CIVL_ID=?";

            }
            else
            {
                tableName = "dbo.T_STD_PHOTO_BASE";
                conn = new SqlConnection();
                cmd = new SqlCommand();
                cmd.CommandText = "SELECT STD_PHOTO_LOB FROM " + tableName + " WHERE CIVL_ID=@civil_id";
                ((SqlCommand)cmd).Parameters.Add("@civil_id", SqlDbType.Decimal);
                cmd.Parameters["@civil_id"].Value = civilId;
            }

            String st = getConnectionString(connectionString);

            conn.ConnectionString = getConnectionString(connectionString);

            return GetUserPicture(conn, cmd, tableName, civilId);

            byte[] buffer = null;
            return buffer;
        }


        internal byte[] GetUserPicture(DbConnection conn, DbCommand cmd, String tableName, Decimal civilId)
        {

            DbDataReader reader = null;

            byte[] buffer = null;

            try
            {
//                conn = new DB2Connection();
//                conn.ConnectionString = getConnectionString("IBMProviderToDB2");
                conn.Open();

//                cmd = new DB2Command();
                cmd.Connection = conn;
            
//                cmd.CommandText = "SELECT STD_PHOTO_LOB FROM " + tableName + " WHERE CIVL_ID=?";

//                cmd.Parameters.Add("@civil_id", DB2Type.Decimal);
//                cmd.Parameters["@civil_id"].Value = civilId;

                reader = cmd.ExecuteReader();
                reader.Read();

                if (reader.HasRows)
                {
                    int maxSize = 102400;
                    buffer = new byte[maxSize];
                    reader.GetBytes(0, 0L, buffer, 0, maxSize);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try
                {
                    if (reader != null)
                        reader.Close();

                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                    if (conn != null)
                        conn = null;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            return buffer;
        }

        internal void SaveUserPicture(UserProfile user, ref byte[] buffer)
        {

//            String connectionString = "IBMProviderToDB2";
            String connectionString = "MSSQLServerProvider";

            String tableName;

            DbConnection conn = null;
            DbCommand[] cmd = new DbCommand[3];

            if (connectionString == "IBMProviderToDB2")
            {
                tableName = "SRSD.T_STD_PHOTO_BASE";
                conn = new DB2Connection();

                cmd[0] = new DB2Command();
                cmd[0].CommandText = "SELECT STD_PHOTO_LOB FROM " + tableName + " WHERE CIVL_ID=?";
                ((DB2Command)cmd[0]).Parameters.Add("@civil_id", DB2Type.Decimal);
                cmd[0].Parameters["@civil_id"].Value = user.CivilId;

                cmd[1] = new DB2Command();
                cmd[1].CommandText = "UPDATE " + tableName + " SET STD_PHOTO_LOB=?, USER_ID=?, MOD_BY=?, MOD_AT=? " +
                                     " WHERE CIVL_ID=?";
                ((DB2Command)cmd[1]).Parameters.Add("@photo", DB2Type.Blob);
                cmd[1].Parameters["@photo"].Value = buffer;
                ((DB2Command)cmd[1]).Parameters.Add("@user_id", DB2Type.VarChar);
                cmd[1].Parameters["@user_id"].Value = user.SupervisorId;

                ((DB2Command)cmd[1]).Parameters.Add("@mod_by", DB2Type.VarChar);
                cmd[1].Parameters["@mod_by"].Value = user.SupervisorId;
                ((DB2Command)cmd[1]).Parameters.Add("@mod_at", DB2Type.Timestamp);
                cmd[1].Parameters["@mod_at"].Value = DateTime.Now;

                ((DB2Command)cmd[1]).Parameters.Add("@civil_id", DB2Type.Decimal);
                cmd[1].Parameters["@civil_id"].Value = user.CivilId;

                cmd[2] = new DB2Command();
                cmd[2].CommandText = "INSERT INTO " + tableName + "(CIVL_ID, STD_PHOTO_LOB, USER_ID, CRTD_BY, CRTD_AT) " +
                                     " VALUES(?,?,?,?,?);";

                ((DB2Command)cmd[2]).Parameters.Add("@civil_id", DB2Type.Decimal);
                cmd[2].Parameters["@civil_id"].Value = user.CivilId;

                ((DB2Command)cmd[2]).Parameters.Add("@photo", DB2Type.Blob);
                cmd[2].Parameters["@photo"].Value = buffer;
                ((DB2Command)cmd[2]).Parameters.Add("@user_id", DB2Type.VarChar);
                cmd[2].Parameters["@user_id"].Value = user.SupervisorId;

                ((DB2Command)cmd[2]).Parameters.Add("@crtd_by", DB2Type.VarChar);
                cmd[2].Parameters["@crtd_by"].Value = user.SupervisorId;
                ((DB2Command)cmd[2]).Parameters.Add("@crtd_at", DB2Type.Timestamp);
                cmd[2].Parameters["@crtd_at"].Value = DateTime.Now;
            }
            else
            {
                tableName = "dbo.T_STD_PHOTO_BASE";
                conn = new SqlConnection();

                cmd[0] = new SqlCommand();
                cmd[0].CommandText = "SELECT STD_PHOTO_LOB FROM " + tableName + " WHERE CIVL_ID=@civil_id";
                ((SqlCommand)cmd[0]).Parameters.Add("@civil_id", SqlDbType.Decimal);
                cmd[0].Parameters["@civil_id"].Value = user.CivilId;

                cmd[1] = new SqlCommand();
                cmd[1].CommandText = "UPDATE " + tableName + " SET STD_PHOTO_LOB=@photo, USER_ID=@user_id, MOD_BY=@mod_by, MOD_AT=@mod_at " +
                                     " WHERE CIVL_ID=@civil_id";

                ((SqlCommand)cmd[1]).Parameters.Add("@photo", SqlDbType.Image);
                cmd[1].Parameters["@photo"].Value = buffer;
                ((SqlCommand)cmd[1]).Parameters.Add("@user_id", SqlDbType.VarChar);
                cmd[1].Parameters["@user_id"].Value = user.SupervisorId;

                ((SqlCommand)cmd[1]).Parameters.Add("@mod_by", SqlDbType.VarChar);
                cmd[1].Parameters["@mod_by"].Value = user.SupervisorId;
                ((SqlCommand)cmd[1]).Parameters.Add("@mod_at", SqlDbType.DateTime);
                cmd[1].Parameters["@mod_at"].Value = DateTime.Now;

                ((SqlCommand)cmd[1]).Parameters.Add("@civil_id", SqlDbType.Decimal);
                cmd[1].Parameters["@civil_id"].Value = user.CivilId;

                cmd[2] = new SqlCommand();
                cmd[2].CommandText = "INSERT INTO " + tableName + "(CIVL_ID, STD_ROWID, STD_PHOTO_LOB, USER_ID, CRTD_BY, CRTD_AT) " +
                                     " VALUES(@civil_id,@row_id,@photo,@user_id,@crtd_by,@crtd_at);";

                ((SqlCommand)cmd[2]).Parameters.Add("@civil_id", SqlDbType.Decimal);
                cmd[2].Parameters["@civil_id"].Value = user.CivilId;

                ((SqlCommand)cmd[2]).Parameters.Add("@row_id", SqlDbType.Binary);
                cmd[2].Parameters["@row_id"].Value = new byte[1]{0};

                ((SqlCommand)cmd[2]).Parameters.Add("@photo", SqlDbType.Image);
                cmd[2].Parameters["@photo"].Value = buffer;
                ((SqlCommand)cmd[2]).Parameters.Add("@user_id", SqlDbType.VarChar);
                cmd[2].Parameters["@user_id"].Value = user.SupervisorId;

                ((SqlCommand)cmd[2]).Parameters.Add("@crtd_by", SqlDbType.VarChar);
                cmd[2].Parameters["@crtd_by"].Value = user.SupervisorId;
                ((SqlCommand)cmd[2]).Parameters.Add("@crtd_at", SqlDbType.DateTime);
                cmd[2].Parameters["@crtd_at"].Value = DateTime.Now;
            }

            conn.ConnectionString = getConnectionString(connectionString);

            SaveUserPicture(conn, cmd, tableName, user, ref buffer);

        }

        internal void SaveUserPicture(DbConnection conn, DbCommand[] cmd, String tableName, UserProfile user, ref byte[] buffer)
        {
            DbDataReader reader = null;

            try
            {

//                conn = new DB2Connection();
//                conn.ConnectionString = getConnectionString("IBMProviderToDB2");
                conn.Open();

//                cmd = new DB2Command();
                cmd[0].Connection = conn;

//                cmd.CommandText = "SELECT STD_PHOTO_LOB FROM " + tableName + " WHERE CIVL_ID=?";

//                cmd.Parameters.Add("@civil_id", DB2Type.Decimal);
//                cmd.Parameters["@civil_id"].Value = user.CivilId;

                reader = cmd[0].ExecuteReader();
                reader.Read();
                Boolean hasRows = reader.HasRows;
                reader.Close();
                reader = null;

                cmd[0].Cancel();
                cmd[0].Parameters.Clear();

                if (hasRows)
                {
                    cmd[1].Connection = conn;
                    cmd[1].ExecuteNonQuery();
                }
                else
                {
                    cmd[2].Connection = conn;
                    cmd[2].ExecuteNonQuery();
                }
//                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try
                {
                    if (reader != null)
                        reader.Close();

                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                    if (conn != null)
                        conn = null;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
        }

        internal void DeleteFromDatabase()
        {
            String tableName = "T_STD_PHOTO_BASE";

            DB2Connection conn = null;
            DB2Command cmd = null;

            try
            {
//              dbConn = new OleDbConnection(getConnectionString("db2"));
                conn = new DB2Connection(getConnectionString("db2"));

                conn.Open();

//            OleDbCommand cmd = new OleDbCommand();
                cmd = new DB2Command();
                cmd.CommandText = "DELETE FROM " + tableName;

                cmd.Connection = conn;

                cmd.ExecuteNonQuery();
            }
            finally
            {
                try
                {
                    if (conn != null)
                        conn.Close();
                }
                catch (Exception ex)
                {
                    Console.Out.WriteLine(ex.Message);
                }
            }
        }

        internal void SaveToAccessDatabase(ref byte[] buffer)
        {
            String tableName = "T_STD_PHOTO_BASE";

            OleDbConnection dbConn = new OleDbConnection(getConnectionString("access"));

            OleDbDataAdapter dbAdapt = new OleDbDataAdapter("SELECT * FROM " + tableName, dbConn);

            dbAdapt.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            OleDbCommandBuilder dbCB = new OleDbCommandBuilder(dbAdapt);

            dbConn.Open();

            DataSet dbSet = new DataSet();

            dbAdapt.Fill(dbSet, tableName);

            DataTable dbTable = dbSet.Tables[tableName];

            DataRow dbRow = dbTable.NewRow();

            dbRow["CIVL_ID"] = "1";
            dbRow["STD_PHOTO_LOB"] = buffer;

            dbTable.Rows.Add(dbRow);

            dbAdapt.Update(dbSet, tableName);

            dbConn.Close();
        }

        private String getConnectionString(String provider) {
            if (provider == "MSProviderToDB2")
                return ConfigurationManager.ConnectionStrings["MSProviderToDB2OnPaaetRomanGateWayToSRSSchema"].ToString();
            else if (provider == "IBMProviderToDB2")
                return ConfigurationManager.ConnectionStrings["IBMProviderToDB2OnPaaetRomanGateWayToPhotoTableOnly"].ToString();
            else if (provider == "MSSQLServerProvider")
                return ConfigurationManager.ConnectionStrings["MSSQLServerProviderToPhotoTableOnly"].ToString();
            else
                return String.Empty;




//            return ConfigurationManager.ConnectionStrings["paaet_employeesConnectionString"].ToString();
//                return ConfigurationManager.ConnectionStrings["IBMDB2PaaetRomanPhotoTableConnectionString"].ToString();


/*
            ConnectionStringSettingsCollection connectionStrings = ConfigurationManager.ConnectionStrings;
            foreach (ConnectionStringSettings setting in connectionStrings)
            {
                String key = setting.Name;
                String val = setting.ConnectionString;
                val = val;
            }
*/
        }
    }
}
