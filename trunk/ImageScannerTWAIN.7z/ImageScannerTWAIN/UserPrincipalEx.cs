﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.DirectoryServices.AccountManagement;

namespace ImageScanner
{
    [DirectoryObjectClass("person")]

    //[DirectoryServicesPermissionAttribute(SecurityAction.LinkDemand, Unrestricted = true)]
    //[DirectoryServicesPermissionAttribute(SecurityAction.InheritanceDemand, Unrestricted = true)]
    public class UserPrincipalEx : UserPrincipal
    {
        // Inplement the constructor using the base class constructor. 
        public UserPrincipalEx(PrincipalContext context)
            : base(context)
        {

        }

        // Implement the constructor with initialization parameters.    
        public UserPrincipalEx(PrincipalContext context,
                             string samAccountName,
                             string password,
                             bool enabled)
            : base(context,
                   samAccountName,
                   password,
                   enabled)
        {
        }

        [DirectoryProperty("ExtensionName")]
        public string ExtensionName
        {
            get
            {
                if (ExtensionGet("ExtensionName").Length != 1)
                    return null;

                return (string)ExtensionGet("ExtensionName")[0];

            }
            //set { this.ExtensionSet("extensionName", value); }
        }

        // Implement the overloaded search method FindByIdentity.
        public static new UserPrincipalEx FindByIdentity(PrincipalContext context,
                                                       string identityValue)
        {
            return (UserPrincipalEx)FindByIdentityWithType(context,
                                                         typeof(UserPrincipalEx),
                                                         identityValue);
        }

        // Implement the overloaded search method FindByIdentity. 
        public static new UserPrincipalEx FindByIdentity(PrincipalContext context,
                                                       IdentityType identityType,
                                                       string identityValue)
        {
            return (UserPrincipalEx)FindByIdentityWithType(context,
                                                         typeof(UserPrincipalEx),
                                                         identityType,
                                                         identityValue);
        }
    }		
}
