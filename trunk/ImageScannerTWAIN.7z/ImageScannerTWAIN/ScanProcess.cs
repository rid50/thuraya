﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;

namespace ImageScanner
{
    partial class TwainForm
    {
        bool _error = false;
/*
        internal void setMessageFilter() {
            //if (!msgfilter)
            {
                //this.Enabled = false;
                //msgfilter = true;
                Application.AddMessageFilter(_mainForm);
            }
        }
*/
        internal bool startScanProcess()
        {

            //short retCode = _tw.AcquireImage();
            //if (retCode != 0)
            //    _error = true;
            //else
            //    _error = false;

            //Thread t = new Thread(new ThreadStart(Acquire));
            //t.Start();


            //Task<short> t = new Task<short>(tw.Acquire);
            //t.Start();
            //if (t.Result != 0)
            //    _error = true;
            //else
            //    _error = false;

            return _error;

/*
            if (backgroundWorkerScan.IsBusy)
                return;

            backgroundWorkerScan.RunWorkerAsync();
*/ 
        }

        //private void Acquire()
        //{
        //    short retCode = tw.Acquire();
        //    if (retCode != 0)
        //        _error = true;
        //    else
        //        _error = false;
        //}

        private void backgroundWorkerScan_DoWork(object sender, DoWorkEventArgs e)
        {
            //short retCode = _tw.AcquireImage();
            //if (retCode != 0)
            //    _error = true;
            //else
            //    _error = false;
        }

        private void backgroundWorkerScan_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (_error)
            {
                //EndingScan();
                //tw.CloseSrc();
                _mainForm.toolStripStatusLabelError.Text = "Error while scan is in process";
                _mainForm.stopProgressBar();
                _mainForm.Cursor = Cursors.Default;
                _mainForm.enableButtons(true);
            }
        }
    }
}
