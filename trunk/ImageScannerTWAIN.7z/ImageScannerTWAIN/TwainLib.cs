using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace TwainLib
{
public enum TwainCommand
{
	Not				= -1,
	Null			= 0,
	TransferReady	= 1,
	CloseRequest	= 2,
	CloseOk			= 3,
	DeviceEvent		= 4
}




public class Twain
{
	private const short CountryUSA		= 1;
	private const short LanguageUSA		= 13;

	public Twain()
	{
		appid = new TwIdentity();
		appid.Id				= IntPtr.Zero;
		appid.Version.MajorNum	= 1;
		appid.Version.MinorNum	= 1;
		appid.Version.Language	= LanguageUSA;
		appid.Version.Country	= CountryUSA;
		appid.Version.Info		= "Hack 1";
		appid.ProtocolMajor		= TwProtocol.Major;
		appid.ProtocolMinor		= TwProtocol.Minor;
		appid.SupportedGroups	= (int)(TwDG.Image | TwDG.Control);
		appid.Manufacturer		= "NETMaster";
		appid.ProductFamily		= "Freeware";
		appid.ProductName		= "Hack";

		srcds = new TwIdentity();
		srcds.Id = IntPtr.Zero;

        dsmstat = new TwStatus();

        hwnd = IntPtr.Zero;

		evtmsg.EventPtr = Marshal.AllocHGlobal( Marshal.SizeOf( winmsg ) );
	}

	~Twain()
	{
		Marshal.FreeHGlobal( evtmsg.EventPtr );
	}

    public String getInfo() {
        return _infoMessage;
    }

	public short Init( IntPtr hwndp )
	{
        short retCode = 0;
		
        Finish();

		TwRC rc = DSMparent( appid, IntPtr.Zero, TwDG.Control, TwDAT.Parent, TwMSG.OpenDSM, ref hwndp );
        if (rc == TwRC.Success)
        {
            rc = DSMident(appid, IntPtr.Zero, TwDG.Control, TwDAT.Identity, TwMSG.GetDefault, srcds);
            if (rc == TwRC.Success)
            {
                hwnd = hwndp;
                _infoMessage = srcds.ProductName;
            }
            else
            {
                DSMstatus(appid, IntPtr.Zero, TwDG.Control, TwDAT.Status, TwMSG.Get, dsmstat);
                retCode = (short) dsmstat.ConditionCode;
                if (retCode == (short)TwCC.NoDS)
                    _infoMessage = "No Image Source installed";
                else
                    _infoMessage = "There is a problem with an Image Source. Call Support Center.";

                rc = DSMparent(appid, IntPtr.Zero, TwDG.Control, TwDAT.Parent, TwMSG.CloseDSM, ref hwndp);
            }
        }

        return retCode;
	}

    public short Select(IntPtr hwndp)
	{
        short retCode = 0;

		TwRC rc;

        retCode = Init(hwndp);

        if (appid.Id != IntPtr.Zero)
        {
            CloseSrc();

            rc = DSMident(appid, IntPtr.Zero, TwDG.Control, TwDAT.Identity, TwMSG.UserSelect, srcds);

            if (rc == TwRC.Success)
                _infoMessage = srcds.ProductName;
            else if (rc == TwRC.Failure)
                HandleError();
        }

        return retCode;
	}


	public short Acquire()
	{
		TwRC rc;
		CloseSrc();
		if( appid.Id == IntPtr.Zero )
		{
			Init( hwnd );
			if( appid.Id == IntPtr.Zero )
                return (short)TwRC.Failure;
		}
	
        rc = DSMident( appid, IntPtr.Zero, TwDG.Control, TwDAT.Identity, TwMSG.OpenDS, srcds );
        if (rc != TwRC.Success)
        {
            HandleError();

//            DSMstatus(appid, IntPtr.Zero, TwDG.Control, TwDAT.Status, TwMSG.Get, dsmstat);
//            short retCode = dsmstat.ConditionCode;
            
            
            
            return (short)TwRC.Failure;
        }

        TwImageLayout imlayout = new TwImageLayout();
        rc = DSlayout(appid, srcds, TwDG.Image, TwDAT.ImageLayout, TwMSG.Get, imlayout);
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }

        //imlayout.Frame.Right.FromFloat(1.77f);
        //imlayout.Frame.Bottom.FromFloat(2.36f);

        rc = DSlayout(appid, srcds, TwDG.Image, TwDAT.ImageLayout, TwMSG.Set, imlayout);
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }

        TwCapability cap = new TwCapability(TwCap.XferCount, 1, TwType.Int16);
		rc = DScap( appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap );
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }

        cap = new TwCapability(TwCap.IPixelType, 2, TwType.UInt16);  // TWPT_RGB - 2
        rc = DScap( appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap );
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }

        cap = new TwCapability(TwCap.BitDepth, 8, TwType.UInt16);
        rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }

        cap = new TwCapability(TwCap.XResolution, 600, TwType.Fix32);
        //rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Get, cap);
        //IntPtr pv = Twain.GlobalLock(cap.Handle);
        //short w1 = Marshal.ReadInt16(pv, 0);
        //short w2 = Marshal.ReadInt16(pv, 2);
        rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }

        cap = new TwCapability(TwCap.YResolution, 600, TwType.Fix32);
        rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }
/*
        cap = new TwCapability(TwCap.ImageFileFormat);
        rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Get, cap);
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }
*/

/*
        TwSetUpFileXfer xfer = new TwSetUpFileXfer();
        xfer.FileName = "c:\\temp\\doc.pdf";
        xfer.Format = 2;       // TWFF_PDF 10
        xfer.VrefNum = 0xffff;  // TWON_DONTCARE16
        rc = DSxfer(appid, srcds, TwDG.Control, TwDAT.SetupFileXfer, TwMSG.Set, xfer);
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }
*/

		TwUserInterface	guif = new TwUserInterface();
		guif.ShowUI = 0;
		guif.ModalUI = 1;
		guif.ParentHand = hwnd;
		rc = DSuserif( appid, srcds, TwDG.Control, TwDAT.UserInterface, TwMSG.EnableDS, guif );
        if (rc != TwRC.Success)
        {
            HandleError();
            return (short)TwRC.Failure;
        }

        return (short)TwRC.Success;
	}


	public ArrayList TransferPictures()
	{
		ArrayList pics = new ArrayList();
		if( srcds.Id == IntPtr.Zero )
			return pics;

		TwRC rc;
		IntPtr hbitmap = IntPtr.Zero;
		TwPendingXfers pxfr = new TwPendingXfers();
		
		do
		{
			pxfr.Count = 0;
			hbitmap = IntPtr.Zero;
/*
            TwSetUpFileXfer xfer = new TwSetUpFileXfer();
            xfer.FileName = System.Text.Encoding.UTF8.GetBytes("c:\\temp\\doc.pdf");
            xfer.Format = 10;       // TWFF_PDF 10
            xfer.VrefNum = 0xffff;  // TWON_DONTCARE16
            rc = DSxfer(appid, srcds, TwDG.Control, TwDAT.SetupFileXfer, TwMSG.Get, xfer);
            if (rc != TwRC.Success)
            {
                short retCode = HandleError();
                return pics;
            }
*/
			TwImageInfo	iinf = new TwImageInfo();
			rc = DSiinf( appid, srcds, TwDG.Image, TwDAT.ImageInfo, TwMSG.Get, iinf );
            if (rc != TwRC.Success)
            {
                HandleError();
                return pics;
            }
/*
            iinf.ImageWidth = 100;
            iinf.ImageLength = 100;

            rc = DSiinf(appid, srcds, TwDG.Image, TwDAT.ImageInfo, TwMSG.Set, iinf);
            if (rc != TwRC.Success)
			{
                HandleError();
				return pics;
			}
*/
			rc = DSixfer( appid, srcds, TwDG.Image, TwDAT.ImageNativeXfer, TwMSG.Get, ref hbitmap );
			if( rc != TwRC.XferDone )
			{
                HandleError();
				return pics;
			}

			rc = DSpxfer( appid, srcds, TwDG.Control, TwDAT.PendingXfers, TwMSG.EndXfer, pxfr );
			if( rc != TwRC.Success )
			{
				CloseSrc();
				return pics;
			}

			pics.Add( hbitmap );
		}
		while( pxfr.Count != 0 );

		rc = DSpxfer( appid, srcds, TwDG.Control, TwDAT.PendingXfers, TwMSG.Reset, pxfr );
		return pics;
	}


	public TwainCommand PassMessage( ref Message m )
	{
		if( srcds.Id == IntPtr.Zero )
			return TwainCommand.Not;

		int pos = GetMessagePos();

		winmsg.hwnd		= m.HWnd;
		winmsg.message	= m.Msg;
		winmsg.wParam	= m.WParam;
		winmsg.lParam	= m.LParam;
		winmsg.time		= GetMessageTime();
		winmsg.x		= (short) pos;
		winmsg.y		= (short) (pos >> 16);
		
		Marshal.StructureToPtr( winmsg, evtmsg.EventPtr, false );
		evtmsg.Message = 0;
		TwRC rc = DSevent( appid, srcds, TwDG.Control, TwDAT.Event, TwMSG.ProcessEvent, ref evtmsg );
		if( rc == TwRC.NotDSEvent )
			return TwainCommand.Not;
		if( evtmsg.Message == (short) TwMSG.XFerReady )
			return TwainCommand.TransferReady;
		if( evtmsg.Message == (short) TwMSG.CloseDSReq )
			return TwainCommand.CloseRequest;
		if( evtmsg.Message == (short) TwMSG.CloseDSOK )
			return TwainCommand.CloseOk;
		if( evtmsg.Message == (short) TwMSG.DeviceEvent )
			return TwainCommand.DeviceEvent;

		return TwainCommand.Null;
	}

	private short HandleError()
    {
        TwRC rc;

        DSstatus(appid, srcds, TwDG.Control, TwDAT.Status, TwMSG.Get, dsmstat);
        short retCode = (short) dsmstat.ConditionCode;
        
        TwPendingXfers pxfr = new TwPendingXfers();
//        pxfr.Count = 0;

        rc = DSpxfer(appid, srcds, TwDG.Control, TwDAT.PendingXfers, TwMSG.EndXfer, pxfr);
        rc = DSpxfer(appid, srcds, TwDG.Control, TwDAT.PendingXfers, TwMSG.Reset, pxfr);

        CloseSrc();

        return retCode;
    }

	public void CloseSrc()
	{
		TwRC rc;
		if( srcds.Id != IntPtr.Zero )
		{
			TwUserInterface	guif = new TwUserInterface();
			rc = DSuserif( appid, srcds, TwDG.Control, TwDAT.UserInterface, TwMSG.DisableDS, guif );
            rc = DSMident(appid, IntPtr.Zero, TwDG.Control, TwDAT.Identity, TwMSG.CloseDS, srcds);

            srcds.Id = IntPtr.Zero;
		}
	}

	public void Finish()
	{
		TwRC rc;
		CloseSrc();
		if( appid.Id != IntPtr.Zero )
			rc = DSMparent( appid, IntPtr.Zero, TwDG.Control, TwDAT.Parent, TwMSG.CloseDSM, ref hwnd );
	}

	private IntPtr		hwnd;
	private TwIdentity	appid;
	private TwIdentity	srcds;
	private TwEvent		evtmsg;
	private WINMSG		winmsg;
    private TwStatus    dsmstat;
    
    string _infoMessage = String.Empty;


	// ------ DSM entry point DAT_ variants:
        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DSMparent( [In, Out] TwIdentity origin, IntPtr zeroptr, TwDG dg, TwDAT dat, TwMSG msg, ref IntPtr refptr );

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DSMident( [In, Out] TwIdentity origin, IntPtr zeroptr, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwIdentity idds );

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DSMstatus( [In, Out] TwIdentity origin, IntPtr zeroptr, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwStatus dsmstat );


	// ------ DSM entry point DAT_ variants to DS:
        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DSuserif( [In, Out] TwIdentity origin, [In, Out] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, TwUserInterface guif );

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DSevent( [In, Out] TwIdentity origin, [In, Out] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, ref TwEvent evt );

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DSstatus( [In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwStatus dsmstat );

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DScap( [In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwCapability capa );

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DSiinf( [In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwImageInfo imginf );

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DSixfer( [In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, ref IntPtr hbitmap );

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
	private static extern TwRC DSpxfer( [In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwPendingXfers pxfr );

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
    private static extern TwRC DSlayout([In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwImageLayout imlayout);

        [DllImport("TWAINDSM.dll", EntryPoint = "#1")]
        private static extern TwRC DSxfer([In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwSetUpFileXfer imxfer);

		[DllImport("kernel32.dll", ExactSpelling=true)]
	internal static extern IntPtr GlobalAlloc( int flags, int size );
		[DllImport("kernel32.dll", ExactSpelling=true)]
	internal static extern IntPtr GlobalLock( IntPtr handle );
		[DllImport("kernel32.dll", ExactSpelling=true)]
	internal static extern bool GlobalUnlock( IntPtr handle );
		[DllImport("kernel32.dll", ExactSpelling=true)]
	internal static extern IntPtr GlobalFree( IntPtr handle );
    //    [DllImport("kernel32.dll", ExactSpelling = true)]
    //internal static extern IntPtr GlobalSize(IntPtr handle);

		[DllImport("user32.dll", ExactSpelling=true)]
	private static extern int GetMessagePos();
		[DllImport("user32.dll", ExactSpelling=true)]
	private static extern int GetMessageTime();


		[DllImport("gdi32.dll", ExactSpelling=true)]
	private static extern int GetDeviceCaps( IntPtr hDC, int nIndex );

		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
	private static extern IntPtr CreateDC( string szdriver, string szdevice, string szoutput, IntPtr devmode );

		[DllImport("gdi32.dll", ExactSpelling=true)]
	private static extern bool DeleteDC( IntPtr hdc );




	public static int ScreenBitDepth {
		get {
			IntPtr screenDC = CreateDC( "DISPLAY", null, null, IntPtr.Zero );
			int bitDepth = GetDeviceCaps( screenDC, 12 );
			bitDepth *= GetDeviceCaps( screenDC, 14 );
			DeleteDC( screenDC );
			return bitDepth;
			}
		}


		[StructLayout(LayoutKind.Sequential, Pack=4)]
	internal struct WINMSG
		{
		public IntPtr		hwnd;
		public int			message;
		public IntPtr		wParam;
		public IntPtr		lParam;
		public int			time;
		public int			x;
		public int			y;
		}


	} // class Twain
}
