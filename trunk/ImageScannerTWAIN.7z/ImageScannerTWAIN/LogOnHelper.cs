using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Security.Permissions;

namespace ImageScanner
{
    partial class Form1
    {
        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword,
            int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public extern static bool CloseHandle(IntPtr handle);

        public WindowsIdentity LogOn()
        {
            WindowsIdentity id = null;
            IntPtr tokenHandle = new IntPtr(0);
            try
            {
                const int LOGON32_PROVIDER_DEFAULT = 0;
                //This parameter causes LogonUser to create a primary token.
//                const int LOGON32_LOGON_INTERACTIVE = 2;
                const int LOGON32_LOGON_NETWORK = 3;

                tokenHandle = IntPtr.Zero;

                // Call LogonUser to obtain a handle to an access token.
                bool returnValue = LogonUser(txtPersonId.Text, txtDomain.Text, txtPassword.Text,
                                        LOGON32_LOGON_NETWORK, LOGON32_PROVIDER_DEFAULT,
                                        ref tokenHandle);

                if (false == returnValue)
                {
                    int ret = Marshal.GetLastWin32Error();
                    throw new System.ComponentModel.Win32Exception(ret);
                }

                // Use the token handle returned by LogonUser.
                id = new WindowsIdentity(tokenHandle);

                // Free the tokens.
                if (tokenHandle != IntPtr.Zero)
                    CloseHandle(tokenHandle);
            }
            catch (Exception ex)
            {
                toolStripStatusLabelError.Text = ex.Message;
            }

            return id;
        }            
    }
}
