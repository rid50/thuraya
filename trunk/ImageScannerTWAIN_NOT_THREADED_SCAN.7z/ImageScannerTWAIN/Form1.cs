using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Security.Principal;
using System.Collections;
using System.Configuration;


//using System.Configuration;

//using System.Xml;
using System.IO;

using TwainLib;
using System.DirectoryServices.AccountManagement;
//using ImageScanner.PTServices;

namespace ImageScanner
{
    public partial class Form1 : Form, IMessageFilter
    {
        private BackgroundWorker backgroundWorkerProgressBar;
        private BackgroundWorker backgroundWorkerAuthentication;
        private BackgroundWorker backgroundWorkerDB;
        private BackgroundWorker backgroundWorkerScan;

        private UserProfile _user = null;
        private bool _isImageSourceSelected = false;

        public Form1()
        {
            InitializeComponent();

            backgroundWorkerProgressBar = new BackgroundWorker();
            backgroundWorkerProgressBar.WorkerSupportsCancellation = true;
            backgroundWorkerProgressBar.WorkerReportsProgress = true;
            backgroundWorkerProgressBar.DoWork += new DoWorkEventHandler(backgroundWorkerProgressBar_DoWork);
            backgroundWorkerProgressBar.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerProgressBar_RunWorkerCompleted);
            backgroundWorkerProgressBar.ProgressChanged += new ProgressChangedEventHandler(backgroundWorkerProgressBar_ProgressChanged);

            backgroundWorkerAuthentication = new BackgroundWorker();
            backgroundWorkerAuthentication.DoWork += new DoWorkEventHandler(backgroundWorkerAuthentication_DoWork);
            backgroundWorkerAuthentication.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerAuthentication_RunWorkerCompleted);

            backgroundWorkerDB = new BackgroundWorker();
            backgroundWorkerDB.DoWork += new DoWorkEventHandler(backgroundWorkerDB_DoWork);
            backgroundWorkerDB.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerDB_RunWorkerCompleted);

            backgroundWorkerScan = new BackgroundWorker();
            backgroundWorkerScan.DoWork += new DoWorkEventHandler(backgroundWorkerScan_DoWork);
            backgroundWorkerScan.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerScan_RunWorkerCompleted);


            StatusBar bar = new StatusBar();
            bar.Visible = true;
            
            tw = new Twain();

            short retCode = tw.Init(this.Handle);
            if (retCode != 0)
            {
                labelImageSource.ForeColor = Color.Red;
                labelImageSource.Text = tw.getInfo();
            }
            else
            {
                labelImageSource.ForeColor = Color.Green;
                labelImageSource.Text = tw.getInfo();

                _isImageSourceSelected = true;
            }
        }
/*
        private String getAuthorizedPersonFDN()
        {
            int i = txtPersonId.Text.LastIndexOf("\\");
            if (i != -1)
                return txtPersonId.Text;
            else
            {
                if (txtDomain.Text.Length == 0)
                    return txtPersonId.Text;
                else
                    return txtDomain.Text + "\\" + txtPersonId.Text;
            }
        }
*/
        private void get_Click(object sender, EventArgs e)
        {

/*
            _user = new UserProfile();
            _user.SupervisorId = txtPersonId.Text;

            try
            {
                decimal cd = Convert.ToDecimal(txtCivilId.Text);

                //ValidationServicesHelper.ValidateCivilId(txtCivilId.Text, 'a');
            }
            catch (FormatException ex)
            {
                toolStripStatusLabelError.Text = ex.Message;
                return;
            }
*/ 
/*
            catch (Exception ex)
            {
                toolStripStatusLabelError.Text = ex.Message;
                return;
            }
*/
            //_user.CivilId = Convert.ToDecimal(txtCivilId.Text);

            //if (btnGet.Enabled == false)
            //    return;

            if (txtCivilId.Text == "")
            {
                toolStripStatusLabelError.Text = "Enter an application number";
                return;
            }

            _user.ApplicationNumber = txtCivilId.Text;
                        
            this.Cursor = Cursors.WaitCursor;
            enableButtons(false);
            clearControls();
            listBox.Items.Clear();

            List<object> args = new List<object>();
            args.Add("getAttachmentList");
            startProgressBar();
            startDbProcess(args);
            //backgroundWorkerDB_DoWork(null, null);

/*
            DBHelper db = new DBHelper();
            
            try
            {
                db.GetUserProfile(ref _user);
                if (_user.Status != "ok")
                {
                    toolStripStatusLabelError.Text = _user.Status;
                    return;
                }
                else
                {
                    //                    txtUserProfile.Text = _user.UserId + Environment.NewLine + Environment.NewLine +
                    txtUserProfile.Text = _user.FirstName.Trim() + " " +
                                            _user.SecondName.Trim() + " " +
                                            _user.ThirdName.Trim() + " " +
                                            _user.LastName.Trim() + Environment.NewLine + Environment.NewLine +
                                            _user.InstituteName.Trim() + Environment.NewLine + Environment.NewLine +
                                            _user.MajorName.Trim();

                    byte[] buffer = db.GetUserPicture(_user.CivilId);

                    if (buffer != null)
                    {
                        MemoryStream ms = new MemoryStream();
                        ms.Write(buffer, 0, buffer.Length);
                        Image img = Image.FromStream(ms);
                        pictureBox1.Image = img;

                        ms.Close();
                    }
                    enableScan(true);
                    //                    btnScan.Enabled = true;
                }

            }
            catch (Exception ex)
            {
                toolStripStatusLabelError.Text = ex.Message;
            }
            finally
            {
//                stopProgressBar();
                this.Cursor = Cursors.Default;
                ((Button)sender).Enabled = true;
            }
 */ 
        }

        private void scan_Click(object sender, EventArgs e)
        {
/*
            String inFileName = "temp.jpg";
            String outFileName = "temp.pdf";
            PdfSharp.Drawing.XImage ximg = PdfSharp.Drawing.XImage.FromFile(inFileName);

            PdfSharp.Pdf.PdfDocument doc = new PdfSharp.Pdf.PdfDocument();
            PdfSharp.Pdf.PdfPage page = new PdfSharp.Pdf.PdfPage();
            page.Width = ximg.PixelWidth;
            page.Height = ximg.PixelHeight;
            doc.Pages.Add(page);
            PdfSharp.Drawing.XGraphics xgr = PdfSharp.Drawing.XGraphics.FromPdfPage(doc.Pages[0]);

            xgr.DrawImage(ximg, 0, 0);
            doc.Save(outFileName);
            doc.Close();

            return;
*/

            if (txtCivilId.Text == "")
            {
                toolStripStatusLabelError.Text = "Enter an application number";
                return;
            }

            _user.ApplicationNumber = txtCivilId.Text;

            if (txtAttachmentTitle.Text == "")
                txtAttachmentTitle.Text = Properties.Resources.sketch;

            _user.Title = txtAttachmentTitle.Text;

            this.Cursor = Cursors.WaitCursor;
            enableButtons(false);
            clearControls();
            listBox.Items.Clear();

            Application.DoEvents();

            if (!msgfilter)
            {
                //this.Enabled = false;
                msgfilter = true;
                Application.AddMessageFilter(this);
            }

            //btnScan.Enabled = false;

            startProgressBar();
            //startScanProcess();
            //backgroundWorkerScan_DoWork(null, null);


            short retCode = tw.Acquire();
            if (retCode != 0)
            {
                EndingScan();
                toolStripStatusLabelError.Text = "Error while scan is in process";
                //this.Enabled = true;
                this.Activate();
                this.Cursor = Cursors.Default;
                enableButtons(true);

//                tw.Finish();
            }

            stopProgressBar();

        }

        private void logon_Click(object sender, EventArgs e)
        {
            txtCivilId.Enabled = false;

            startProgressBar();
            startAuthProcess();
            //backgroundWorkerAuthentication_DoWork(null, null);

            //System.Threading.Thread.Sleep(10000);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            WindowsIdentity windowsIdentity = WindowsIdentity.GetCurrent();
            int i = windowsIdentity.Name.LastIndexOf("\\");
            if (i != -1)
            {
                txtDomain.Text = windowsIdentity.Name.Substring(0, i);
                txtPersonId.Text = windowsIdentity.Name.Substring(i + 1);

                //_user.UserId = txtDomain.Text + "\\" + txtPersonId.Text;

                PrincipalContext context = new PrincipalContext(ContextType.Domain);
                var principal = UserPrincipalEx.FindByIdentity(context, IdentityType.SamAccountName, txtPersonId.Text);
                _user = new UserProfile();
                _user.DisplayName = principal.ExtensionName;
            }
            else
            {
                txtDomain.Text = String.Empty;
                txtPersonId.Text = windowsIdentity.Name;
            }





/*
            IdentityReferenceCollection coll = windowsIdentity.Groups;
            IEnumerator it = coll.GetEnumerator();
            while (it.MoveNext())
            {
                String str = ((IdentityReference)it.Current).Translate(typeof(NTAccount)).Value;
                int ii = 0;
            }

            WindowsPrincipal principal = new WindowsPrincipal(windowsIdentity);
            bool b = principal.IsInRole(ConfigurationManager.AppSettings["AuthorizationGroup"]);
*/

            txtPassword.Text = "******";

            txtCivilId.Enabled = false;

            enableButtons(false);
            clearControls();

            txtAttachmentTitle.Text = Properties.Resources.sketch;

            this.ActiveControl = txtPersonId;
            this.AcceptButton = btnLogon;

#if DEBUG
//            txtPersonId.Text = "ri.russia";
//            txtPersonId.Text = "ri.davidenko";
//            txtPassword.Text = "";

//            txtCivilId.Text = "287062301977";
//            txtCivilId.Text = "282033000734";
//            txtCivilId.Text = "10";
//            txtCivilId.Text = "250031301609";
            
#endif

            String domainLocation = ConfigurationManager.AppSettings["DomainLocation"];
//            if (domainLocation.StartsWith(txtDomain.Text, StringComparison.InvariantCultureIgnoreCase) ||
//                domainLocation.Equals("rootDSE"))
            if (domainLocation.StartsWith(txtDomain.Text, StringComparison.InvariantCultureIgnoreCase))
            {
                btnLogon.PerformClick();
                btnLogon.Enabled = false;
            }

        }

        internal UserProfile User
        {
            get { return _user; }
        }

        private void txtPersonId_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = btnLogon;
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = btnLogon;
        }

        private void txtCivilId_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = btnGet;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            short retCode = tw.Select(this.Handle);
            if (retCode != 0)
            {
                labelImageSource.ForeColor = Color.Red;
                labelImageSource.Text = tw.getInfo();

                _isImageSourceSelected = false;

            }
            else
            {
                labelImageSource.ForeColor = Color.Green;
                labelImageSource.Text = tw.getInfo();

                _isImageSourceSelected = true;

                if (txtAttachmentTitle.Text.Length != 0)
                    enableScan(true);
            }
        }

        private void txtPersonId_TextChanged(object sender, EventArgs e)
        {
            btnLogon.Enabled = true;
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            btnLogon.Enabled = true;
        }

        private void txtCivilId_TextChanged(object sender, EventArgs e)
        {
            //clearControls();
        }

        private void enableScan(bool flag) {
            if (flag && _isImageSourceSelected)
                btnScan.Enabled = true;
            else
                btnScan.Enabled = false;
        }

        private void clearControls()
        {
            pictureBox1.Image = null;
            pictureBox1.Invalidate();
            txtAttachmentTitle.Text = "";
            txtAttachmentUser.Text = "";
            txtAttachmentDate.Text = "";
            toolStripStatusLabelError.Text = "";
        }

        private void enableButtons(bool flag)
        {
            enableScan(flag);
            btnGet.Enabled = flag;
            btnDelete.Enabled = flag;
            btnUpdateTitle.Enabled = flag;
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (((ListBox)sender).SelectedItem != null)
            {
                List<object> args = new List<object>();
                args.Add("getAttachment");
                var it = (KeyValuePair<int, string>)((ListBox)sender).SelectedItem;
                args.Add(it.Key);
                startProgressBar();
                startDbProcess(args);
            }
        }

        private void btnUpdateTitle_Click(object sender, EventArgs e)
        {
            if (txtAttachmentTitle.Text == "")
                return;
            else
            {
                List<object> args = new List<object>();
                args.Add("updateTitle");
                var it = (KeyValuePair<int, string>)listBox.SelectedItem;
                args.Add(it.Key);
                args.Add(txtAttachmentTitle.Text);
                startProgressBar();
                startDbProcess(args);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listBox.SelectedItem != null)
            {
                List<object> args = new List<object>();
                args.Add("deleteAttachment");
                var it = (KeyValuePair<int, string>)listBox.SelectedItem;
                args.Add(it.Key);
                startProgressBar();
                startDbProcess(args);
            }
        }
    }
}