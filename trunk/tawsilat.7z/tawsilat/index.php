<?php
session_start();
require_once('c:/simplesaml/lib/_autoload.php');
//require_once('/var/www/html/simplesamlphp/lib/_autoload.php');

//require_once('/home/y...../public_html/simplesamlphp/lib/_autoload.php');

//$url = 'http://mewdesigncomps/index.html';

$ini = parse_ini_file("config.ini");
$idp = $ini["IdP"];
$idpSource = $ini["IdPSource"];

$_SESSION['ini_lang'] = $ini["lang"];

//throw new Exception(http_negotiate_language(array('en-US', 'ar-KW')));
//throw new Exception($_SERVER['HTTP_ACCEPT_LANGUAGE']);

//throw new Exception((preg_match('/^ar/', $_SERVER['HTTP_ACCEPT_LANGUAGE'])) == true);

if ($idp == "SAML") {
	if ($idpSource == "DB")
		$as = new SimpleSAML_Auth_Simple('mewSQLAuth');
	else
		$as = new SimpleSAML_Auth_Simple('mewADAuth');
		
	$as->requireAuth();
	$attributes = $as->getAttributes();
	//$url = $url . '?loginName=' . $attributes["LoginName"];
	//$_SESSION['loginName'] = $attributes["LoginName"];
}

?>

<!doctype html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="description" content="MEW Distribution Department">
  
    <title>Ministry of Electricity and Water</title>
	
	<link rel="stylesheet" href="css/style.css?v=1">
  
	<link rel="shortcut icon" type="image/vnd.microsoft.icon" href="favicon.ico" />

	<link rel="stylesheet" media="all" href="themes/smoothness/jquery-ui-1.10.3.custom.min.css" />	
	<link rel="stylesheet" media="all" href="css/ui.jqgrid.css" />	
    <link rel="stylesheet" media="screen" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" media="print" type="text/css" href="css/style.css"/>
	
    <script src="js/jquery-1.10.2.min.js" type="text/javascript"></script>
    
    <script src="js/jqGridJs/i18n/grid.locale-ar.js" type="text/javascript"></script>
    <script src="js/jqGridJs/i18n/grid.locale-en.js" type="text/javascript"></script>
	<script src="js/jqGridJs/jquery.jqGrid.min.js" type="text/javascript"></script>
    <script src="js/jqGridJs/grid.filtergrid.js" type="text/javascript"></script>
	
	<script src="js/jquery.blockUI.js" type="text/javascript"></script>
    <script src="js/jquery.hotkeys.js" type="text/javascript"></script>
	<!--script src="js/jstree.min.js" type="text/javascript"></script-->
	<script src="js/jquery.jstree.js" type="text/javascript"></script>
	<!--script src="js/jquery-ui-1.10.2.custom.min.js" type="text/javascript"></script-->
	<script src="js/jquery-ui-1.10.3.custom.min.js" type="text/javascript"></script>
	<script src="js/jquery.ui.datepicker-ar.js" type="text/javascript"></script>
	<script src="js/jquery.i18n.properties-min-1.0.9.js" type="text/javascript"></script>
    <script src="js/script.js" type="text/javascript"></script>
    <script src="js/grid.js" type="text/javascript"></script>
    <script src="js/my-helpers.js" type="text/javascript"></script>

    <script src="sliderengine/amazingslider.js"></script>
    <script src="sliderengine/initslider-1.js"></script>
	
	<style type="text/css">
		.ui-accordion .ui-accordion-content {
			overflow: hidden;
		}
	</style>	
</head>

<body dir="ltr">
    <div id="wrapper">
    	<header>
			<div class="floatLeft">
				<a href="#" class="psc-logo"><img src="images/logo.png" alt="Back to Home" title="Back to Home" /></a>
			</div>
			
			<div class="floatRight">
				<a href="#" id="flagUK"><img src="images/FlagUK.png" alt="English" title="English" /></a>
				<a href="#" id="flagKuwait"><img src="images/FlagKuwait.png" alt="Arabic" title="Arabic" /></a>
			</div>
			
        </header>
        
        <div id="main" class="ui-widget">
            <section id="left-section" class="floatLeft ui-corner-all">
			</section>

            <section id="right-section" class="floatRight ui-corner-all">
				<div id="accordion">
					<span>Application</span>
					<div>
						<div><span>Application</span>#&nbsp;<input type="text" id="user_id" maxlength="10" size="10" class="text ui-widget-content ui-corner-all" value="20095423" /></div>
						<!--button id="takePicture" title="Take a snap">Make</button>
						<button id="getPicture" title="Get a picture">Get</button-->
					</div>
					<span>Form</span>
					<div>
					</div>
					<span>Signatures</span>
					<div>
						<button id="signButton" title="Sign the document">Sign</button>
						<img src="images/pinault.png" title="François-Henri Pinault" width="160px" height="100px"  /></a>
						<img src="images/barack.jpg" title="Barack Obama" width="160px" height="100px"  /></a>
						<img src="images/visa.jpg" title="Visa Card" width="160px" height="100px"  /></a>

					</div>
					<span>Drawings & Scanned Images</span>
					<div>
					</div>
				</div>
            </section>
        </div>
        
        <footer class="footer">
			<div id="copyright" class="footerLeft floatLeft">
				&copy; Copyright 2014 Ministry of Electricity and Water &nbsp;|&nbsp; All Rights Reserved
			</div>
        </footer>
    </div>
</body>

<div id="main-form" style="display:none; margin:20px;" class="floatLeft">
	<form>
		<div>
			<label for="application-number">Application Number</label>
			<input type="text" id="application-number" autofocus maxlength="24" class="text ui-widget-content ui-corner-all" value="20095423" />
			<label for="application-date">Application Date</label>
			<input type="text" id="application-date" autofocus maxlength="10" size="10" class="rid50-datepicker text ui-widget-content ui-corner-all" /><br/>
			
			<label for="owner-name">Owner Name</label>
			<input type="text" id="owner-name" autofocus maxlength="24" class="text ui-widget-content ui-corner-all" />
			<label for="project-name">Project Name</label>
			<input type="text" id="project-name" autofocus maxlength="24" class="text ui-widget-content ui-corner-all" /><br/>

			<label for="area">Area</label>
			<input type="text" id="area" autofocus maxlength="15" size="10" class="text ui-widget-content ui-corner-all" />
			<label for="section">Section</label>
			<input type="text" id="section" autofocus maxlength="5" size="5" class="text ui-widget-content ui-corner-all" />
			<label for="voucher">Voucher</label>
			<input type="text" id="voucher" autofocus maxlength="8" size="8" class="text ui-widget-content ui-corner-all" />
			<label for="construction-exp-date">Expiration Date</label>
			<input type="text" id="construction-exp-date" autofocus maxlength="10" size="10" class="text ui-widget-content ui-corner-all" /><br/>
			
			<label for="project-type">Project Type:</label>
			<input type="radio" id="private-housing" name="project-type" checked />
			<label for="private-housing">Private Housing</label>
			<input type="radio" id="investment" name="project-type" />
			<label for="investment">Investment</label>
			<input type="radio" id="commercial" name="project-type" />
			<label for="commercial">Commercial</label>
			<input type="radio" id="governmental" name="project-type" />
			<label for="governmental">Governmental</label>
			<input type="radio" id="agricultural" name="project-type" />
			<label for="agricultural">Agricultural</label>
			<input type="radio" id="industrial" name="project-type" />
			<label for="industrial">Industrial</label><br/>
			
			<label for="residence-total-area">Total Area</label>
			<input type="text" id="residence-total-area" autofocus  maxlength="5" size="5" class="text ui-widget-content ui-corner-all" />
			<label for="square-meters">m2</label>
			<label for="construction-area">Construction Area</label>
			<input type="text" id="construction-area" autofocus  maxlength="5" size="5" class="text ui-widget-content ui-corner-all" />
			<label for="square-meters">m2</label>
			<label for="conditioning-area">AC Area</label>
			<input type="text" id="conditioning-area" autofocus  maxlength="5" size="5" class="text ui-widget-content ui-corner-all" />
			<label for="square-meters">m2</label><br/>
			
			<label for="current-load">Current Load</label>
			<input type="text" id="current-load" autofocus  maxlength="5" size="5" class="text ui-widget-content ui-corner-all" />
			<label for="kilo-watt">KWT</label>
			<label for="extra-load">Extra Load</label>
			<input type="text" id="extra-load" autofocus  maxlength="5" size="5" class="text ui-widget-content ui-corner-all" />
			<label for="kilo-watt">KWT</label><br/>
			
			<label for="maximum-load-after-delivery">Maximum Load After Delivery</label>
			<input type="text" id="load-after-delivery" autofocus  maxlength="5" size="5" class="text ui-widget-content ui-corner-all" />
			<label for="kilo-watt">KWT</label>
			<label for="conductive-total-load">Conductive Total Load</label>
			<input type="text" id="conductive-total-load" autofocus  maxlength="5" size="5" class="text ui-widget-content ui-corner-all" />
			<label for="kilo-watt">KWT</label><br/>

			<label for="number-supply-points">Number of Supply Points</label>
			<input type="text" id="number-supply-points" autofocus  maxlength="5" size="5" class="text ui-widget-content ui-corner-all" />
			<label for="site-feeding-point">Site Feeding Point:</label>
			<input type="radio" id="vault" name="site-feeding-point" checked />
			<label for="vault">Vault</label>
			<input type="radio" id="ground" name="site-feeding-point" />
			<label for="ground">Ground</label>
			<input type="radio" id="mezzanine" name="site-feeding-point" />
			<label for="mezzanine">Mezzanine</label>
			<input type="radio" id="other" name="site-feeding-point" />
			<label for="other">Other</label><br/>

			<label for="requirements" style="text-decoration:underline">Requirements for the delivery of electricity:</label><br/>
			<input type="radio" id="build" name="requirements" checked />
			<label for="build">Build a room inside a residence</label>
			<input type="radio" id="build2" name="requirements" />
			<label for="build2">Building a room for private secondary transfer station</label><br/>
			<input type="radio" id="build3" name="requirements" />
			<label for="build3">Installing a power factor improvement</label><br/>
				
			<fieldset id="cable-size" style="display:inline">
			<legend>Cable Size(mm2)</legend>
			<!--label for="cable-size">Cable Size(mm2)</label-->
			<input type="radio" id="cs35" name="cable-size" checked />
			<label for="cs35">35</label>
			<input type="radio" id="cs150" name="cable-size" />
			<label for="cs150">150</label>
			<input type="radio" id="cs300" name="cable-size" />
			<label for="cs300">300</label>
			</fieldset>
			
			<fieldset id="fuze" style="display:inline">
			<legend>Fuze(amps)</legend>
			<!--label for="fuze">Fuze(amps)</label-->
			<input type="radio" id="f100" name="fuze" checked />
			<label for="f100">100</label>
			<input type="radio" id="f200" name="fuze" />
			<label for="f200">200</label>
			<input type="radio" id="f300" name="fuze" />
			<label for="f300">300</label>
			</fieldset>
			
			<fieldset id="meter">
			<legend>Meter(amps)</legend>
			<!--label for="meter">Meter(amps)</label-->
			<input type="radio" id="m1" name="meter" checked />
			<label for="m1">S.P40</label>
			<input type="radio" id="m2" name="meter" />
			<label for="m2">T.P50</label>
			<input type="radio" id="m3" name="meter" />
			<label for="m3">T.P75</label>
			<input type="radio" id="m4" name="meter" />
			<label for="m4">T.P125</label>
			<input type="radio" id="m5" name="meter" />
			<label for="m5">T.P200/5</label>
			<input type="radio" id="m6" name="meter" />
			<label for="m6">T.P300/5</label>
			</fieldset><br/>
		
			<table cellspacing="0" cellpadding="0">
				<tr>
					<td style="white-space:nowrap;">
						<label for="switchCapacity">Switch</label>
					</td>
					<td colspan="2">1000
						<label for="kqa">K.Q.A</label>
					</td>
					<td colspan="2">1250
						<label for="kqa">K.Q.A</label>
					</td>
					<td colspan="2">1600
						<label for="kqa">K.Q.A</label>
					</td>
				</tr>
				<tr>
					<td rowspan="2">
						<label for="number">Number</label>
					</td>
					<td rowspan="2">
						<label for="loadAfterDelivery">Load After Delivery</label>
						<label for="summer">Sum</label>&nbsp;&nbsp;&nbsp;KW
					</td>
					<td rowspan="2">
						<label for="meterSize">Meter Size</label>
						<label for="amp">(AMP)</label>
					</td>
					<td rowspan="2">
						<label for="loadAfterDelivery">Load After Delivery</label>
						<label for="summer">Sum</label>&nbsp;&nbsp;&nbsp;KW
					</td>
					<td rowspan="2">
						<label for="meterSize">Meter Size</label>
						<label for="amp">(AMP)</label>
					</td>
					<td rowspan="2">
						<label for="loadAfterDelivery">Load After Delivery</label>
						<label for="summer">Sum</label>&nbsp;&nbsp;&nbsp;KW
					</td>
					<td rowspan="2">
						<label for="meterSize">Meter Size</label>
						<label for="amp">(AMP)</label>
					</td>
				</tr>
				<tr/>
				<tr>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
				</tr>
				<tr>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
				</tr>
				<tr>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
				</tr>
				<tr>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
					<td>
						<input type="text" id="" style="width:80px;" />
					</td>
				</tr>
			</table>
		</div>

	</form>
</div>

<div id="amazingslider" style="display:none; margin-top:60px; margin-left:40px; max-width:700px; float:left; clear:both;">
    
    <!-- Insert to your webpage where you want to display the slider -->
    <div id="amazingslider-1" style="display:block;position:relative;margin:16px auto 32px;">
        <ul class="amazingslider-slides" style="display:none;">
		<!--
            <li><a href="images-slides/Bing Desktop-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop.png" alt="Bing Desktop" data-description="With Bing Desktop, make the Bing homepage image your PC desktop wallpaper each day.
Download now
By clicking download, you agree to the Microsoft Online Privacy Statement and Service Agreement. You'll get future updates to Bing Desktop and other Microsoft products from Microsoft Update. This software may also download and install some updates automatically." /></a></li>
            <li><a href="images-slides/Bing Desktop2-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop2.png" alt="Bing Desktop2" /></a></li>
            <li><a href="images-slides/Bing Desktop3-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop3.png" alt="Bing Desktop3" /></a></li>
            <li><a href="images-slides/Bing Desktop4-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop4.png" alt="Bing Desktop4" /></a></li>
            <li><a href="images-slides/Bing Desktop5-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop5.png" alt="Bing Desktop5" /></a></li>
            <li><a href="images-slides/Bing Desktop6-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop6.png" alt="Bing Desktop6" /></a></li>
            <li><a href="images-slides/Bing Desktop7-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop7.png" alt="Bing Desktop7" /></a></li>
            <li><a href="images-slides/Bing Desktop8-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop8.png" alt="Bing Desktop8" /></a></li>
            <li><a href="images-slides/Bing Desktop9-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop9.png" alt="Bing Desktop9" /></a></li>
            <li><a href="images-slides/Bing Desktop10-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop10.png" alt="Bing Desktop10" /></a></li>
            <li><a href="images-slides/Bing Desktop11-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop11.png" alt="Bing Desktop11" /></a></li>
            <li><a href="images-slides/Bing Desktop12-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop12.png" alt="Bing Desktop12" /></a></li>
            <li><a href="images-slides/Bing Desktop13-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop13.png" alt="Bing Desktop13" /></a></li>
            <li><a href="images-slides/Bing Desktop14-lightbox.png" class="html5lightbox"><img src="images-slides/Bing Desktop14.png" alt="Bing Desktop14" /></a></li>
         -->   
			<li><a href="images-slides/20140213104947335-lightbox.png" class="html5lightbox"><img src="images-slides/20140213104947335.png" alt="الرسم اثنين - قسمة المنزل" /></a></li>
            <li><a href="images-slides/20140213105038910-lightbox.png" class="html5lightbox"><img src="images-slides/20140213105038910.png" alt="رسم واحد - كامل تخطيط الأسلاك تحجيمها" data-description="رسم واحد - كامل تخطيط الأسلاك تحجيمها" /></a></li>
            <li><a href="images-slides/20140213105128933-lightbox.png" class="html5lightbox"><img src="images-slides/20140213105128933.png" alt="رسم" /></a></li>
            <li><a href="images-slides/20140213105203627-lightbox.png" class="html5lightbox"><img src="images-slides/20140213105203627.png" alt="رسم" /></a></li>
            <li><a href="images-slides/20140213105238049-lightbox.png" class="html5lightbox"><img src="images-slides/20140213105238049.png" alt="قطاع شبكات التوزيع الكهربائية" data-description="وزارة الكهرباء والماءطلب ترخيص ايصال تيار كهربائي " /></a></li>
            <li><a href="images-slides/20140213105308681-lightbox.png" class="html5lightbox"><img src="images-slides/20140213105308681.png" alt="قطاع شبكات التوزيع الكهربائية" data-description="وزارة الكهرباء والماءطلب ترخيص ايصال تيار كهربائي " /></a></li>
        </ul>
        <ul class="amazingslider-thumbnails" style="display:none;">
		<!--
            <li><img src="images-slides/Bing Desktop-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop2-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop3-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop4-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop5-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop6-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop7-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop8-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop9-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop10-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop11-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop12-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop13-tn.png" /></li>
            <li><img src="images-slides/Bing Desktop14-tn.png" /></li>
			-->
            <li><img src="images-slides/20140213104947335-tn.png" /></li>
            <li><img src="images-slides/20140213105038910-tn.png" /></li>
            <li><img src="images-slides/20140213105128933-tn.png" /></li>
            <li><img src="images-slides/20140213105203627-tn.png" /></li>
            <li><img src="images-slides/20140213105238049-tn.png" /></li>
            <li><img src="images-slides/20140213105308681-tn.png" /></li>
        </ul>
        <div class="amazingslider-engine" style="display:none;"><a href="http://amazingslider.com">JavaScript Slideshow</a></div>
    </div>
	<!-- End of body section HTML codes -->    
</div>

<div id="divGrid" style="display:none;">
	<form>
		<!--div id="mysearch"></div-->
		<div style="padding-top: 10px; padding-left: 10px; height:24px;">
			<span>Search File#:</span>
			<input type="text" id="grid_search_field" onkeydown="doSearch(arguments[0]||event)" style="direction:ltr; text-align:left; float:none; padding:0;" />
			<button onclick="gridReload()" id="gridSubmitButton">Go</button>
			<input type="checkbox" id="autosearch" onclick="enableAutosubmit(this.checked)" style="padding: 0; float:none; width:auto; border: 0" />
			<span>Enable Autosearch</span>
			<div id="grid_search_hidden_field" style="visibility: hidden; width:10px; height: 10px"></div>
		</div>

		<div id="myjqGrid">
			<div>
				<table id="grid" ></table>
				<div id="pager"></div>
			</div>
			<!--div style="padding-top:10px;">
			<table id="grid_d"></table>
			<div id="pager_d"></div>
			</div-->
		</div>
	</form>
</div>

</html>
