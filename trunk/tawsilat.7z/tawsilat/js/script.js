var lang = "en";
var divVideo;
var divWsq;

$(document).ready(function () {
	$.ajaxSetup({ cache: false, async: false });

	$.blockUI.defaults.message = '<img src="images/ajax-loader.gif"/>';
	$.blockUI.defaults.css.top = '3px';
	$.blockUI.defaults.css.left = '3px';
	$.blockUI.defaults.css.textAlign = 'left';
	$.blockUI.defaults.css.border = 'none';
	$.blockUI.defaults.css.color = 'transparent';
	$.blockUI.defaults.css.backgroundColor = 'transparent';
	$.blockUI.defaults.css.cursor = 'default';
	
	$.blockUI.defaults.overlayCSS.backgroundColor = '#383838';
	$.blockUI.defaults.overlayCSS.opacity = 0.2;
	
	if (navigator.userAgent.match(/msie/i))
		$.blockUI.defaults.overlayCSS.cursor = 'default';

	$.blockUI.defaults.centerX = true;
	$.blockUI.defaults.centerY = true;

	// Ajax activity indicator bound to ajax start/stop document events
	$(document)
		.ajaxStart(function(){
			$.blockUI();
		})
		.ajaxStop(function(){
			$.unblockUI();
		});
/*
	$.get("get_ini.php")
		.done(function(data) {
			idp = data.IdP;
			idpSource = data.IdPSource;
			documentSource = data.documentSource;
			lang = data.lang;
			searchInterval = data.searchInterval;
		});
*/	

	$("#flagKuwait").off("click").on("click", function(event){
		if ($("body[dir='ltr']").length) {
			lang = 'ar';
			//$(videoControl).hide();
			toggleLanguage('ar', 'rtl');
			//$(videoControl).show();
		}
	});

	$("#flagUK").off("click").on("click", function(event){
		if ($("body[dir='rtl']").length) {
			lang = 'en';
			toggleLanguage('en', 'ltr');
		}
	});

	if (lang == "ar") {
		toggleLanguage('ar', 'rtl');
	} else {
		jQuery.i18n.properties({
			name:'Messages', 
			path:'bundle/', 
			mode:'both',
			language: 'en'
		});	
	}

	$(function() {
		$("#accordion").accordion({
			//active: false,
			collapsible: false,
			heightStyle: 'content',
			beforeActivate: function( event, ui ) {
				//try {
					switch (ui.newHeader.index()) {
						case 0:
							//if (!$(videoControl).is(':visible')) {
								if (divWsq == null) {
									$('#divWsq').hide();
									divWsq = $('#divWsq').detach();
								}
								if (divVideo) {
									divVideo.appendTo('#left-section');
									divVideo.show();
									divVideo = null;
									if (videoControl !== undefined)
										videoControl.StartAxVideoControl();
								//	$(videoControl).show();
								}
								//$('#pre_scanned_fingers').show();
							//}
							break;
						case 2:
							if (divVideo == null) {
								if (videoControl !== undefined)
									videoControl.StopAxVideoControl();
									
								$('#divVideo').hide();
								divVideo = $('#divVideo').detach();
							}
								
								//$('#pre_scanned_fingers').hide();
								
							if (divWsq === undefined)
								divWsq = $('#divWsq');
								
							if (divWsq) {
								divWsq.appendTo('#left-section');
								$('#divWsq').show();
								divWsq = null;
							}

								//$(videoControl).hide();
							//}
							break;
					}
				//}catch(e) {}
			}
		});

		$("#takePicture").button({ label: $.i18n.prop('takePicture')});
		$("#getPicture").button({ label: $.i18n.prop('getPicture')});
		
		$("#accordion").bind("keydown", function (event) {
			//var keycode = (event.keyCode ? event.keyCode : (event.which ? event.which : event.charCode));
			var keycode = event.keyCode || event.which;

			if (keycode == 13) {
				//event.stopImmediatePropagation();
				//event.preventDefault();
				//$('#searchButton').click();
				$('#getPicture').triggerHandler( "click" );
				//document.getElementById(btnFocus).click();
			}
        });

		$("#getPicture").on("click", function(event){
			$.blockUI();
			getIt();
			$.unblockUI();
		})
		
		$("#takePicture").on("click", function(){
			$.blockUI();
			takeIt();
			$.unblockUI();
		});
	});
	
	$("#LeftHand, #RightHand, #Thumbs").on("click", function(event){
		
		//var obj = $("input[type='checkbox']:checked");
		//var obj = $("#fingers_to_scan input[type='checkbox']");
		var buttonId = this.id;
		var obj = $(this).parent().siblings().children('input');
		var chBoxesArr = [];
		$.each(obj, function(index, value) {
			chBoxesArr.push(value.checked ? '1' : '0');
		});
		
		//var data = "{" + JSON.stringify(chBoxesArr) + "}";
		//var data = "{\"checkBoxesStates\":" + JSON.stringify(chBoxesArr) + "}";
		var data = "checkBoxesStates=" + chBoxesArr.join();
		//data = null;
		
		//var	url = "http://biooffice/PSCWCFServices/CommandServices.svc/" + buttonId + "/123";
		var url = "http://biooffice:8000/PSCWindowsService/CommandServices/" + buttonId + "/123";
		//var url = "http://localhost:8800/PSCWindowsService/CommandServices?id=123";

	//		if ($('#terms-check').is(":checked")) {

		//var jsonData = {"email": "rid50"};
		//var obj = $("#userList>input");
		
		//[{loginName: obj.val()}]
		//'{"loginName":"' + name + '"}'
		
		//var loginNames = new Array();
		//a.forEach(function(name){
		//	var personInfo = {};
		//	personInfo.loginName = name;
		//	loginNames.push(personInfo);
		//});
		
				
		$.ajax({ 
			type: "get",
			url: url,
			//url: "ASPNetWebService.asmx/" + url,
			//url: 'simpleSAMLSP.php?loginName="roman"&password="roman"',
			//url: 'simpleSAMLSP.php',
			//cache: true,
			//crossDomain: true,
			//async: false,
			//contentType: "application/json; charset=utf-8",
			//contentType: "text/json; charset=utf-8",
			//contentType: "application/x-www-form-urlencoded; charset=UTF-8",

			//contentType: "application/json; charset=utf-8",
			//contentType: "application/xml; charset=utf-8",
			//dataType: "xml",
			dataType: "jsonp",
			data: data,
			//data: { loginNames: json },
			//data: "{\"loginNames\":" + JSON.stringify(json) + "}",
			//data = "{\"loginNames\":" + JSON.stringify(json) + "}",
			//data: {'loginNames':JSON.stringify(json)},
			//data: "{}",
			//processData: false,
			//success: function(data, textStatus) {
			//	alert(data.Status);
			//},
			//error: function(xhr, textStatus, errorThrown){
			//	alert(errorThrown);
			//}
		})	
		.done(function( data ) {
			/*
			var object = JSON.parse(data.d);
			if (object.Error == '') {
				//Alert the persons name
				alert(object.Response);
			}
			*/
			alert(data.Status);
			//alert(eval('data.' + buttonId + 'Result'));
			//var i = 0;
		})
		.fail(function(jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
			//alert(jQuery.parseJSON(jqXHR.responseText));
		});	
	})		
	
	try {
		$('#divVideo').appendTo('#left-section');
		divVideo = null;
		videoControl.StartAxVideoControl();
		//$(videoControl).show();
	} catch(e) { videoControl = undefined;}
	
	$('#main-form').appendTo('#left-section').show();
	var lastRow = $('table tr:last').clone();
	$('table tr:last').after(lastRow);
	lastRow = $('table tr:last').clone();
	$('table tr:last').after(lastRow);
	lastRow = $('table tr:last').clone();
	$('table tr:last').after(lastRow);
	lastRow = $('table tr:last').clone();
	$('table tr:last').after(lastRow);

	
});

function toggleLanguage(lang, dir) {
	var left = $(".floatLeft");
	var right = $(".floatRight");
	var direction = false; 
	$(left).toggleClass("floatLeft", direction);
	$(left).toggleClass("floatRight", !direction);
	$(right).toggleClass("floatRight", direction);
	$(right).toggleClass("floatLeft", !direction);
	$('body').attr('dir', dir);
	$('html').attr('lang', lang);

	jQuery.i18n.properties({
		name:'Messages', 
		path:'bundle/', 
		mode:'both',
		language: lang,
		callback: function() {
		
			$('#copyright').text(jQuery.i18n.prop('copyright'));

			if (dir == 'ltr') {
				//$("#left-section").css("margin", "0 6px 0 0");
				$("#left-section").css("margin-left", "0");
				$("#left-section").css("margin-right", "6px");
				$("#right-section").css("text-align", "right");
				//$("#accordion>span").css("text-align", "right");
				$("#left-section, #right-section").css("box-shadow", "4px 4px 2px #999");
				$(".ui-accordion .ui-accordion-content").css({'padding': '1em 8px 1em 0px'});
				
				$('form input.text').css({'margin':'0 20px 10px 0'});
				$('form input[type="radio"]').css({'margin':'0 0 10px 20px'});
			} else {
				//$("#left-section").css("margin", "0, 0, 0, 6px");
				$("#left-section").css("margin-left", "6px");
				$("#left-section").css("margin-right", "0");
				$("#right-section").css("text-align", "left");
				//$("#accordion>span").css("text-align", "right");				
				$("#left-section, #right-section").css("box-shadow", "-4px 4px 2px #999");
				$(".ui-accordion .ui-accordion-content").css({'padding': '1em 0px 1em 8px'});

				$('form input.text').css({'margin':'0 0 10px 20px'});
				$('form input[type="radio"]').css({'margin':'0 20px 10px 0'});
			}
						
			var obj = $("#accordion>span:nth-child(1)").contents().filter(function() {return this.nodeType == 3;});
			obj.get()[0].textContent = jQuery.i18n.prop('application');
			$("#accordion>div>div:first>span").text(jQuery.i18n.prop('application'));
			//$("#getPicture").button({ label: $.i18n.prop('getPicture')});

			obj = $("#accordion>span:nth-child(3)").contents().filter(function() {return this.nodeType == 3;});
			obj.get()[0].textContent = jQuery.i18n.prop('signatures');
			$("#signButton").button({ label: $.i18n.prop('sign')});
			$("#signButton").attr({title: jQuery.i18n.prop('signDocument')});
			
			$('label[for="application-number"]').html($.i18n.prop('applicationNumber'));
			$('label[for="application-date"]').html($.i18n.prop('applicationDate'));
			$('label[for="owner-name"]').html($.i18n.prop('ownerName'));
			$('label[for="project-name"]').html($.i18n.prop('projectName'));
			$('label[for="area"]').html($.i18n.prop('area'));
			$('label[for="section"]').html($.i18n.prop('section'));
			$('label[for="voucher"]').html($.i18n.prop('voucher'));
			$('label[for="construction-exp-date"]').html($.i18n.prop('constructionExpDate'));

			$('label[for="project-type"]').html($.i18n.prop('projectType'));
			$('label[for="private-housing"]').html($.i18n.prop('privateHousing'));
			$('label[for="investment"]').text($.i18n.prop('investment'));
			$('label[for="commercial"]').text($.i18n.prop('commercial'));
			$('label[for="governmental"]').text($.i18n.prop('governmental'));
			$('label[for="agricultural"]').text($.i18n.prop('agricultural'));
			$('label[for="industrial"]').text($.i18n.prop('industrial'));

			$('label[for="residence-total-area"]').text($.i18n.prop('residenceTotalArea'));
			$('label[for="construction-area"]').text($.i18n.prop('constructionArea'));
			$('label[for="conditioning-area"]').text($.i18n.prop('conditioningArea'));
			$('label[for="square-meters"]').text($.i18n.prop('squareMeters'));			
			
			$('label[for="current-load"]').text($.i18n.prop('currentLoad'));
			$('label[for="extra-load"]').text($.i18n.prop('extraLoad'));
			$('label[for="kilo-watt"]').text($.i18n.prop('kiloWatt'));			

			$('label[for="maximum-load-after-delivery"]').text($.i18n.prop('maximumLoadAfterDelivery'));
			$('label[for="conductive-total-load"]').text($.i18n.prop('conductiveTotalLoad'));

			$('label[for="number-supply-points"]').text($.i18n.prop('numberOfSupplyPoints'));
			$('label[for="site-feeding-point"]').text($.i18n.prop('siteFeedingPoint'));
			$('label[for="vault"]').text($.i18n.prop('vault'));
			$('label[for="ground"]').text($.i18n.prop('ground'));
			$('label[for="mezzanine"]').text($.i18n.prop('mezzanine'));
			$('label[for="other"]').text($.i18n.prop('other'));

			$('label[for="requirements"]').text($.i18n.prop('requirements'));
			$('label[for="build"]').text($.i18n.prop('build'));
			$('label[for="build2"]').text($.i18n.prop('build2'));
			$('label[for="build3"]').text($.i18n.prop('build3'));

			$('#cable-size legend').html($.i18n.prop('cableSize'));
			$('#fuze legend').html($.i18n.prop('fuze'));
			$('#meter legend').html($.i18n.prop('meter'));
			
			$('label[for="switchCapacity"]').text($.i18n.prop('switchCapacity'));
			$('label[for="kqa"]').text($.i18n.prop('kqa'));
			$('label[for="number"]').text($.i18n.prop('number'));
			$('label[for="loadAfterDelivery"]').text($.i18n.prop('loadAfterDelivery'));
			$('label[for="summer"]').text($.i18n.prop('summer'));
			$('label[for="meterSize"]').text($.i18n.prop('meterSize'));
			$('label[for="amp"]').text($.i18n.prop('amp'));
			
		}				
	});
}

function startVideo() {
	if (videoControl !== undefined)
		videoControl.StartAxVideoControl();
	//document.videoControl.Background = "#e8e8e8";
	//videoControl.MyTitle = form1.txt.value;
	//document.videoControl.Open();
}

function stopVideo() {
	if (videoControl !== undefined)
		videoControl.StopAxVideoControl();
	//document.videoControl.Background = "#e8e8e8";
	//videoControl.MyTitle = form1.txt.value;
	//document.videoControl.Open();
}

function getIt() {
	//videoControl.StopAxVideoControl();
	//videoControl.UserId = $('#user_id').val();
	//videoControl.GetIt();
	if (videoControl !== undefined)
		videoControl.GetIt($('#user_id').val());
		
		var urlImg = 'ImageHandler/ImageHandler.ashx';
		var id = $('#user_id').val();
		(function() {
			$('.wsq').each(function () {
				$(this).prop('src', urlImg + '?wsq=' + $(this).prop('id') + '&id=' + id);
			});		
		})();
		
	//document.videoControl.Background = "#e8e8e8";
	//videoControl.MyTitle = form1.txt.value;
	//document.videoControl.Open();
}

function takeIt() {
	//videoControl.StopAxVideoControl();
	//videoControl.UserId = $('#user_id').val();
	//videoControl.GetIt();
	if (videoControl !== undefined)
		videoControl.TakeIt($('#user_id').val());
	//document.videoControl.Background = "#e8e8e8";
	//videoControl.MyTitle = form1.txt.value;
	//document.videoControl.Open();
}
