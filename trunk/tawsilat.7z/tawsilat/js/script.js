var idp, idpSource;
var documentSource;
var lang;
var searchInterval;

var userInfo;

$(document).ready(function () {
	$.ajaxSetup({ cache: false, async: false });

	$.blockUI.defaults.message = '<img src="images/ajax-loader.gif"/>';
	$.blockUI.defaults.css.top = '3px';
	$.blockUI.defaults.css.left = '3px';
	$.blockUI.defaults.css.textAlign = 'left';
	$.blockUI.defaults.css.border = 'none';
	$.blockUI.defaults.css.color = 'transparent';
	$.blockUI.defaults.css.backgroundColor = 'transparent';
	$.blockUI.defaults.css.cursor = 'default';
	
	$.blockUI.defaults.overlayCSS.backgroundColor = '#383838';
	$.blockUI.defaults.overlayCSS.opacity = 0.2;
	
	if (navigator.userAgent.match(/msie/i))
		$.blockUI.defaults.overlayCSS.cursor = 'default';

	$.blockUI.defaults.centerX = true;
	$.blockUI.defaults.centerY = true;

	// Ajax activity indicator bound to ajax start/stop document events
	$(document)
		.ajaxStart(function(){
			$.blockUI();
		})
		.ajaxStop(function(){
			$.unblockUI();
		});

	$.get("get_ini.php")
		.done(function(data) {
			idp = data.IdP;
			idpSource = data.IdPSource;
			documentSource = data.documentSource;
			lang = data.lang;
			searchInterval = data.searchInterval;
		});
	

	$("#flagKuwait").off("click").on("click", function(event){
		if ($("body[dir='ltr']").length) {
			lang = 'ar';
			//$(videoControl).hide();
			toggleLanguage('ar', 'rtl');
			//$(videoControl).show();
		}
	});

	$("#flagUK").off("click").on("click", function(event){
		if ($("body[dir='rtl']").length) {
			lang = 'en';
			toggleLanguage('en', 'ltr');
		}
	});

	$.datepicker.setDefaults( $.datepicker.regional[ "" ] );
	$.datepicker.setDefaults({
		//regional: "",
		showOn: "both",
		buttonImageOnly: true,
		buttonImage: "images/calendar.gif",
		buttonText: "Calendar",
		//changeMonth: 'true',
		//changeYear: 'true'
	});
	
	$(".rid50-datepicker").datepicker({
		changeMonth: true,
		changeYear: true,
		dateFormat: "dd/mm/yy",
	});
	
	$("#application-date").datepicker( "setDate", "now" );
	$('input[id="application-date"]').change(function() {
		var regExpPattern = /^(0[1-9]|[12][0-9]|3[01])[/](0[1-9]|1[012])[/](19|20)\d\d$/;
		if (!$(this).val().match(regExpPattern)) {
			$(this).addClass( "ui-state-error" );
			$("#searchButton").attr('disabled', 'disabled');
		} else {
			$(this).removeClass( "ui-state-error" );
			$("#searchButton").removeAttr("disabled");
		}
	});
	
	if (lang == "ar") {
		toggleLanguage('ar', 'rtl');
	} else {
		jQuery.i18n.properties({
			name:'Messages', 
			path:'bundle/', 
			mode:'both',
			language: 'en'
		});	
	}

	$(function() {
		var divGrid = $('#divGrid'), main_form = $('#main-form'), amazingslider = $('#amazingslider');
		$('.amazingslider-watermark-0').hide();
		$('.amazingslider-bullet-wrapper-0').attr({dir: 'ltr'});

		//main_form.appendTo('#left-section');
		//amazingslider.appendTo('#left-section');
		$("#accordion").accordion({
			//active: false,
			collapsible: false,
			heightStyle: 'content',
			beforeActivate: function( event, ui ) {
				switch (ui.newHeader.index()) {
					case 0:
						divGrid.show();
						main_form.hide();
						amazingslider.hide();
						break;
					case 2:
						main_form.show();
						divGrid.hide();
						amazingslider.hide();
						break;
					case 6:
						amazingslider.show();
						divGrid.hide();
						main_form.hide();
						break;
				}
			}
		});

		$("#accordion").bind("keydown", function (event) {
			//var keycode = (event.keyCode ? event.keyCode : (event.which ? event.which : event.charCode));
			var keycode = event.keyCode || event.which;

			if (keycode == 13) {
				//event.stopImmediatePropagation();
				//event.preventDefault();
				//$('#searchButton').click();
				$('#getPicture').triggerHandler( "click" );
				//document.getElementById(btnFocus).click();
			}
        });

		$("#getPicture").on("click", function(event){
			$.blockUI();
			getIt();
			$.unblockUI();
		})
		
		$("#takePicture").on("click", function(){
			$.blockUI();
			takeIt();
			$.unblockUI();
		});
	});
	
	$("#LeftHand, #RightHand, #Thumbs").on("click", function(event){
		
		//var obj = $("input[type='checkbox']:checked");
		//var obj = $("#fingers_to_scan input[type='checkbox']");
		var buttonId = this.id;
		var obj = $(this).parent().siblings().children('input');
		var chBoxesArr = [];
		$.each(obj, function(index, value) {
			chBoxesArr.push(value.checked ? '1' : '0');
		});
		
		//var data = "{" + JSON.stringify(chBoxesArr) + "}";
		//var data = "{\"checkBoxesStates\":" + JSON.stringify(chBoxesArr) + "}";
		var data = "checkBoxesStates=" + chBoxesArr.join();
		//data = null;
		
		//var	url = "http://biooffice/PSCWCFServices/CommandServices.svc/" + buttonId + "/123";
		var url = "http://biooffice:8000/PSCWindowsService/CommandServices/" + buttonId + "/123";
		//var url = "http://localhost:8800/PSCWindowsService/CommandServices?id=123";

	//		if ($('#terms-check').is(":checked")) {

		//var jsonData = {"email": "rid50"};
		//var obj = $("#userList>input");
		
		//[{loginName: obj.val()}]
		//'{"loginName":"' + name + '"}'
		
		//var loginNames = new Array();
		//a.forEach(function(name){
		//	var personInfo = {};
		//	personInfo.loginName = name;
		//	loginNames.push(personInfo);
		//});
		
				
		$.ajax({ 
			type: "get",
			url: url,
			//url: "ASPNetWebService.asmx/" + url,
			//url: 'simpleSAMLSP.php?loginName="roman"&password="roman"',
			//url: 'simpleSAMLSP.php',
			//cache: true,
			//crossDomain: true,
			//async: false,
			//contentType: "application/json; charset=utf-8",
			//contentType: "text/json; charset=utf-8",
			//contentType: "application/x-www-form-urlencoded; charset=UTF-8",

			//contentType: "application/json; charset=utf-8",
			//contentType: "application/xml; charset=utf-8",
			//dataType: "xml",
			dataType: "jsonp",
			data: data,
			//data: { loginNames: json },
			//data: "{\"loginNames\":" + JSON.stringify(json) + "}",
			//data = "{\"loginNames\":" + JSON.stringify(json) + "}",
			//data: {'loginNames':JSON.stringify(json)},
			//data: "{}",
			//processData: false,
			//success: function(data, textStatus) {
			//	alert(data.Status);
			//},
			//error: function(xhr, textStatus, errorThrown){
			//	alert(errorThrown);
			//}
		})	
		.done(function( data ) {
			/*
			var object = JSON.parse(data.d);
			if (object.Error == '') {
				//Alert the persons name
				alert(object.Response);
			}
			*/
			alert(data.Status);
			//alert(eval('data.' + buttonId + 'Result'));
			//var i = 0;
		})
		.fail(function(jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
			//alert(jQuery.parseJSON(jqXHR.responseText));
		});	
	})		
	
	//$('#main-form').appendTo('#left-section').show();
	
	var lastRow = $('table tr:last').clone();
	$('table tr:last').after(lastRow);
	lastRow = $('table tr:last').clone();
	$('table tr:last').after(lastRow);
	lastRow = $('table tr:last').clone();
	$('table tr:last').after(lastRow);
	lastRow = $('table tr:last').clone();
	$('table tr:last').after(lastRow);

    //$grid = $('#myjqGrid');
	$("#left-section").append($("#divGrid"));
	$("#left-section").append($("#main-form"));
	$("#left-section").append($("#amazingslider"));

	if ($("#divGrid").css("display") == "none") {
		toggleGrid(lang);
		$("#divGrid").show();
	}

});

function toggleLanguage(lang, dir) {
	var left = $(".floatLeft");
	var right = $(".floatRight");
	var direction = false; 
	$(left).toggleClass("floatLeft", direction);
	$(left).toggleClass("floatRight", !direction);
	$(right).toggleClass("floatRight", direction);
	$(right).toggleClass("floatLeft", !direction);
	$('body').attr('dir', dir);
	$('html').attr('lang', lang);

	jQuery.i18n.properties({
		name:'Messages', 
		path:'bundle/', 
		mode:'both',
		language: lang,
		callback: function() {
		
			toggleGrid(lang);

			$('#copyright').text(jQuery.i18n.prop('Copyright'));

			if (dir == 'ltr') {
				$.datepicker.setDefaults( $.datepicker.regional[ lang == "en" ? "" : lang ] );
				$(".rid50-datepicker").datepicker("option", "changeMonth", lang == "en" ? true : false);
			
				//$("#left-section").css("margin", "0 6px 0 0");
				$("#left-section").css("margin-left", "0");
				$("#left-section").css("margin-right", "6px");
				$("#right-section").css("text-align", "right");
				//$("#accordion>span").css("text-align", "right");
				$("#left-section, #right-section").css("box-shadow", "4px 4px 2px #999");
				$(".ui-accordion .ui-accordion-content").css({'padding': '1em 8px 1em 0px'});
				
				$('form input.text').css({'margin':'0 20px 10px 0'});
				$('form input[type="radio"]').css({'margin':'0 0 10px 20px'});
			} else {
				//$("#left-section").css("margin", "0, 0, 0, 6px");
				$("#left-section").css("margin-left", "6px");
				$("#left-section").css("margin-right", "0");
				$("#right-section").css("text-align", "left");
				//$("#accordion>span").css("text-align", "right");				
				$("#left-section, #right-section").css("box-shadow", "-4px 4px 2px #999");
				$(".ui-accordion .ui-accordion-content").css({'padding': '1em 0px 1em 8px'});

				$('form input.text').css({'margin':'0 0 10px 20px'});
				$('form input[type="radio"]').css({'margin':'0 20px 10px 0'});

				$(".rid50-datepicker").datepicker("option", "changeMonth", lang == "en" ? true : false);
				$.datepicker.setDefaults( $.datepicker.regional[ lang == "en" ? "" : lang ] );
			}
						
			$($("#divGrid>form>div:first:nth-child(1)>span")[0]).text(($.i18n.prop('SearchByFileNumber')));
			$($("#divGrid>form>div:first:nth-child(1)>span")[1]).text(($.i18n.prop('EnableAutosearch')));
			$('#gridSubmitButton').button({ label: $.i18n.prop('Go')});
						
			var obj = $("#accordion>span:nth-child(1)").contents().filter(function() {return this.nodeType == 3;});
			obj.get()[0].textContent = jQuery.i18n.prop('Application');
			$("#accordion>div>div:first>span").text(jQuery.i18n.prop('Application'));
			//$("#getPicture").button({ label: $.i18n.prop('getPicture')});

			obj = $("#accordion>span:nth-child(3)").contents().filter(function() {return this.nodeType == 3;});
			obj.get()[0].textContent = jQuery.i18n.prop('Form');

			obj = $("#accordion>span:nth-child(5)").contents().filter(function() {return this.nodeType == 3;});
			obj.get()[0].textContent = jQuery.i18n.prop('Signatures');
			$("#signButton").button({ label: $.i18n.prop('Sign')});
			$("#signButton").attr({title: jQuery.i18n.prop('SignDocument')});

			obj = $("#accordion>span:nth-child(7)").contents().filter(function() {return this.nodeType == 3;});
			obj.get()[0].textContent = jQuery.i18n.prop('Drawings');
			
			$('label[for="application-number"]').html($.i18n.prop('ApplicationNumber'));
			$('label[for="application-date"]').html($.i18n.prop('ApplicationDate'));
			$('label[for="owner-name"]').html($.i18n.prop('OwnerName'));
			$('label[for="project-name"]').html($.i18n.prop('ProjectName'));
			$('label[for="area"]').html($.i18n.prop('Area'));
			$('label[for="section"]').html($.i18n.prop('Section'));
			$('label[for="voucher"]').html($.i18n.prop('Voucher'));
			$('label[for="construction-exp-date"]').html($.i18n.prop('ConstructionExpDate'));

			$('label[for="project-type"]').html($.i18n.prop('ProjectType'));
			$('label[for="private-housing"]').html($.i18n.prop('PrivateHousing'));
			$('label[for="investment"]').text($.i18n.prop('Investment'));
			$('label[for="commercial"]').text($.i18n.prop('Commercial'));
			$('label[for="governmental"]').text($.i18n.prop('Governmental'));
			$('label[for="agricultural"]').text($.i18n.prop('Agricultural'));
			$('label[for="industrial"]').text($.i18n.prop('Industrial'));

			$('label[for="residence-total-area"]').text($.i18n.prop('ResidenceTotalArea'));
			$('label[for="construction-area"]').text($.i18n.prop('ConstructionArea'));
			$('label[for="conditioning-area"]').text($.i18n.prop('ConditioningArea'));
			$('label[for="square-meters"]').text($.i18n.prop('SquareMeters'));			
			
			$('label[for="current-load"]').text($.i18n.prop('CurrentLoad'));
			$('label[for="extra-load"]').text($.i18n.prop('ExtraLoad'));
			$('label[for="kilo-watt"]').text($.i18n.prop('KiloWatt'));			

			$('label[for="maximum-load-after-delivery"]').text($.i18n.prop('MaximumLoadAfterDelivery'));
			$('label[for="conductive-total-load"]').text($.i18n.prop('ConductiveTotalLoad'));

			$('label[for="number-supply-points"]').text($.i18n.prop('NumberOfSupplyPoints'));
			$('label[for="site-feeding-point"]').text($.i18n.prop('SiteFeedingPoint'));
			$('label[for="vault"]').text($.i18n.prop('Vault'));
			$('label[for="ground"]').text($.i18n.prop('Ground'));
			$('label[for="mezzanine"]').text($.i18n.prop('Mezzanine'));
			$('label[for="other"]').text($.i18n.prop('Other'));

			$('label[for="requirements"]').text($.i18n.prop('Requirements'));
			$('label[for="build"]').text($.i18n.prop('Build'));
			$('label[for="build2"]').text($.i18n.prop('Build2'));
			$('label[for="build3"]').text($.i18n.prop('Build3'));

			$('#cable-size legend').html($.i18n.prop('CableSize'));
			$('#fuze legend').html($.i18n.prop('Fuze'));
			$('#meter legend').html($.i18n.prop('Meter'));
			
			$('label[for="switchCapacity"]').text($.i18n.prop('SwitchCapacity'));
			$('label[for="kqa"]').text($.i18n.prop('Kqa'));
			$('label[for="number"]').text($.i18n.prop('Number'));
			$('label[for="loadAfterDelivery"]').text($.i18n.prop('LoadAfterDelivery'));
			$('label[for="summer"]').text($.i18n.prop('Summer'));
			$('label[for="meterSize"]').text($.i18n.prop('MeterSize'));
			$('label[for="amp"]').text($.i18n.prop('Amp'));
			
		}				
	});
}
