﻿/*
	(function($){
		$.jgrid = {
			defaults : {
				//recordtext: "View!!!!!!! {0} - {1} of {2}",
				//emptyrecords: "No records to view",
				//loadtext: "Loading...",
				//pgtext : "Page#### {0} of {1}"
			},
		}
	})(jQuery);
*/

//$(document).ready(function () {
//    CheckupGrid.setupGrid($("#grid"), $("#pager"), $("#search"), (lang == 'en') ? 'ltr' : 'rtl');
//});
var myCustomSearch;

function toggleGrid(lang) {
	//$(".tagButton").text($.i18n.prop('Checkup'));
	var jgrid = $('#grid');
	jgrid.jqGrid('GridUnload');
	if ($.jgrid.hasOwnProperty("regional") && $.jgrid.regional.hasOwnProperty(lang))
		$.extend($.jgrid,$.jgrid.regional[lang]);

	Grid.setupGrid($("#grid"), $("#pager"), $("#grid_search_field"), (lang == 'en') ? 'ltr' : 'rtl');
	//CheckupGrid.setupGrid($("#grid"), $("#pager"), $("#mysearch"), (lang == 'en') ? 'ltr' : 'rtl');
}

Grid = {
    setupGrid: function (grid, pager, search, direction) {
        //        debugger; 
        grid.jqGrid({
			direction: direction,
            url: "json_db_crud_pdo.php",
			postData:{"func": "getApps"},
            mtype: "get",
            datatype: "json",
            colNames: [$.i18n.prop('ApplicationNumber'), $.i18n.prop('ApplicationDate'), $.i18n.prop('OwnerName'), $.i18n.prop('ProjectName'), $.i18n.prop('Area')],
            colModel: [ //http://php.net/manual/en/function.date.php
                        {name: 'ApplicationNumber', index: 'ApplicationNumber', align: 'left', width: '120px', sortable: true, resizable: true, frozen: true },
                        {name: 'ApplicationDate', index: 'ApplicationDate', align: 'center', width: '100px', sortable: true, hidden: false, resizable: false, sorttype: 'date', formatter: 'date', formatoptions: { srcformat: 'Y-m-d', newformat: 'd-M-Y'} }, //DateEntry (src) = "12/31/1999 00:00:00"
                        {name: 'OwnerName', index: 'OwnerName', align: 'right', width: '140px', sortable: true, editable: false, resizable: false },
                        {name: 'ProjectName', index: 'ProjectName', align: 'right', width: '120px', sortable: true, editable: false, resizable: true },
                        {name: 'AreaName', index: 'AreaName', align: 'right', width: '120px', sortable: true, editable: false, resizable: false, searchoptions: { sopt: ['bw']} },
                      ],
            rowNum: 15,
            rowList: [15, 30, 45],
			altclass: 'gridAltRows',
			altRows: true,
            loadui: "block",
			hidegrid: false,
            pager: pager,
            sortname: 'ApplicationNumber',
            sortorder: "asc",
            viewrecords: true,
            width: 720,
            height: '455px',
            shrinkToFit: false,
            autowidth: false,
            rownumbers: true,
            caption: $.i18n.prop('Application'),
            toppager: false,
			gridComplete:  function() {
				//jQuery("#grid").jqGrid('setFrozenColumns');
			},
			afterInsertRow: function(rowid, rowdata, rowelem) {
			},			
            loadError: function (xhr, st, err) {
                if (window.console) window.console.log('failed');
				alert ("Type: " + st + "; Response: " + xhr.status + " " + xhr.statusText);
                $('#alertContent').html("Type: " + st + "; Response: " + xhr.status + " " + xhr.statusText);
                $('#alert').dialog('open');
            },
            loadComplete: function (event) {
                if (event && event[0] && event[0].error != "") {
					if (window.console) window.console.log(event[0].error);
					alert (event[0].error);
				}
            },
            onSelectRow: function (ids) {
            }
            //        }).jqGrid('navGrid', pager, { edit: true, add: false, del: false, search: false, refresh: true });
        }).navGrid("#pager", { view: true, edit: false, add: false, del: false, search: true, refresh: true },
                            {}, // settings for edit
                            {}, // settings for add
                            {}, // settings for delete
							{
								closeOnEscape:true, 
								onClose: function(){
									delete jQuery('#grid').jqGrid('getGridParam' ,'postData' )['searchField'];
									delete jQuery('#grid').jqGrid('getGridParam' ,'postData' )['searchString'];
									delete jQuery('#grid').jqGrid('getGridParam' ,'postData' )['searchOper'];
								}
							}  // search options
                            //{sopt: ["cn"]} // Search options. Some options can be set on column level        
        );
    }
};

        var timeoutHnd = null;
        var flAuto = false;
        function doSearch(e) {
            if (timeoutHnd) {
                clearTimeout(timeoutHnd)
				timeoutHnd = null;
            }
			
            if (e.keyCode == 13) {
                timeoutHnd = setTimeout(gridReload, 500);
                return;
            }
            if (!flAuto) return;
            // var elem = ev.target||ev.srcElement;
            //if (timeoutHnd) {
            //    clearTimeout(timeoutHnd)
            //}
			
			//var keyCode = (e.keyCode ? e.keyCode : (e.which ? e.which : e.charCode));
			var keyCode = e.keyCode || e.which;

			// 65-90 	: A to Z
			// 8 		: Backspace
			// 46		: Delete
			// 48-57	: 0 to 9
			// 96-105	: 0 to 9 (Numpad)
            //if ((ev.keyCode >= 65 && ev.keyCode <= 90) || ev.keyCode == 8 || ev.keyCode == 46 || (ev.keyCode >= 48 && ev.keyCode <= 57) || (ev.keyCode >= 96 && ev.keyCode <= 105)) {
            if ((keyCode >= 65 && keyCode <= 90) || keyCode == 8 || keyCode == 46 || (keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105)) {
                timeoutHnd = setTimeout(gridReload, 500)
            }
        }
        function gridReload() {
            if (timeoutHnd) {
                clearTimeout(timeoutHnd);
				timeoutHnd = null;
            }

			if ($('#grid').jqGrid('getGridParam' ,'postData' ) != undefined) {
				$('#grid').jqGrid('setGridParam',{postData:{'searchField':'file_no'} });
				$('#grid').jqGrid('setGridParam',{postData:{'searchString':$('#grid_search_field').val()} });
				$('#grid').jqGrid('setGridParam',{postData:{'searchOper':'bw'} });
				
				//$($("#grid").navGrid("#pager")[0]).prop('p').postData.searchField = "file_no";
				//$($("#grid").navGrid("#pager")[0]).prop('p').postData.searchString = $('#grid_search_field').val();
				//$($("#grid").navGrid("#pager")[0]).prop('p').postData.searchOper = "bw";
				jQuery("#grid").trigger("reloadGrid");

				delete jQuery('#grid').jqGrid('getGridParam' ,'postData' )['searchField'];
				delete jQuery('#grid').jqGrid('getGridParam' ,'postData' )['searchString'];
				delete jQuery('#grid').jqGrid('getGridParam' ,'postData' )['searchOper'];
			}

            //var searchField = "file_no";
            //var searchString = $('#grid_search_field').val();
			//var searchOper = "bw";
			
			//myCustomSearch.triggerSearch();
			
			//jQuery("#grid").jqGrid('searchGrid', options );

			
            //jQuery("#grid").setGridParam({ url: "json_db_crud_pdo.php?searchField=" + searchField + "&searchString=" + searchString + "&searchOper=" + searchOper, page: 1 }).trigger("reloadGrid");
			//jQuery("#grid").setGridParam({ url: "json_db_crud_pdo.php", page: 1 });

			//$("#grid").jqGrid("setColProp", "file_no", { searchoptions: { sopt: ['cn']} }).trigger("reloadGrid");
            //jQuery("#grid").setGridParam({ url: "Checkup/List?search=" + search, page: 1 }).trigger("reloadGrid");
        }

        function enableAutosubmit(state) {
            flAuto = state;
            jQuery("#gridSubmitButton").attr("disabled", state);
			$('#griid_search_field').focus();
        } 