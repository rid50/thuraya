using System;
using System.Collections.Generic;
using System.Text;

using System.Xml;
using System.Security.Principal;

namespace ImageScanner
{
    class ValidationServicesHelper
    {
        public static void ValidateCivilId(String civilId, char localizationCode)
        {
            ValidationService.PTValidationUtils proxy = new ValidationService.PTValidationUtils();
            proxy.PreAuthenticate = true;
            proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;

            try
            {
                proxy.ValidateCivilId(civilId, localizationCode);
            }
            catch (System.Web.Services.Protocols.SoapException sex)
            {
                String errorMessage = sex.Message;
                if (sex.Detail != null)
                {
                    XmlNode node = sex.Detail.SelectSingleNode("error");
                    if (node != null)
                        errorMessage = node.Attributes["errorMessage"].Value;
                }

                throw new Exception(errorMessage);
            }
        }
    }
}
