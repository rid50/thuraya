﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Forms;

namespace ImageScanner
{
    partial class TwainForm
    {
        bool _error = false;

        internal void startScanProcess()
        {
            if (backgroundWorkerScan.IsBusy)
                return;

            backgroundWorkerScan.RunWorkerAsync();
        }

        private void backgroundWorkerScan_DoWork(object sender, DoWorkEventArgs e)
        {
            short retCode = tw.Acquire();
            if (retCode != 0)
            {
//                EndingScan();
                _error = true;
            }
            else
                _error = false;
        }

        private void backgroundWorkerScan_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (_error)
            {
                EndingScan();
                tw.CloseSrc();
                _mainForm.toolStripStatusLabelError.Text = "Error while scan is in process";
                _mainForm.stopProgressBar();
                _mainForm.Cursor = Cursors.Default;
                _mainForm.enableButtons(true);
            }
        }
    }
}
