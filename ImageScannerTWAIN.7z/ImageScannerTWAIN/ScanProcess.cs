﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Forms;

namespace ImageScanner
{
    partial class Form1
    {
        bool _error = false;

        void startScanProcess()
        {
            if (backgroundWorkerScan.IsBusy)
                return;

            backgroundWorkerScan.RunWorkerAsync();
        }

        private void backgroundWorkerScan_DoWork(object sender, DoWorkEventArgs e)
        {

            short retCode = tw.Acquire();
            if (retCode != 0)
            {
                EndingScan();
                _error = true;
            }
            else
                _error = false;
        }

        private void backgroundWorkerScan_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (_error)
                toolStripStatusLabelError.Text = "Error while scan is in process";

            stopProgressBar();
            this.Cursor = Cursors.Default;
            //btnScan.Enabled = true;
        }

    }
}
