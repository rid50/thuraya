//#define SHOW_TREAHD_IDS

using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using ImageScanner;
using System.Reflection;

namespace TwainLib
{
/*
    public enum TwainCommand
    {
        Not = -1,
        Null = 0,
        TransferReady = 1,
        CloseRequest = 2,
        CloseOk = 3,
        DeviceEvent = 4
    }
*/
    public partial class Twain : IDisposable
    {
        private const short CountryUSA = 1;
        private const short LanguageUSA = 13;

        public event EventHandler<TwainOperationCompleteEventArgs> TwainOperationComplete;
        public event EventHandler<TwainOperationCompleteEventArgs> TwainInitOrSelectComplete;
        //public event EventHandler<TwainOperationCompleteEventArgs> TwainSelectSourceComplete;
        public event EventHandler<TransferImageEventArgs> TransferImage;

        TwEvent _eventMessage;
        WindowMessageHook _messageFilter;
        WINMSG _winMessage;

        Form1 _mainForm;

        public Twain(WindowMessageHook messageFilter, Form1 mainForm)
        {
            _mainForm = mainForm;
            DisplayCurrentThreadId("twainlib");

            appid = new TwIdentity();
            appid.Id = IntPtr.Zero;
            appid.Version.MajorNum = 1;
            appid.Version.MinorNum = 1;
            appid.Version.Language = LanguageUSA;
            appid.Version.Country = CountryUSA;
            appid.Version.Info = Assembly.GetExecutingAssembly().FullName;
            appid.ProtocolMajor = TwProtocol.Major;
            appid.ProtocolMinor = TwProtocol.Minor;
            appid.SupportedGroups = (int)(TwDG.Image | TwDG.Control);
            appid.Manufacturer = "MEW";
            appid.ProductFamily = "Freeware";
            appid.ProductName = "ImageScanner";

            srcds = new TwIdentity();
            srcds.Id = IntPtr.Zero;

            dsmstat = new TwStatus();

            hwnd = IntPtr.Zero;

            _eventMessage.EventPtr = Marshal.AllocHGlobal(Marshal.SizeOf(_winMessage));

            _messageFilter = messageFilter;
            _messageFilter.FilterMessageFunc = FilterMessage;
            //TransferImage += delegate { };

            //Init(f.Handle);
        }

        ~Twain()
        {
            Dispose();

//            Marshal.FreeHGlobal(evtmsg.EventPtr);
        }

        internal Form1 MainForm
        {
            get
            {
                return _mainForm;
            }
            set
            {
                _mainForm = value;
            }
        }

        internal static TwIdentity ApplicationId
        {
            get
            {
                return appid;
            }
        }

        internal static TwIdentity DataSource
        {
            get
            {
                return srcds;
            }
        }


        internal void DisplayCurrentThreadId(string funcName)
        {
#if SHOW_TREAHD_IDS
            string currThread = System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();
            MainForm.GetSynchronizationContext.Send(
                delegate {
                    MainForm.toolStripStatusLabelError.Text += currThread + " " + funcName + " | "; 
                }, null);
#endif
        }

        public String getInfo()
        {
            return _infoMessage;
        }

        public void InitLib(IntPtr hwnd)
        {
            //IntPtr hwnd = IntPtr.Zero;
            var args = new TwainOperationCompleteEventArgs(Init(hwnd) != 0 ? true : false);
            TwainInitOrSelectComplete(this, args);
        }

        private short Init(IntPtr hwndp)
        {
            DisplayCurrentThreadId("init"); 
            
            short retCode = 0;

            Finish();

            TwRC rc = DSMparent(appid, IntPtr.Zero, TwDG.Control, TwDAT.Parent, TwMSG.OpenDSM, ref hwndp);
            if (rc == TwRC.Success)
            {
                rc = DSMident(appid, IntPtr.Zero, TwDG.Control, TwDAT.Identity, TwMSG.GetDefault, srcds);
                if (rc == TwRC.Success)
                {
                    hwnd = hwndp;
                    _infoMessage = srcds.ProductName;
                }
                else
                {
                    DSMstatus(appid, IntPtr.Zero, TwDG.Control, TwDAT.Status, TwMSG.Get, dsmstat);
                    retCode = (short)dsmstat.ConditionCode;
                    if (retCode == (short)TwCC.NoDS)
                        _infoMessage = "No Image Source installed";
                    else
                        _infoMessage = "There is a problem with an Image Source. Call Support Center.";

                    rc = DSMparent(appid, IntPtr.Zero, TwDG.Control, TwDAT.Parent, TwMSG.CloseDSM, ref hwndp);
                }
            }

            return retCode;
        }


        public void SelectSource(IntPtr hwnd)
        {
            //IntPtr hwnd = IntPtr.Zero;
            var args = new TwainOperationCompleteEventArgs(Select(hwnd) != 0 ? true : false);
            TwainInitOrSelectComplete(this, args);
        }

        private short Select(IntPtr hwndp)
        {
            DisplayCurrentThreadId("select");

            short retCode = 0;

            TwRC rc;

            retCode = Init(hwndp);

            if (appid.Id != IntPtr.Zero)
            {
                CloseSrc();

                rc = DSMident(appid, IntPtr.Zero, TwDG.Control, TwDAT.Identity, TwMSG.UserSelect, srcds);

                if (rc == TwRC.Success)
                    _infoMessage = srcds.ProductName;
                else if (rc == TwRC.Failure)
                    HandleError();
            }

            return retCode;
        }

        public void AcquireImage(bool isDocumentScan)
        {
            var args = new TwainOperationCompleteEventArgs(Acquire(isDocumentScan) != 0 ? true : false);
            TwainOperationComplete(this, args);
        }

        private short Acquire(bool isDocumentScan)
        {
            DisplayCurrentThreadId("acquire");
            Application.DoEvents();

            TwRC rc;
            //CloseSrc();
            if (appid.Id == IntPtr.Zero)
            {
                Init(hwnd);
                if (appid.Id == IntPtr.Zero)
                    return (short)TwRC.Failure;
            }

            _messageFilter.UseFilter = true;

            rc = DSMident(appid, IntPtr.Zero, TwDG.Control, TwDAT.Identity, TwMSG.OpenDS, srcds);
            if (rc != TwRC.Success)
            {
                HandleError();
                return (short)TwRC.Failure;
            }

            TwCapability cap;

            //cap = new TwCapability(TwCap.Rotation, 90, TwType.Fix32);
            //rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Reset, cap);
            //if (rc != TwRC.Success)
            //{
            //    if (HandleError() != (short)ConditionCode.CapabilityUnsupported)
            //        return (short)TwRC.Failure;
            //}

            cap = new TwCapability(TwCap.Rotation, 90, TwType.Fix32);
            rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
            if (rc != TwRC.Success)
            {
                if (HandleError() != (short)ConditionCode.CapabilityUnsupported)
                    return (short)TwRC.Failure;
            }

            if (!isDocumentScan)
            {
                //The A3 size print measures 29.7 x 42.0cm, 11.69 x 16.53 inches, if mounted 40.6 x 50.8cm, 15.98 x 20 inches.
                //The A4 size print measures 21.0 x 29.7cm,   8.27 x 11.69 inches, if mounted 30.3 x 40.6cm, 11.93 x 15.98 inches.

                TwImageLayout imlayout = new TwImageLayout();
                rc = DSlayout(appid, srcds, TwDG.Image, TwDAT.ImageLayout, TwMSG.GetDefault, imlayout);
                if (rc == TwRC.Success)
                {
                    imlayout.Frame.Left.FromFloat(0.1f);    //0.254 cm
                    imlayout.Frame.Top.FromFloat(0.1f);
                    imlayout.Frame.Right.FromFloat(1.77f);  //4.5 cm
                    imlayout.Frame.Bottom.FromFloat(2.36f); //6 cm

                    //imlayout.Frame.Right = new TwFix32(1.77f);
                    //imlayout.Frame.Bottom = new TwFix32(2.36f);

                    //imlayout.Frame.Top = new TwFix32();
                    //imlayout.Frame.Top.Whole = 1;
                    //imlayout.DocumentNumber = 1;
                    //imlayout.FrameNumber = 1;
                    //imlayout.PageNumber = 1;

                    rc = DSlayout(appid, srcds, TwDG.Image, TwDAT.ImageLayout, TwMSG.Set, imlayout);
                    if (rc != TwRC.Success)
                    {
                        if (rc == TwRC.CheckStatus)
                        {
                        }
                        else
                        {
                            HandleError();
                            return (short)TwRC.Failure;
                        }
                    }
                }
                else
                {
                    HandleError();
                    return (short)TwRC.Failure;
                }
            }
            else
            {
                //IntPtr pv = Twain.GlobalLock(cap.Handle);
                //short w1 = Marshal.ReadInt16(pv, 0);
                //int w2 = Marshal.ReadInt32(pv, 2);
                ////object val;
                ////Marshal.PtrToStructure(pv, val);
                //Twain.GlobalUnlock(cap.Handle);


                cap = new TwCapability(TwCap.Supportedsizes, (short)TwSS.None, TwType.UInt16);
                rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
                if (rc != TwRC.Success)
                {
                    HandleError();
                    return (short)TwRC.Failure;
                }

                cap = new TwCapability(TwCap.Orientation, (short)TwOR.Landscape, TwType.UInt16);
                rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
                if (rc != TwRC.Success)
                {
                    HandleError();
                    return (short)TwRC.Failure;
                }


                cap = new TwCapability(TwCap.Undefinedimagesize, 1, TwType.Bool);
                rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
                if (rc != TwRC.Success)
                {
                    HandleError();
                    return (short)TwRC.Failure;
                }
            }

            //cap = new TwCapability(TwCap.SupportedCaps);
            //rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.ResetAll, cap);
            //if (rc != TwRC.Success)
            //{
            //    HandleError();
            //    return (short)TwRC.Failure;
            //}

            cap = new TwCapability(TwCap.PaperDetectable, 0, TwType.Bool);
            rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Get, cap);
            if (rc == TwRC.Success)
            {
                cap = new TwCapability(TwCap.FeederLoaded, 0, TwType.Bool);
                rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Get, cap);
                if (rc != TwRC.Success)
                {
                    HandleError();
                    return (short)TwRC.Failure;
                }
            }

/*
            cap = new TwCapability(TwCap.Undefinedimagesize, 1, TwType.Bool);
            rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
            if (rc == TwRC.Success)
            {
                cap = new TwCapability(TwCap.Automaticborderdetection, 1, TwType.Bool);
                rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Get, cap);
                if (rc != TwRC.Success)
                {
                    HandleError();
                    return (short)TwRC.Failure;
                }
            }
*/
/*
            cap = new TwCapability(TwCap.Undefinedimagesize, 0, TwType.Bool);
            rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Get, cap);
            if (rc == TwRC.Success)
            {
                rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
                if (rc == TwRC.Success)
                {
                    cap = new TwCapability(TwCap.Autosize, (short)TwAS.Auto, TwType.UInt16);
                    rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Get, cap);
                    if (rc == TwRC.Success)
                    {
                        cap = new TwCapability(TwCap.Autosize, (short)TwAS.Auto, TwType.UInt16);
                        rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
                        if (rc != TwRC.Success)
                        {
                            HandleError();
                            return (short)TwRC.Failure;
                        }
                    }
                }
            }
*/

            cap = new TwCapability(TwCap.XferCount, 1, TwType.Int16);
            rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
            if (rc != TwRC.Success)
            {
                HandleError();
                return (short)TwRC.Failure;
            }

            //cap = new TwCapability(TwCap.Brightness, -900, TwType.Fix32);
            //rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
            //if (rc != TwRC.Success)
            //{
            //    HandleError();
            //    return (short)TwRC.Failure;
            //}

            short pixelType = 2;
            short bitDepth = 8;
            if (!isDocumentScan)
            {
                pixelType = 3;
                bitDepth = 4;
            }

            cap = new TwCapability(TwCap.IPixelType, pixelType, TwType.UInt16);  // TWPT_RGB - 2, TWPT_PALETTE - 3
            rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
            if (rc != TwRC.Success)
            {
                HandleError();
                return (short)TwRC.Failure;
            }

            cap = new TwCapability(TwCap.BitDepth, bitDepth, TwType.UInt16);
            rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
            if (rc != TwRC.Success)
            {
                HandleError();
                return (short)TwRC.Failure;
            }

            short resolution = 300;
            //if (!isDocumentScan)
            //    resolution = 300;

            cap = new TwCapability(TwCap.XResolution, resolution, TwType.Fix32);
            //rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Get, cap);
            //IntPtr pv = Twain.GlobalLock(cap.Handle);
            //short w1 = Marshal.ReadInt16(pv, 0);
            //short w2 = Marshal.ReadInt16(pv, 2);
            rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
            if (rc != TwRC.Success)
            {
                HandleError();
                return (short)TwRC.Failure;
            }

            cap = new TwCapability(TwCap.YResolution, resolution, TwType.Fix32);
            rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Set, cap);
            if (rc != TwRC.Success)
            {
                HandleError();
                return (short)TwRC.Failure;
            }

            //cap = new TwCapability(TwCap.ImageFileFormat);
            //rc = DScap(appid, srcds, TwDG.Control, TwDAT.Capability, TwMSG.Get, cap);
            //if (rc != TwRC.Success)
            //{
            //    HandleError();
            //    return (short)TwRC.Failure;
            //}

            //TwSetUpFileXfer xfer = new TwSetUpFileXfer();
            //xfer.FileName = "c:\\temp\\doc.pdf";
            //xfer.Format = 2;       // TWFF_PDF 10
            //xfer.VrefNum = 0xffff;  // TWON_DONTCARE16
            //rc = DSxfer(appid, srcds, TwDG.Control, TwDAT.SetupFileXfer, TwMSG.Set, xfer);
            //if (rc != TwRC.Success)
            //{
            //    HandleError();
            //    return (short)TwRC.Failure;
            //}


            TwUserInterface ui = new TwUserInterface();
            ui.ShowUI = 0;
            ui.ModalUI = 1;
            ui.ParentHand = hwnd;
            rc = DSuserif(appid, srcds, TwDG.Control, TwDAT.UserInterface, TwMSG.EnableDS, ui);
            if (rc != TwRC.Success)
            {
                HandleError();
                return (short)TwRC.Failure;
            }

            return (short)TwRC.Success;
        }

/*
        public ArrayList TransferPictures()
        {
            ArrayList pics = new ArrayList();
            if (srcds.Id == IntPtr.Zero)
                return pics;

            TwRC rc;
            IntPtr hbitmap = IntPtr.Zero;
            TwPendingXfers pxfr = new TwPendingXfers();

            do
            {
                pxfr.Count = 0;
                hbitmap = IntPtr.Zero;
                TwImageInfo iinfo = new TwImageInfo();
                rc = DSiinf(appid, srcds, TwDG.Image, TwDAT.ImageInfo, TwMSG.Get, iinfo);
                if (rc != TwRC.Success)
                {
                    HandleError();
                    return pics;
                }

                iinfo.ImageWidth = 100;
                iinfo.ImageLength = 100;

                rc = DSiinf(appid, srcds, TwDG.Image, TwDAT.ImageInfo, TwMSG.Set, iinfo);
                if (rc != TwRC.Success)
                {
                    HandleError();
                    return pics;
                }

                rc = DSixfer(appid, srcds, TwDG.Image, TwDAT.ImageNativeXfer, TwMSG.Get, ref hbitmap);
                if (rc != TwRC.XferDone)
                {
                    HandleError();
                    return pics;
                }

                rc = DSpxfer(appid, srcds, TwDG.Control, TwDAT.PendingXfers, TwMSG.EndXfer, pxfr);
                if (rc != TwRC.Success)
                {
                    CloseSrc();
                    return pics;
                }

                pics.Add(hbitmap);
            }
            while (pxfr.Count != 0);

            rc = DSpxfer(appid, srcds, TwDG.Control, TwDAT.PendingXfers, TwMSG.Reset, pxfr);
            return pics;
        }
*/
/*
        public TwainCommand PassMessage(ref Message m)
        {
            if (srcds.Id == IntPtr.Zero)
                return TwainCommand.Not;

            int pos = GetMessagePos();

            winmsg.hwnd = m.HWnd;
            winmsg.message = m.Msg;
            winmsg.wParam = m.WParam;
            winmsg.lParam = m.LParam;
            winmsg.time = GetMessageTime();
            winmsg.x = (short)pos;
            winmsg.y = (short)(pos >> 16);

            Marshal.StructureToPtr(winmsg, evtmsg.EventPtr, false);
            evtmsg.Message = 0;
            TwRC rc = DSevent(appid, srcds, TwDG.Control, TwDAT.Event, TwMSG.ProcessEvent, ref evtmsg);
            if (rc == TwRC.NotDSEvent)
                return TwainCommand.Not;
            if (evtmsg.Message == (short)TwMSG.XFerReady)
                return TwainCommand.TransferReady;
            if (evtmsg.Message == (short)TwMSG.CloseDSReq)
                return TwainCommand.CloseRequest;
            if (evtmsg.Message == (short)TwMSG.CloseDSOK)
                return TwainCommand.CloseOk;
            if (evtmsg.Message == (short)TwMSG.DeviceEvent)
                return TwainCommand.DeviceEvent;

            return TwainCommand.Null;
        }
*/
        private short HandleError()
        {
            DSstatus(appid, srcds, TwDG.Control, TwDAT.Status, TwMSG.Get, dsmstat);
            short retCode = (short)dsmstat.ConditionCode;

            if (retCode != (short)ConditionCode.CapabilityUnsupported)
            {
                TwPendingXfers pxfr = new TwPendingXfers();

                DSpxfer(appid, srcds, TwDG.Control, TwDAT.PendingXfers, TwMSG.EndXfer, pxfr);
                DSpxfer(appid, srcds, TwDG.Control, TwDAT.PendingXfers, TwMSG.Reset, pxfr);

                CloseSrc();
            }

            return retCode;
        }

        protected void EndingScan()
        {
            _messageFilter.UseFilter = false;
        }

        public void CloseSrc()
        {
            EndingScan();

            TwRC rc;
            if (srcds.Id != IntPtr.Zero)
            {
                TwUserInterface ui = new TwUserInterface();
                rc = DSuserif(appid, srcds, TwDG.Control, TwDAT.UserInterface, TwMSG.DisableDS, ui);
                rc = DSMident(appid, IntPtr.Zero, TwDG.Control, TwDAT.Identity, TwMSG.CloseDS, srcds);

                srcds.Id = IntPtr.Zero;
            }
        }

        public void Finish()
        {
            TwRC rc;
            CloseSrc();
            if (appid.Id != IntPtr.Zero)
                rc = DSMparent(appid, IntPtr.Zero, TwDG.Control, TwDAT.Parent, TwMSG.CloseDSM, ref hwnd);
        }

        public void Dispose()
        {
            MainForm.GetQueue.Add(Tuple.Create<bool, Action>(false, null));

            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            Marshal.FreeHGlobal(_eventMessage.EventPtr);

            if (disposing)
            {
                Finish();
            }
        }


        internal IntPtr hwnd;
        private static TwIdentity appid;
        private static TwIdentity srcds;
        //internal TwEvent evtmsg;
        //internal WINMSG winmsg;
        internal TwStatus dsmstat;

        string _infoMessage = String.Empty;

        //TWAINDSM.dll
        //twain_32.dll
        // ------ DSM entry point DAT_ variants:
        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSMparent([In, Out] TwIdentity origin, IntPtr zeroptr, TwDG dg, TwDAT dat, TwMSG msg, ref IntPtr refptr);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSMident([In, Out] TwIdentity origin, IntPtr zeroptr, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwIdentity idds);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSMstatus([In, Out] TwIdentity origin, IntPtr zeroptr, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwStatus dsmstat);


        // ------ DSM entry point DAT_ variants to DS:
        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSuserif([In, Out] TwIdentity origin, [In, Out] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, TwUserInterface guif);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSevent([In, Out] TwIdentity origin, [In, Out] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, ref TwEvent evt);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSstatus([In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwStatus dsmstat);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DScap([In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwCapability capa);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSiinf([In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwImageInfo imginf);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSixfer([In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, ref IntPtr hbitmap);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSpxfer([In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwPendingXfers pxfr);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSlayout([In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwImageLayout imlayout);

        [DllImport("twain_32.dll", EntryPoint = "#1")]
        internal static extern TwRC DSxfer([In, Out] TwIdentity origin, [In] TwIdentity dest, TwDG dg, TwDAT dat, TwMSG msg, [In, Out] TwSetUpFileXfer imxfer);

        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern IntPtr GlobalAlloc(int flags, int size);
        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern IntPtr GlobalLock(IntPtr handle);
        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern bool GlobalUnlock(IntPtr handle);
        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern IntPtr GlobalFree(IntPtr handle);
        //    [DllImport("kernel32.dll", ExactSpelling = true)]
        //internal static extern IntPtr GlobalSize(IntPtr handle);

        [DllImport("user32.dll", ExactSpelling = true)]
        public static extern int GetMessagePos();
        [DllImport("user32.dll", ExactSpelling = true)]
        public static extern int GetMessageTime();


        [DllImport("gdi32.dll", ExactSpelling = true)]
        internal static extern int GetDeviceCaps(IntPtr hDC, int nIndex);

        [DllImport("gdi32.dll", CharSet = CharSet.Auto)]
        internal static extern IntPtr CreateDC(string szdriver, string szdevice, string szoutput, IntPtr devmode);

        [DllImport("gdi32.dll", ExactSpelling = true)]
        internal static extern bool DeleteDC(IntPtr hdc);

        public static int ScreenBitDepth
        {
            get
            {
                IntPtr screenDC = CreateDC("DISPLAY", null, null, IntPtr.Zero);
                int bitDepth = GetDeviceCaps(screenDC, 12);
                bitDepth *= GetDeviceCaps(screenDC, 14);
                DeleteDC(screenDC);
                return bitDepth;
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        internal struct WINMSG
        {
            public IntPtr hwnd;
            public int message;
            public IntPtr wParam;
            public IntPtr lParam;
            public int time;
            public int x;
            public int y;
        }
    } // class Twain


    public class TwainOperationCompleteEventArgs : EventArgs
    {
        public bool Error { get; set; }

        public TwainOperationCompleteEventArgs(bool error)
        {
            this.Error = error;
        }
    }

    public class TransferImageEventArgs : EventArgs
    {
        public bool Error { get; set; }
        public ArrayList Image { get; private set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public int Resolution { get; set; }

        public TransferImageEventArgs(ArrayList image, bool error, int width, int height, int resolution)
        {
            this.Image = image;
            this.Error = error;
            this.Width = width;
            this.Height = height;
            this.Resolution = resolution;
        }
    }
}
