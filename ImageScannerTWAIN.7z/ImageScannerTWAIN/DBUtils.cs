using System;
using System.Data;
using System.Data.OleDb;
using System.Data.Common;

using System.Configuration;
using System.Data.SqlClient;

using Npgsql;
using MySql.Data.MySqlClient;

namespace ImageScanner
{
    public class DBUtils
    {
        internal void GetUserProfile(UserProfile user)
        {
            NpgsqlConnection conn = null;
            NpgsqlCommand cmd = null;
            NpgsqlDataReader reader = null;

            try
            {
//                conn = new NpgsqlConnection("Server=localhost;Port=5432;User Id=postgres;Password=nitwit;Database=postgres;");
                conn = new NpgsqlConnection(getConnectionString());
                conn.Open();

                cmd = new NpgsqlCommand();
                cmd.Connection = conn;

                cmd.CommandText = "SELECT fname, lname, dept_code" +
                                " FROM employee" +
                                " WHERE employee_id = :_employee_id";
//                " WHERE employee_id = :value1 or employee_id is null";
                //282033000734

                //cmd.Parameters.Add("_employee_id", NpgsqlTypes.NpgsqlDbType.Varchar);
                cmd.Parameters.Add(new NpgsqlParameter("_employee_id", DbType.String));
                cmd.Parameters[0].Value = user.CivilId.ToString();

                reader = cmd.ExecuteReader();
                //reader.Read();
                //if (reader.HasRows)   // does not work
                if (reader.Read())
                {
                    //user.UserId = reader.GetString(0);
                    if (!reader.IsDBNull(0))
                        user.FirstName = reader.GetString(0);
                    if (!reader.IsDBNull(1))
                        user.LastName = reader.GetString(1);
                    if (!reader.IsDBNull(2))
                        user.InstituteName = reader.GetString(2);
                    user.Status = "ok";
                }
                else
                {
                    user.Status = "Not found";
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try
                {
                    if (reader != null)
                        reader.Close();

                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                    if (conn != null)
                        conn = null;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
        }

        internal byte[] GetUserPicture(Decimal civilId, ref byte[] buffer)
//        internal void GetUserPicture(Decimal civilId, ref byte[] buffer)
        {
            NpgsqlConnection conn = null;
            NpgsqlCommand cmd = null;
            NpgsqlDataReader reader = null;

            //byte[] buffer = null;
            //byte[] buff = null;

            try
            {
                conn = new NpgsqlConnection();
                conn.ConnectionString = getConnectionString();
                conn.Open();

                cmd = new NpgsqlCommand();
                cmd.Connection = conn;

                cmd.CommandText = "SELECT photo_lob FROM employee" + 
                                " WHERE employee_id = :_employee_id";

                cmd.Parameters.Add("_employee_id", NpgsqlTypes.NpgsqlDbType.Varchar);
                //cmd.Parameters.Add(new NpgsqlParameter("_employee_id", DbType.String));
                cmd.Parameters[0].Value = civilId.ToString();

                reader = cmd.ExecuteReader();
                //reader.Read();
                //if (reader.HasRows && !reader.IsDBNull(0))
                if (reader.Read() && !reader.IsDBNull(0))
                {
                    //int maxSize = 102400;
                    //buffer = new byte[maxSize];
                    //long len = reader.GetBytes(0, 0L, buffer, 0, maxSize);
                    long len = reader.GetBytes(0, 0, null, 0, 0);
                    buffer = new byte[len];
                    len = reader.GetBytes(0, 0L, buffer, 0, buffer.Length);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try
                {
                    if (reader != null)
                        reader.Close();

                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                    if (conn != null)
                        conn = null;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            //return buff;
            return new byte[1];
        }

        internal void SaveUserPicture(UserProfile user, ref byte[] buffer, ref byte[] buffer2)
        {
            MySqlConnection conn = null;
            MySqlCommand cmd = null;
            //MySqlDataReader reader = null;

            //NpgsqlConnection conn = null;
            //NpgsqlCommand cmd = null;
            //NpgsqlDataReader reader = null;

            try
            {
                conn = new MySqlConnection();
                conn.ConnectionString = getConnectionString();
                conn.Open();

                cmd = new MySqlCommand();
                cmd.Connection = conn;

                //string app_num = "12345";
                cmd.CommandText = "INSERT INTO ScannedImages (ApplicationNumber, Image, Thumb) VALUES(@application_number, @image, @thumb)";
                cmd.Parameters.AddWithValue("@application_number", "12345");
                cmd.Parameters.AddWithValue("@image", buffer);
                cmd.Parameters.AddWithValue("@thumb", buffer2);

/*
                cmd.CommandText = "UPDATE employee SET photo_lob = :_photo_lob" +
                                " WHERE employee_id = :_employee_id";

                cmd.Parameters.Add("_photo_lob", NpgsqlTypes.NpgsqlDbType.Bytea);
                cmd.Parameters["_photo_lob"].Value = buffer;

                cmd.Parameters.Add("_employee_id", NpgsqlTypes.NpgsqlDbType.Varchar);
                cmd.Parameters["_employee_id"].Value = user.CivilId;
*/
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try
                {
                    //if (reader != null)
                    //    reader.Close();

                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                    if (conn != null)
                        conn = null;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
        }

        internal void DeleteFromDatabase()
        {
            NpgsqlConnection conn = null;
            NpgsqlCommand cmd = null;

            try
            {
                conn = new NpgsqlConnection(getConnectionString());

                conn.Open();

                cmd = new NpgsqlCommand();
                cmd.CommandText = "DELETE FROM employee";

                cmd.Connection = conn;

                cmd.ExecuteNonQuery();
            }
            finally
            {
                try
                {
                    if (conn != null)
                        conn.Close();
                }
                catch (Exception ex)
                {
                    Console.Out.WriteLine(ex.Message);
                }
            }
        }

        //private String getConnectionString(String provider)
        private String getConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["MySQLProvider"].ToString();
        }
    }
}
