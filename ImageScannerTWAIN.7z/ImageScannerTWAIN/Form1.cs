using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Security.Principal;
using System.Collections;
using System.Configuration;


//using System.Configuration;

//using System.Xml;
using System.IO;

using TwainLib;
//using ImageScanner.PTServices;

namespace ImageScanner
{
    public partial class Form1 : Form, IMessageFilter
    {
        private BackgroundWorker backgroundWorkerProgressBar;
        private BackgroundWorker backgroundWorkerAuthentication;
        private BackgroundWorker backgroundWorkerDB;

        private UserProfile _user = null;
        private bool _isImageSourceSelected = false;

        public Form1()
        {
            InitializeComponent();

            backgroundWorkerProgressBar = new BackgroundWorker();
            backgroundWorkerProgressBar.WorkerSupportsCancellation = true;
            backgroundWorkerProgressBar.WorkerReportsProgress = true;
            backgroundWorkerProgressBar.DoWork += new DoWorkEventHandler(backgroundWorkerProgressBar_DoWork);
            backgroundWorkerProgressBar.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerProgressBar_RunWorkerCompleted);
            backgroundWorkerProgressBar.ProgressChanged += new ProgressChangedEventHandler(backgroundWorkerProgressBar_ProgressChanged);

            backgroundWorkerAuthentication = new BackgroundWorker();
            backgroundWorkerAuthentication.DoWork += new DoWorkEventHandler(backgroundWorkerAuthentication_DoWork);
            backgroundWorkerAuthentication.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerAuthentication_RunWorkerCompleted);

            backgroundWorkerDB = new BackgroundWorker();
            backgroundWorkerDB.DoWork += new DoWorkEventHandler(backgroundWorkerDB_DoWork);
            backgroundWorkerDB.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerDB_RunWorkerCompleted);

            StatusBar bar = new StatusBar();
            bar.Visible = true;
            
            tw = new Twain();

            short retCode = tw.Init(this.Handle);
            if (retCode != 0)
            {
                labelImageSource.ForeColor = Color.Red;
                labelImageSource.Text = tw.getInfo();
            }
            else
            {
                labelImageSource.ForeColor = Color.Green;
                labelImageSource.Text = tw.getInfo();

                _isImageSourceSelected = true;
            }
        }
/*
        private String getAuthorizedPersonFDN()
        {
            int i = txtPersonId.Text.LastIndexOf("\\");
            if (i != -1)
                return txtPersonId.Text;
            else
            {
                if (txtDomain.Text.Length == 0)
                    return txtPersonId.Text;
                else
                    return txtDomain.Text + "\\" + txtPersonId.Text;
            }
        }
*/
        private void get_Click(object sender, EventArgs e)
        {
            _user = new UserProfile();
            _user.SupervisorId = txtPersonId.Text;

            try
            {
                decimal cd = Convert.ToDecimal(txtCivilId.Text);

                //ValidationServicesHelper.ValidateCivilId(txtCivilId.Text, 'a');
            }
            catch (FormatException ex)
            {
                toolStripStatusLabelError.Text = ex.Message;
                return;
            }
/*
            catch (Exception ex)
            {
                toolStripStatusLabelError.Text = ex.Message;
                return;
            }
*/
            _user.CivilId = Convert.ToDecimal(txtCivilId.Text);
                        
            ((Button)sender).Enabled = false;
            this.Cursor = Cursors.WaitCursor;

            toolStripStatusLabelError.Text = "";
            enableScan(false);            

            //startProgressBar();
            //startDbProcess();
            backgroundWorkerDB_DoWork(null, null);

/*
            DBHelper db = new DBHelper();
            
            try
            {
                db.GetUserProfile(ref _user);
                if (_user.Status != "ok")
                {
                    toolStripStatusLabelError.Text = _user.Status;
                    return;
                }
                else
                {
                    //                    txtUserProfile.Text = _user.UserId + Environment.NewLine + Environment.NewLine +
                    txtUserProfile.Text = _user.FirstName.Trim() + " " +
                                            _user.SecondName.Trim() + " " +
                                            _user.ThirdName.Trim() + " " +
                                            _user.LastName.Trim() + Environment.NewLine + Environment.NewLine +
                                            _user.InstituteName.Trim() + Environment.NewLine + Environment.NewLine +
                                            _user.MajorName.Trim();

                    byte[] buffer = db.GetUserPicture(_user.CivilId);

                    if (buffer != null)
                    {
                        MemoryStream ms = new MemoryStream();
                        ms.Write(buffer, 0, buffer.Length);
                        Image img = Image.FromStream(ms);
                        pictureBox1.Image = img;

                        ms.Close();
                    }
                    enableScan(true);
                    //                    btnScan.Enabled = true;
                }

            }
            catch (Exception ex)
            {
                toolStripStatusLabelError.Text = ex.Message;
            }
            finally
            {
//                stopProgressBar();
                this.Cursor = Cursors.Default;
                ((Button)sender).Enabled = true;
            }
 */ 
        }

        private void scan_Click(object sender, EventArgs e)
        {
            if (!msgfilter)
            {
                this.Enabled = false;
                msgfilter = true;
                Application.AddMessageFilter(this);
            }

            startProgressBar();

            short retCode = tw.Acquire();
            if (retCode != 0)
            {
                EndingScan();
//                tw.Finish();
            }

            stopProgressBar();

        }

        private void logon_Click(object sender, EventArgs e)
        {
            txtCivilId.Enabled = false;
            btnGet.Enabled = false;


            enableScan(true);

            //enableScan(false);
            //btnScan.Enabled = false;
            
            
            
            toolStripStatusLabelError.Text = "";
            txtUserProfile.Text = "";
            pictureBox1.Image = null;
            pictureBox1.Invalidate();

            startProgressBar();
            startAuthProcess();
            //backgroundWorkerAuthentication_DoWork(null, null);

//            System.Threading.Thread.Sleep(10000);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            WindowsIdentity windowsIdentity = WindowsIdentity.GetCurrent();
            int i = windowsIdentity.Name.LastIndexOf("\\");
            if (i != -1)
            {
                txtDomain.Text = windowsIdentity.Name.Substring(0, i);
                txtPersonId.Text = windowsIdentity.Name.Substring(i + 1);
            }
            else
            {
                txtDomain.Text = String.Empty;
                txtPersonId.Text = windowsIdentity.Name;
            }

/*
            IdentityReferenceCollection coll = windowsIdentity.Groups;
            IEnumerator it = coll.GetEnumerator();
            while (it.MoveNext())
            {
                String str = ((IdentityReference)it.Current).Translate(typeof(NTAccount)).Value;
                int ii = 0;
            }

            WindowsPrincipal principal = new WindowsPrincipal(windowsIdentity);
            bool b = principal.IsInRole(ConfigurationManager.AppSettings["AuthorizationGroup"]);
*/

            txtPassword.Text = "******";

            txtCivilId.Enabled = false;
            btnGet.Enabled = false;
//            btnScan.Enabled = false;
            enableScan(false);
            this.ActiveControl = txtPersonId;
            this.AcceptButton = btnLogon;

#if DEBUG
//            txtPersonId.Text = "ri.russia";
//            txtPersonId.Text = "ri.davidenko";
//            txtPassword.Text = "";

//            txtCivilId.Text = "287062301977";
//            txtCivilId.Text = "282033000734";
            txtCivilId.Text = "10";
//            txtCivilId.Text = "250031301609";
            
#endif

            String domainLocation = ConfigurationManager.AppSettings["DomainLocation"];
//            if (domainLocation.StartsWith(txtDomain.Text, StringComparison.InvariantCultureIgnoreCase) ||
//                domainLocation.Equals("rootDSE"))
            if (domainLocation.StartsWith(txtDomain.Text, StringComparison.InvariantCultureIgnoreCase))
            {
                btnLogon.PerformClick();
                btnLogon.Enabled = false;
            }

        }

        internal UserProfile User
        {
            get { return _user; }
        }

        private void txtPersonId_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = btnLogon;
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = btnLogon;
        }

        private void txtCivilId_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = btnGet;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            short retCode = tw.Select(this.Handle);
            if (retCode != 0)
            {
                labelImageSource.ForeColor = Color.Red;
                labelImageSource.Text = tw.getInfo();

                _isImageSourceSelected = false;

            }
            else
            {
                labelImageSource.ForeColor = Color.Green;
                labelImageSource.Text = tw.getInfo();

                _isImageSourceSelected = true;

                if (txtUserProfile.Text.Length != 0)
                    enableScan(true);
            }
        }

        private void txtPersonId_TextChanged(object sender, EventArgs e)
        {
            btnLogon.Enabled = true;
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            btnLogon.Enabled = true;
        }

        private void txtCivilId_TextChanged(object sender, EventArgs e)
        {
            clearControls();
        }

        private void enableScan(bool flag) {
            if (flag && _isImageSourceSelected)
                btnScan.Enabled = true;
            else
                btnScan.Enabled = false;
        }

        private void clearControls()
        {
            enableScan(false);
            txtUserProfile.Text = "";
            pictureBox1.Image = null;
            pictureBox1.Invalidate();
        }
    }
}