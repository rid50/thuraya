using System;
using System.Configuration;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.ComponentModel;
using System.Xml;
using System.IO;
using System.Windows.Forms;

//using ImageScanner.PhotoTableUtils;
using ImageScanner.PostgrePhotoTableService;

namespace ImageScanner
{
    partial class Form1
    {
        void startDbProcess()
        {
            if (backgroundWorkerDB.IsBusy)
                return;

            backgroundWorkerDB.RunWorkerAsync();
        }

        private void backgroundWorkerDB_DoWork(object sender, DoWorkEventArgs e)
        {
            // This method will run on a thread other than the UI thread.
            // Be sure not to manipulate any Windows Forms controls created
            // on the UI thread from this method.

            DbHelper db = new DbHelper();

            try
            {
                db.GetUserProfile(ref _user);
                if (_user.Status != "ok")
                {
                    txtUserProfile.Text = "";
                    pictureBox1.Image = null;
                    toolStripStatusLabelError.Text = _user.Status;
                    return;
                }
                else
                {
                    //txtUserProfile.Text = _user.UserId + Environment.NewLine + Environment.NewLine +
                    txtUserProfile.Text = _user.FirstName.Trim() + " " +
                                            _user.SecondName.Trim() + " " +
                                            _user.ThirdName.Trim() + " " +
                                            _user.LastName.Trim() + Environment.NewLine + Environment.NewLine +
                                            _user.InstituteName.Trim() + Environment.NewLine + Environment.NewLine +
                                            _user.MajorName.Trim();

                    //int maxSize = 102400;
                    //byte[] buffer = new byte[maxSize];
                    byte[] buff = null;

                    //byte[] buffer = db.GetUserPicture(_user.CivilId);
                    db.GetUserPicture(_user.CivilId, ref buff);

                    if (buff != null)
                    {
                        using (MemoryStream ms = new MemoryStream(buff))
                        {
                            //ms.Seek(0, SeekOrigin.Begin);
                            //ms.Write(buffer, 0, buffer.Length);
                            Image img = Image.FromStream(ms);
                            pictureBox1.SizeMode = PictureBoxSizeMode.Normal;
                            pictureBox1.Image = img;
                            ms.Close();
                        }
                    }
                    else
                    {
                        using (FileStream fs = new FileStream("./no_photo_available.gif", FileMode.Open, FileAccess.Read))
                        {
                            Image img = Image.FromStream(fs);
                            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                            pictureBox1.Image = img;
                            fs.Close();
                        }
                    }
                    enableScan(true);
                }
            }
            catch (Exception ex)
            {
                toolStripStatusLabelError.Text = ex.Message;
            }
        }

        private void backgroundWorkerDB_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            stopProgressBar();
            this.Cursor = Cursors.Default;
            btnGet.Enabled = true;
        }

        public class DbHelper
        {
            ImageScanner.PostgrePhotoTableService.PhotoTableUtils _proxy = null;

            public DbHelper()
            {
                String client = ConfigurationManager.AppSettings["DBClient"];
                if (client == "service")
                {
                    _proxy = new ImageScanner.PostgrePhotoTableService.PhotoTableUtils();
                    _proxy.PreAuthenticate = true;
//                _proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;


                    String nCr = ConfigurationManager.AppSettings["NetworkCredential"];
                    String[] networkCredential = nCr.Split(new char[]{','});

                    System.Net.CredentialCache cache = new System.Net.CredentialCache();
                    System.Net.NetworkCredential cred = new System.Net.NetworkCredential(networkCredential[0].Trim(), networkCredential[1].Trim(), networkCredential[2].Trim());
                    cache.Add(new System.Uri(_proxy.Url), "Negotiate", cred);
                    _proxy.Credentials = cache;
                    _proxy.ConnectionGroupName = networkCredential[0].Trim();

                }
            }

            public void GetUserProfile(ref UserProfile user)
            {
                if (_proxy == null) {
                    DBUtils db = new DBUtils();
                    db.GetUserProfile(user);
                }
                else 
                {
//                ImageScanner.PhotoTableUtils.UserProfile userPr = new ImageScanner.PhotoTableUtils.UserProfile();
//                userPr.CivilId = user.CivilId;

                    try
                    {
//                    ImageScanner.PhotoTableUtils.UserProfile userPr2 = _proxy.GetUserProfile(userPr);
                        _proxy.GetUserProfile(ref user);
//                    user.CivilId = userPr2.CivilId;
//                    user.FirstName = userPr2.FirstName;
//                    user.Status = userPr2.Status;

//                    return user;
                    }
                    catch (System.Web.Services.Protocols.SoapException sex)
                    {
                        String errorCode = null;
                        if (sex.Detail != null)
                        {
                            XmlNode node = sex.Detail.SelectSingleNode("error");
                            if (node != null)
                                errorCode = node.Attributes["errorCode"].Value;
                        }

                        uint uerr = 0;
                        if (errorCode != null)
                        {
                            uerr = (uint)(Convert.ToInt32(errorCode));
                            //if (uerr == 0x8007052e) // Logon failure: unknown user name or bad password
                            //if (uerr == 0x8007200a) // Logon failure: Your account is not active or disabled
                        }

                        throw new Exception(sex.Message);
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message);
                    }
                }
            }

            public byte[] GetUserPicture(Decimal civilId, ref byte[] buffer)
            {
                if (_proxy == null) {
                    DBUtils db = new DBUtils();
                    return db.GetUserPicture(civilId, ref buffer);
                }
                else
                {
                    try
                    {
                        return _proxy.GetUserPicture(civilId);
                    }
                    catch (System.Web.Services.Protocols.SoapException sex)
                    {
                        String errorCode = null;
                        if (sex.Detail != null)
                        {
                            XmlNode node = sex.Detail.SelectSingleNode("error");
                            if (node != null)
                                errorCode = node.Attributes["errorCode"].Value;
                        }

                        uint uerr = 0;
                        if (errorCode != null)
                        {
                            uerr = (uint)(Convert.ToInt32(errorCode));
                            //if (uerr == 0x8007052e) // Logon failure: unknown user name or bad password
                            //if (uerr == 0x8007200a) // Logon failure: Your account is not active or disabled
                        }

                        throw new Exception(sex.Message);
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message);
                    }
                }
            }

            public void SaveUserPicture(UserProfile user, ref byte[] buffer, ref byte[] buffer2)
            {

                if (_proxy == null) {
                    DBUtils db = new DBUtils();
                    db.SaveUserPicture(user, ref buffer, ref buffer2);
                }
                else
                {
//                ImageScanner.PhotoTableUtils.UserProfile userPr = new ImageScanner.PhotoTableUtils.UserProfile();
//                userPr.CivilId = user.CivilId;
//                userPr.SupervisorId = user.SupervisorId;
                    try
                    {
                        _proxy.SaveUserPicture(user, ref buffer);
                    }
                    catch (System.Web.Services.Protocols.SoapException sex)
                    {
                        String errorCode = null;
                        if (sex.Detail != null)
                        {
                            XmlNode node = sex.Detail.SelectSingleNode("error");
                            if (node != null)
                                errorCode = node.Attributes["errorCode"].Value;
                        }

                        uint uerr = 0;
                        if (errorCode != null)
                        {
                            uerr = (uint)(Convert.ToInt32(errorCode));
                            //if (uerr == 0x8007052e) // Logon failure: unknown user name or bad password
                            //if (uerr == 0x8007200a) // Logon failure: Your account is not active or disabled
                        }

                        throw new Exception(sex.Message);
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message);
                    }
                }
            }
        }
    }
}
