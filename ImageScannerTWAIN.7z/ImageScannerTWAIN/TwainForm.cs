﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TwainLib;

namespace ImageScanner
{
    public partial class TwainForm : Form, IMessageFilter
    {
        Form1 _mainForm = null;
        private BackgroundWorker backgroundWorkerScan;
        internal bool _isImageSourceSelected = false;

        public TwainForm(Form1 parent)
        {
            Visible = false;

            InitializeComponent();
            _mainForm = parent;

            backgroundWorkerScan = new BackgroundWorker();
            backgroundWorkerScan.DoWork += new DoWorkEventHandler(backgroundWorkerScan_DoWork);
            backgroundWorkerScan.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerScan_RunWorkerCompleted);

            tw = new Twain();

            short retCode = tw.Init(this.Handle);
            if (retCode != 0)
            {
                _mainForm.labelImageSource.ForeColor = Color.Red;
                _mainForm.labelImageSource.Text = tw.getInfo();
            }
            else
            {
                _mainForm.labelImageSource.ForeColor = Color.Green;
                _mainForm.labelImageSource.Text = tw.getInfo();

                _isImageSourceSelected = true;
            }
        }
    }
}
