﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TwainLib;
using GdiPlusLib;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System.IO;
using System.Threading;

namespace ImageScanner
{
    //public partial class TwainForm : Form, IMessageFilter
    public partial class TwainForm : Form
    {
        Form1 _mainForm = null;
        private BackgroundWorker backgroundWorkerScan;
        internal bool _isImageSourceSelected = false;
        internal Twain _tw;

        //public event EventHandler AcquireImage;

        //internal Func<short> AcquireFunc;
        //delegate UserProfile GetUserProfileFunc();
        //delegate void SetImageFunc(Image image);
        //delegate void StopProgressBarFunc();
        //delegate void SetLabelImageSourceFunc(Color color);
        //delegate void SetStatusLabelErrorFunc(String message);

        public TwainForm(Form1 parent)
        {
            //Visible = false;

            InitializeComponent();
            _mainForm = parent;

            //if (_mainForm.InvokeRequired)
                _mainForm.toolStripStatusLabelError.Text += System.Threading.Thread.CurrentThread.ManagedThreadId.ToString() + " twain form | ";

            backgroundWorkerScan = new BackgroundWorker();
            backgroundWorkerScan.DoWork += new DoWorkEventHandler(backgroundWorkerScan_DoWork);
            backgroundWorkerScan.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerScan_RunWorkerCompleted);

            _tw = new Twain(new WindowMessageHook(_mainForm), _mainForm);
            //_mainForm.GetQueue.Add(Tuple.Create<bool, Action>(true, () => _tw = new Twain(new WindowMessageHook(_mainForm), _mainForm)));
            //_mainForm.GetQueue.Add(Tuple.Create<bool, Action>(true, () => _tw.Init(this.Handle)));

//            SynchronizationContext context = SynchronizationContext.Current;

            //AcquireImage += delegate(Object sender, EventArgs args)
            //{
            //    parent.GetSynchronizationContext.Post(new SendOrPostCallback(delegate(object o) { _tw.Acquire(); }), null);
            //};


            //AcquireFunc = _tw.Acquire;

            _tw.TransferImage += delegate(Object sender, TransferImageEventArgs args)
            {
                if (args.Image != null)
                {
                    MemoryStream ms = null;

                    for (int i = 0; i < args.Image.Count; i++)
                    {
                        IntPtr imgPtr = (IntPtr)args.Image[i];
                        IntPtr bmpPtr = Gdip.GlobalLock(imgPtr);
                        IntPtr pixPtr = BitmapUtils.GetPixelInfo(bmpPtr);

                        Guid clsid;
                        //String strFileName = @"c:\" + Environment.MachineName + i.ToString() + DateTime.Now.Millisecond + ".jpg";
                        String inFileName = "temp.jpg";
                        if (Gdip.GetCodecClsid(inFileName, out clsid))
                        {
                            IntPtr imgPtr2 = IntPtr.Zero;
                            Gdip.GdipCreateBitmapFromGdiDib(bmpPtr, pixPtr, ref imgPtr2);

                            Gdip.GdipSaveImageToFile(imgPtr2, inFileName, ref clsid, IntPtr.Zero);

                            Gdip.GdipDisposeImage(imgPtr2);
                            Gdip.GlobalFree(imgPtr);
                            imgPtr = IntPtr.Zero;
                            imgPtr2 = IntPtr.Zero;

                            XImage ximg = XImage.FromFile(inFileName);
                            PdfDocument doc = new PdfDocument();
                            PdfPage page = new PdfPage();
                            page.Width = ximg.PixelWidth;
                            page.Height = ximg.PixelHeight;
                            doc.Pages.Add(page);
                            XGraphics xgr = XGraphics.FromPdfPage(doc.Pages[0]);

                            xgr.DrawImage(ximg, 0, 0);

                            ms = new MemoryStream();
                            doc.Save(ms, false);
                            byte[] buffer_pdf = ms.ToArray();

                            //var ms4 = new MemoryStream(buffer_pdf);
                            //PdfDocument doc4 = new PdfDocument();
                            //doc4 = PdfSharp.Pdf.IO.PdfReader.Open(ms4);
                            //doc4.Save("doc4.pdf");

                            //String outFileName = "temp.pdf";
                            //doc.Save(outFileName);
                            ximg.Dispose();
                            doc.Close();
                            ms.Close();
                            ms = null;

                            FileStream fs = new FileStream(inFileName, FileMode.Open, FileAccess.Read);
                            BinaryReader br = new BinaryReader(fs);
                            byte[] buffer = br.ReadBytes((int)fs.Length);

                            //fs.Close();
                            //fs = null;
                            //Image image = Image.FromFile(strFileName);
                            ms = new MemoryStream(buffer);
                            Image image = Image.FromStream(ms);
                            Image image2 = BitmapUtils.resizeImage(image, 480);

                            ms.Close();
                            ms = null;
                            ms = new MemoryStream();
                            image2.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                            byte[] buffer2 = ms.ToArray();

                            Form1.DbHelper db = new Form1.DbHelper();
                            try
                            {
                                //db.SaveAttachment(_mainForm.User, ref buffer_pdf, ref buffer2);
                                db.SaveAttachment(CheckAndGetUserProfile(), ref buffer_pdf, ref buffer2);
                                Image img = Image.FromStream(fs);

                                //Action<Image> imAction = (im) => SetImage(img);

                                if (_mainForm.InvokeRequired)
                                    _mainForm.Invoke((Action<Image>)((im) => SetImage(img)));
                                    //_mainForm.Invoke(new SetImageFunc(SetImage), img);
                                else
                                    SetImage(img);

                                //_mainForm.pictureBox1.Image = img;
                                //_mainForm.txtAttachmentTitle.Text = _mainForm.User.Title;
                                //_mainForm.txtAttachmentUser.Text = _mainForm.User.DisplayName;
                                //_mainForm.txtAttachmentDate.Text = DateTime.Now.ToString("dd/MM/yyyy");

                                //pictureBox1.Image = image2;
                            }
                            catch (Exception ex)
                            {
                                if (_mainForm.InvokeRequired)
                                    _mainForm.Invoke((Action)(() => SetStatusLabelError(ex.Message)));
                                    //_mainForm.Invoke(new SetStatusLabelErrorFunc(SetStatusLabelError), ex.Message);
                                else
                                    SetStatusLabelError(ex.Message);

                                //_mainForm.toolStripStatusLabelError.Text = ex.Message;
                            }
                            finally
                            {
                                if (fs != null)
                                    fs.Close();
                                if (ms != null)
                                    ms.Close();

                                if (image != null)
                                    image.Dispose();
                                if (image2 != null)
                                    image2.Dispose();

                                File.Delete(inFileName);
                            }
                        }
                        else
                        {
                            //toolStripStatusLabelError.Text = "No codec found for the file: " + inFileName;
                            break;
                        }

                        //fs.Close();
                        //try
                        //{
                        //    //File.Delete(strFileName);
                        //}
                        //catch { }
                    }

                    if (_mainForm.InvokeRequired)
                        _mainForm.Invoke((Action)(() => StopProgressBar()));
                    else
                        StopProgressBar();

                    ////this.Enabled = true;
                    ////_mainForm.Activate();
                    //_mainForm.Cursor = Cursors.Default;
                    //_mainForm.enableButtons(true);
                    //_mainForm.stopProgressBar();
                }

            };


/*
            short retCode = _tw.Init(_mainForm.Handle);
            if (retCode != 0)
            {
                if (_mainForm.InvokeRequired)
                    _mainForm.Invoke((Action)(() => SetLabelImageSource(Color.Red)));
                    //_mainForm.Invoke(new SetLabelImageSourceFunc(SetLabelImageSource), Color.Red);
                else
                    SetLabelImageSource(Color.Red);

                //_mainForm.labelImageSource.ForeColor = Color.Red;
                //_mainForm.labelImageSource.Text = tw.getInfo();
            }
            else
            {
                if (_mainForm.InvokeRequired)
                    _mainForm.Invoke((Action)(() => SetLabelImageSource(Color.Green)));
                    //_mainForm.Invoke(new SetLabelImageSourceFunc(SetLabelImageSource), Color.Green);
                else
                    SetLabelImageSource(Color.Green);

                //_mainForm.labelImageSource.ForeColor = Color.Green;
                //_mainForm.labelImageSource.Text = tw.getInfo();

                _isImageSourceSelected = true;
            }
*/
            //Acquire();
            //_tw.Acquire();
        }

        private void TwainForm_Load(object sender, EventArgs e)
        {

            //this.Visible = true;
            //this.Show();

        }

        private UserProfile CheckAndGetUserProfile()
        {
            if (_mainForm.InvokeRequired) {
                //Func<UserProfile> func = () => GetUserProfile(); 
                //return _mainForm.Invoke(func) as UserProfile;
                return _mainForm.Invoke((Func<UserProfile>)(() => GetUserProfile())) as UserProfile;
                //return _mainForm.Invoke(new GetUserProfileFunc(GetUserProfile)) as UserProfile;
            } else
                return GetUserProfile();
        }

        private UserProfile GetUserProfile()
        {
            return _mainForm.User;
        }

        private void SetImage(Image img)
        {
            _mainForm.pictureBox1.Image = img;
            _mainForm.txtAttachmentTitle.Text = CheckAndGetUserProfile().Title;
            _mainForm.txtAttachmentUser.Text = CheckAndGetUserProfile().DisplayName;
            _mainForm.txtAttachmentDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void StopProgressBar()
        {
            _mainForm.Cursor = Cursors.Default;
            _mainForm.enableButtons(true);
            _mainForm.stopProgressBar();
        }

        private void SetLabelImageSource(Color c)
        {
            _mainForm.labelImageSource.ForeColor = c;
            _mainForm.labelImageSource.Text = _tw.getInfo();
        }

        private void SetStatusLabelError(String message)
        {
            _mainForm.toolStripStatusLabelError.Text = message; 
        }

        public void Acquire2()
        {
            //setMessageFilter();
            startScanProcess();
        }

        public bool Acquire()
        {
            //Func<short> func = _tw.Acquire;
            //func.BeginInvoke(null, null);
            //_mainForm.Invoke(func);

            //EventHandler handler = AcquireImage;
            //handler(this, null);

            //setMessageFilter();
            return startScanProcess();
        }

/*
        private IntPtr GetPixelInfo(IntPtr bmpptr)
        {
            //BITMAPINFOHEADER bmi;
            BitmapInfoHeader bmi;
            Rectangle bmprect = new Rectangle(0, 0, 0, 0);

            //bmi = new BITMAPINFOHEADER();
            bmi = new BitmapInfoHeader();
            System.Runtime.InteropServices.Marshal.PtrToStructure(bmpptr, bmi);

            bmprect.X = bmprect.Y = 0;
            bmprect.Width = bmi.biWidth;
            bmprect.Height = bmi.biHeight;

            if (bmi.biSizeImage == 0)
                bmi.biSizeImage = ((((bmi.biWidth * bmi.biBitCount) + 31) & ~31) >> 3) * bmi.biHeight;

            int p = bmi.biClrUsed;
            if ((p == 0) && (bmi.biBitCount <= 8))
                p = 1 << bmi.biBitCount;
            p = (p * 4) + bmi.biSize + (int)bmpptr;
            return (IntPtr)p;
        }

        //private static Image resizeImage(Image imgToResize, Size size)
        private static Image resizeImage(Image imgToResize, int height)
        {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;

            //float nPercent = 0;
            //float nPercentW = 0;
            //float nPercentH = 0;

            //nPercentW = ((float)size.Width / (float)sourceWidth);
            //nPercentH = ((float)size.Height / (float)sourceHeight);
            float nPercent = ((float)height / (float)sourceHeight);

            //if (nPercentH < nPercentW)
            //    nPercent = nPercentH;
            //else
            //    nPercent = nPercentW;

            int destWidth = (int)(sourceWidth * nPercent);
            int destHeight = (int)(sourceHeight * nPercent);

            Bitmap b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage((Image)b);
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();

            return (Image)b;
        }

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential, Pack = 2)]
        internal class BITMAPINFOHEADER
        {
            public int biSize;
            public int biWidth;
            public int biHeight;
            public short biPlanes;
            public short biBitCount;
            public int biCompression;
            public int biSizeImage;
            public int biXPelsPerMeter;
            public int biYPelsPerMeter;
            public int biClrUsed;
            public int biClrImportant;
        }
*/
    }
}
