using System;
using System.Collections.Generic;
using System.Text;

namespace ImageScanner
{
    public class UserProfile
    {
        private String userId = String.Empty;
        private Decimal civilId;
        private String applicationNumber = String.Empty;
        private String title = String.Empty;
        private String firstName = String.Empty;
        private String secondName = String.Empty;
        private String thirdName = String.Empty;
        private String lastName = String.Empty;
        private String displayName = String.Empty;
        private String instituteName = String.Empty;
        private String majorName = String.Empty;
        private String supervisorId = String.Empty;
        private String status = String.Empty;

        public String UserId
        {
            get { return userId; }
            set { userId = value; }
        }

        public Decimal CivilId
        {
            get { return civilId; }
            set { civilId = value; }
        }

        public String ApplicationNumber
        {
            get { return applicationNumber; }
            set { applicationNumber = value; }
        }

        public String Title
        {
            get { return title; }
            set { title = value; }
        }

        public String FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public String SecondName
        {
            get { return secondName; }
            set { secondName = value; }
        }

        public String ThirdName
        {
            get { return thirdName; }
            set { thirdName = value; }
        }

        public String LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public String DisplayName
        {
            get { return displayName; }
            set { displayName = value; }
        }

        public String InstituteName
        {
            get { return instituteName; }
            set { instituteName = value; }
        }

        public String MajorName
        {
            get { return majorName; }
            set { majorName = value; }
        }

        public String SupervisorId
        {
            get { return supervisorId; }
            set { supervisorId = value; }
        }

        public String Status
        {
            get { return status; }
            set { status = value; }
        }
    }
}
