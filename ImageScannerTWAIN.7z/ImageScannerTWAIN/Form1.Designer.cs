using System;

using System.Collections;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

using System.Runtime.InteropServices;

using TwainLib;
using GdiPlusLib;
using PdfSharp.Pdf;
using PdfSharp.Drawing;


namespace ImageScanner
{

    partial class Form1
    {


//        [DllImport("kernel32.dll", ExactSpelling = true)]
//        internal static extern IntPtr GlobalLock(IntPtr handle);
//        [DllImport("kernel32.dll", ExactSpelling = true)]
//        internal static extern IntPtr GlobalFree(IntPtr handle);

//        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
//        public static extern void OutputDebugString(string outstr);
//        [DllImport("gdiplus.dll", ExactSpelling = true)]
//        internal static extern int GdipCreateBitmapFromGdiDib(IntPtr bminfo, IntPtr pixdat, ref IntPtr image);

//        [DllImport("gdiplus.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]
//        internal static extern int GdipSaveImageToFile(IntPtr image, string filename, [In] ref Guid clsid, IntPtr encparams);

//        [DllImport("gdiplus.dll", ExactSpelling = true)]
//        internal static extern int GdipDisposeImage(IntPtr image);


        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {

            _twain.Dispose();

            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        //public void Dispose()
        //{
        //    _queue.Add(Tuple.Create<bool, Action>(false, null));
        //    Dispose(true);
        //    //GC.SuppressFinalize(this);
        //}


/*
        bool IMessageFilter.PreFilterMessage(ref Message m)
        {
            TwainCommand cmd = tw.PassMessage(ref m);
            if (cmd == TwainCommand.Not)
                return false;

            switch (cmd)
            {
                case TwainCommand.CloseRequest:
                    {
                        EndingScan();
                        tw.CloseSrc();
                        break;
                    }
                case TwainCommand.CloseOk:
                    {
                        EndingScan();
                        tw.CloseSrc();
                        break;
                    }
                case TwainCommand.DeviceEvent:
                    {
                        break;
                    }
                case TwainCommand.TransferReady:
                    {
                        MemoryStream ms = null;
                        ArrayList pics = tw.TransferPictures();
                        EndingScan();
                        tw.CloseSrc();
                        for (int i = 0; i < pics.Count; i++)
                        {
                            IntPtr imgPtr = (IntPtr)pics[i];
                            IntPtr bmpPtr = Gdip.GlobalLock(imgPtr);
                            IntPtr pixPtr = GetPixelInfo(bmpPtr);

                            Guid clsid;
//                            String strFileName = @"c:\" + Environment.MachineName + i.ToString() + DateTime.Now.Millisecond + ".jpg";
                            String inFileName = "temp.jpg";
                            if (Gdip.GetCodecClsid(inFileName, out clsid))
                            {
                                IntPtr imgPtr2 = IntPtr.Zero;
                                Gdip.GdipCreateBitmapFromGdiDib(bmpPtr, pixPtr, ref imgPtr2);

                                Gdip.GdipSaveImageToFile(imgPtr2, inFileName, ref clsid, IntPtr.Zero);

                                Gdip.GdipDisposeImage(imgPtr2);
                                Gdip.GlobalFree(imgPtr);
                                imgPtr = IntPtr.Zero;
                                imgPtr2 = IntPtr.Zero;

                                XImage ximg = XImage.FromFile(inFileName);
                                PdfDocument doc = new PdfDocument();
                                PdfPage page = new PdfPage();
                                page.Width = ximg.PixelWidth;
                                page.Height = ximg.PixelHeight;
                                doc.Pages.Add(page);
                                XGraphics xgr = XGraphics.FromPdfPage(doc.Pages[0]);

                                xgr.DrawImage(ximg, 0, 0);

                                ms = new MemoryStream();
                                doc.Save(ms, false);
                                byte[] buffer_pdf = ms.ToArray();

                                //var ms4 = new MemoryStream(buffer_pdf);
                                //PdfDocument doc4 = new PdfDocument();
                                //doc4 = PdfSharp.Pdf.IO.PdfReader.Open(ms4);
                                //doc4.Save("doc4.pdf");

                                //String outFileName = "temp.pdf";
                                //doc.Save(outFileName);
                                ximg.Dispose();
                                doc.Close();
                                ms.Close();
                                ms = null;
                                
                                FileStream fs = new FileStream(inFileName, FileMode.Open, FileAccess.Read);
                                BinaryReader br = new BinaryReader(fs);
                                byte[] buffer = br.ReadBytes((int)fs.Length);

                                //fs.Close();
                                //fs = null;
                                //Image image = Image.FromFile(strFileName);
                                ms = new MemoryStream(buffer);
                                Image image = Image.FromStream(ms);
                                Image image2 = resizeImage(image, 480);

                                ms.Close();
                                ms = null;
                                ms = new MemoryStream();
                                image2.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                                byte[] buffer2 = ms.ToArray();

                                DbHelper db = new DbHelper();
                                try
                                {
                                    db.SaveAttachment(this.User, ref buffer_pdf, ref buffer2);
                                    Image img = Image.FromStream(fs);
                                    pictureBox1.Image = img;
                                    txtAttachmentTitle.Text = _user.Title;
                                    txtAttachmentUser.Text = _user.DisplayName;
                                    txtAttachmentDate.Text = DateTime.Now.ToString("dd/MM/yyyy");

                                    //pictureBox1.Image = image2;
                                }
                                catch (Exception ex)
                                {
                                    toolStripStatusLabelError.Text = ex.Message;
                                }
                                finally
                                {
                                    if (fs != null)
                                        fs.Close();
                                    if (ms != null)
                                        ms.Close();

                                    if (image != null)
                                        image.Dispose();
                                    if (image2 != null)
                                        image2.Dispose();

                                    //File.Delete(strFileName);
                                }
                            }
                            else
                            {
                                toolStripStatusLabelError.Text = "No codec found for the file: " + inFileName;
                                break;
                            }

                            //fs.Close();
                            //try
                            //{
                            //    //File.Delete(strFileName);
                            //}
                            //catch { }
                        }

                        //this.Enabled = true;
                        this.Activate();
                        this.Cursor = Cursors.Default;
                        enableButtons(true);

                        break;
                    }
            }

            return true;
        }

        private void EndingScan()
        {
            if (msgfilter)
            {
                Application.RemoveMessageFilter(this);
                msgfilter = false;
//                this.Enabled = true;
//                this.Activate();
            }
        }
*/
/*
        private IntPtr GetPixelInfo(IntPtr bmpptr)
        {
            BITMAPINFOHEADER bmi;
            Rectangle bmprect = new Rectangle(0, 0, 0, 0);

            bmi = new BITMAPINFOHEADER();
            Marshal.PtrToStructure(bmpptr, bmi);

            bmprect.X = bmprect.Y = 0;
            bmprect.Width = bmi.biWidth;
            bmprect.Height = bmi.biHeight;

            if (bmi.biSizeImage == 0)
                bmi.biSizeImage = ((((bmi.biWidth * bmi.biBitCount) + 31) & ~31) >> 3) * bmi.biHeight;

            int p = bmi.biClrUsed;
            if ((p == 0) && (bmi.biBitCount <= 8))
                p = 1 << bmi.biBitCount;
            p = (p * 4) + bmi.biSize + (int)bmpptr;
            return (IntPtr)p;
        }

        //private static Image resizeImage(Image imgToResize, Size size)
        private static Image resizeImage(Image imgToResize, int height)
        {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;

            //float nPercent = 0;
            //float nPercentW = 0;
            //float nPercentH = 0;

            //nPercentW = ((float)size.Width / (float)sourceWidth);
            //nPercentH = ((float)size.Height / (float)sourceHeight);
            float nPercent = ((float)height / (float)sourceHeight);

            //if (nPercentH < nPercentW)
            //    nPercent = nPercentH;
            //else
            //    nPercent = nPercentW;

            int destWidth = (int)(sourceWidth * nPercent);
            int destHeight = (int)(sourceHeight * nPercent);

            Bitmap b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage((Image)b);
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();

            return (Image)b;
        }
*/
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.txtPersonId = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCivilId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdateTitle = new System.Windows.Forms.Button();
            this.txtAttachmentDate = new System.Windows.Forms.TextBox();
            this.txtAttachmentUser = new System.Windows.Forms.TextBox();
            this.listBox = new System.Windows.Forms.ListBox();
            this.labelImageSource = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.txtAttachmentTitle = new System.Windows.Forms.TextBox();
            this.btnScan = new System.Windows.Forms.Button();
            this.btnGet = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnLogon = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtDomain = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelError = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.toolTipUpdateTitle = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipGetAttachmentList = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipScan = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipDelete = new System.Windows.Forms.ToolTip(this.components);
            this.rbDocument = new System.Windows.Forms.RadioButton();
            this.rbSignature = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Person Id";
            // 
            // txtPersonId
            // 
            this.txtPersonId.Location = new System.Drawing.Point(74, 19);
            this.txtPersonId.Name = "txtPersonId";
            this.txtPersonId.Size = new System.Drawing.Size(169, 20);
            this.txtPersonId.TabIndex = 1;
            this.txtPersonId.TextChanged += new System.EventHandler(this.txtPersonId_TextChanged);
            this.txtPersonId.Enter += new System.EventHandler(this.txtPersonId_Enter);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(377, 19);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(115, 20);
            this.txtPassword.TabIndex = 2;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            this.txtPassword.Enter += new System.EventHandler(this.txtPassword_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(318, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password";
            // 
            // txtCivilId
            // 
            this.txtCivilId.Location = new System.Drawing.Point(121, 51);
            this.txtCivilId.MaxLength = 12;
            this.txtCivilId.Name = "txtCivilId";
            this.txtCivilId.Size = new System.Drawing.Size(121, 20);
            this.txtCivilId.TabIndex = 4;
            this.txtCivilId.Text = "12345";
            this.txtCivilId.TextChanged += new System.EventHandler(this.txtCivilId_TextChanged);
            this.txtCivilId.Enter += new System.EventHandler(this.txtCivilId_Enter);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Application Number";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.btnUpdateTitle);
            this.groupBox1.Controls.Add(this.txtAttachmentDate);
            this.groupBox1.Controls.Add(this.txtAttachmentUser);
            this.groupBox1.Controls.Add(this.listBox);
            this.groupBox1.Controls.Add(this.labelImageSource);
            this.groupBox1.Controls.Add(this.linkLabel1);
            this.groupBox1.Controls.Add(this.txtAttachmentTitle);
            this.groupBox1.Controls.Add(this.btnScan);
            this.groupBox1.Controls.Add(this.btnGet);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.txtCivilId);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(15, 60);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox1.Size = new System.Drawing.Size(1192, 623);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImage = global::ImageScanner.Properties.Resources.Clearallrequests_8816;
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDelete.Location = new System.Drawing.Point(137, 83);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(32, 32);
            this.btnDelete.TabIndex = 17;
            this.toolTipDelete.SetToolTip(this.btnDelete, "Delete Attachment");
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdateTitle
            // 
            this.btnUpdateTitle.BackgroundImage = global::ImageScanner.Properties.Resources.Save_6530;
            this.btnUpdateTitle.Location = new System.Drawing.Point(37, 483);
            this.btnUpdateTitle.Name = "btnUpdateTitle";
            this.btnUpdateTitle.Size = new System.Drawing.Size(16, 16);
            this.btnUpdateTitle.TabIndex = 16;
            this.toolTipUpdateTitle.SetToolTip(this.btnUpdateTitle, "Update Title");
            this.btnUpdateTitle.UseVisualStyleBackColor = true;
            this.btnUpdateTitle.Click += new System.EventHandler(this.btnUpdateTitle_Click);
            // 
            // txtAttachmentDate
            // 
            this.txtAttachmentDate.CausesValidation = false;
            this.txtAttachmentDate.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAttachmentDate.Location = new System.Drawing.Point(31, 531);
            this.txtAttachmentDate.Name = "txtAttachmentDate";
            this.txtAttachmentDate.ReadOnly = true;
            this.txtAttachmentDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtAttachmentDate.Size = new System.Drawing.Size(224, 25);
            this.txtAttachmentDate.TabIndex = 15;
            this.txtAttachmentDate.TabStop = false;
            // 
            // txtAttachmentUser
            // 
            this.txtAttachmentUser.CausesValidation = false;
            this.txtAttachmentUser.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAttachmentUser.Location = new System.Drawing.Point(31, 505);
            this.txtAttachmentUser.Name = "txtAttachmentUser";
            this.txtAttachmentUser.ReadOnly = true;
            this.txtAttachmentUser.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtAttachmentUser.Size = new System.Drawing.Size(224, 25);
            this.txtAttachmentUser.TabIndex = 14;
            this.txtAttachmentUser.TabStop = false;
            // 
            // listBox
            // 
            this.listBox.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 17;
            this.listBox.Location = new System.Drawing.Point(31, 133);
            this.listBox.Name = "listBox";
            this.listBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listBox.Size = new System.Drawing.Size(224, 327);
            this.listBox.TabIndex = 13;
            this.listBox.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // labelImageSource
            // 
            this.labelImageSource.AutoSize = true;
            this.labelImageSource.Location = new System.Drawing.Point(148, 594);
            this.labelImageSource.Name = "labelImageSource";
            this.labelImageSource.Size = new System.Drawing.Size(0, 13);
            this.labelImageSource.TabIndex = 12;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(16, 594);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(106, 13);
            this.linkLabel1.TabIndex = 11;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Select Image Source";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // txtAttachmentTitle
            // 
            this.txtAttachmentTitle.CausesValidation = false;
            this.txtAttachmentTitle.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAttachmentTitle.Location = new System.Drawing.Point(59, 479);
            this.txtAttachmentTitle.Name = "txtAttachmentTitle";
            this.txtAttachmentTitle.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtAttachmentTitle.Size = new System.Drawing.Size(196, 25);
            this.txtAttachmentTitle.TabIndex = 10;
            this.txtAttachmentTitle.TabStop = false;
            // 
            // btnScan
            // 
            this.btnScan.BackgroundImage = global::ImageScanner.Properties.Resources.scanner;
            this.btnScan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnScan.Location = new System.Drawing.Point(84, 83);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(32, 32);
            this.btnScan.TabIndex = 6;
            this.toolTipScan.SetToolTip(this.btnScan, "Scan");
            this.btnScan.UseVisualStyleBackColor = true;
            this.btnScan.Click += new System.EventHandler(this.scan_Click);
            // 
            // btnGet
            // 
            this.btnGet.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGet.BackgroundImage = global::ImageScanner.Properties.Resources.paste;
            this.btnGet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnGet.Location = new System.Drawing.Point(31, 83);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(32, 32);
            this.btnGet.TabIndex = 5;
            this.toolTipGetAttachmentList.SetToolTip(this.btnGet, "Get Attachment List");
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.get_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(285, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(886, 564);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnLogon
            // 
            this.btnLogon.Location = new System.Drawing.Point(498, 16);
            this.btnLogon.Name = "btnLogon";
            this.btnLogon.Size = new System.Drawing.Size(75, 23);
            this.btnLogon.TabIndex = 3;
            this.btnLogon.Text = "Log on";
            this.btnLogon.UseVisualStyleBackColor = true;
            this.btnLogon.Click += new System.EventHandler(this.logon_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtDomain);
            this.groupBox2.Controls.Add(this.txtPersonId);
            this.groupBox2.Controls.Add(this.btnLogon);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtPassword);
            this.groupBox2.Location = new System.Drawing.Point(15, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1192, 51);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Authorized Person";
            // 
            // txtDomain
            // 
            this.txtDomain.Enabled = false;
            this.txtDomain.Location = new System.Drawing.Point(249, 19);
            this.txtDomain.Name = "txtDomain";
            this.txtDomain.Size = new System.Drawing.Size(63, 20);
            this.txtDomain.TabIndex = 4;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelError,
            this.toolStripProgressBar1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 698);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1219, 22);
            this.statusStrip1.TabIndex = 10;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabelError
            // 
            this.toolStripStatusLabelError.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabelError.Name = "toolStripStatusLabelError";
            this.toolStripStatusLabelError.Size = new System.Drawing.Size(1102, 17);
            this.toolStripStatusLabelError.Spring = true;
            this.toolStripStatusLabelError.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // toolTipUpdateTitle
            // 
            this.toolTipUpdateTitle.IsBalloon = true;
            // 
            // rbDocument
            // 
            this.rbDocument.AutoSize = true;
            this.rbDocument.Checked = true;
            this.rbDocument.Location = new System.Drawing.Point(3, 9);
            this.rbDocument.Name = "rbDocument";
            this.rbDocument.Size = new System.Drawing.Size(79, 17);
            this.rbDocument.TabIndex = 18;
            this.rbDocument.TabStop = true;
            this.rbDocument.Text = "Documents";
            this.rbDocument.UseVisualStyleBackColor = true;
            this.rbDocument.CheckedChanged += new System.EventHandler(this.rbDocument_CheckedChanged);
            // 
            // rbSignature
            // 
            this.rbSignature.AutoSize = true;
            this.rbSignature.Location = new System.Drawing.Point(105, 9);
            this.rbSignature.Name = "rbSignature";
            this.rbSignature.Size = new System.Drawing.Size(75, 17);
            this.rbSignature.TabIndex = 19;
            this.rbSignature.Text = "Signatures";
            this.rbSignature.UseVisualStyleBackColor = true;
            this.rbSignature.CheckedChanged += new System.EventHandler(this.rbSignature_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rbDocument);
            this.panel1.Controls.Add(this.rbSignature);
            this.panel1.Location = new System.Drawing.Point(32, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(188, 33);
            this.panel1.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1219, 720);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "TWAIN Image Acquisition";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Window_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPersonId;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCivilId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Button btnLogon;
        internal System.Windows.Forms.TextBox txtAttachmentTitle;
        private System.Windows.Forms.GroupBox groupBox2;

        //private bool msgfilter;
        //private Twain tw;
        //IntPtr imgPtr = IntPtr.Zero;
        private LinkLabel linkLabel1;
        private StatusStrip statusStrip1;
        internal ToolStripStatusLabel toolStripStatusLabelError;
        private ToolStripProgressBar toolStripProgressBar1;
        internal Label labelImageSource;
        private TextBox txtDomain;
        private ListBox listBox;
        internal TextBox txtAttachmentDate;
        internal TextBox txtAttachmentUser;
        private Button btnUpdateTitle;
        private ToolTip toolTipUpdateTitle;
        private ToolTip toolTipGetAttachmentList;
        private ToolTip toolTipScan;
        private Button btnDelete;
        private ToolTip toolTipDelete;
        private RadioButton rbSignature;
        private RadioButton rbDocument;
        private Panel panel1;
/*
        [StructLayout(LayoutKind.Sequential, Pack = 2)]
        internal class BITMAPINFOHEADER
        {
            public int biSize;
            public int biWidth;
            public int biHeight;
            public short biPlanes;
            public short biBitCount;
            public int biCompression;
            public int biSizeImage;
            public int biXPelsPerMeter;
            public int biYPelsPerMeter;
            public int biClrUsed;
            public int biClrImportant;
        }
*/
    }
}

