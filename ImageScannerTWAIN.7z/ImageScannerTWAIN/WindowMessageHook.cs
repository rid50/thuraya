﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ImageScanner
{
    public class WindowMessageHook : IMessageFilter
    {
        IntPtr _windowHandle;
        bool _usingFilter;

        public WindowMessageHook(Form window)
        {
            _windowHandle = window.Handle;
        }

        public bool PreFilterMessage(ref Message m)
        {
            //if (FilterMessageCallback != null)
            //{
                //bool handled = false;
                return FilterMessage(ref m);
                //return handled;
            //}

            //return false;
        }

        public IntPtr WindowHandle { get { return _windowHandle; } }

        public bool UseFilter
        {
            get
            {
                return _usingFilter;
            }
            set
            {
                if (!_usingFilter && value == true)
                {
                    Application.AddMessageFilter(this);
                    _usingFilter = true;
                }

                if (_usingFilter && value == false)
                {
                    Application.RemoveMessageFilter(this);
                    _usingFilter = false;
                }
            }
        }

        public FilterMessage FilterMessage { get; set; }        

    }

    public delegate bool FilterMessage(ref Message m);
}
