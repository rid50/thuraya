using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Configuration;
using System.Xml;
using System.Security.Principal;

using System.Reflection;

using ImageScanner.ADServices;

namespace ImageScanner
{
    partial class Form1
    {
        string _domain, _personId, _password;
        bool _authOk = false;
        String _authorizationGroup = "";

        void startAuthProcess(string domain, string personId, string password)
        {
            _domain = domain; _personId = personId; _password = password;
            if (backgroundWorkerAuthentication.IsBusy)
                return;

            backgroundWorkerAuthentication.RunWorkerAsync();
        }

//        void stopAuthProcess()
//        {
//            backgroundWorkerAuthentication.CancelAsync();
//        }

        private void backgroundWorkerAuthentication_DoWork(object sender, DoWorkEventArgs e)
        {
            // This method will run on a thread other than the UI thread.
            // Be sure not to manipulate any Windows Forms controls created
            // on the UI thread from this method.

            _authOk = false;

            String domainLocation = ConfigurationManager.AppSettings["DomainLocation"];
            if (domainLocation.StartsWith(_domain, StringComparison.InvariantCultureIgnoreCase))
                authenticateToLocalDomain();
            else
                authenticateToForeignDomain(domainLocation);
        }


        private void backgroundWorkerAuthentication_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            stopProgressBar();
            if (_authOk)
            {
                txtCivilId.Enabled = true;
                enableButtons(true);

                this.ActiveControl = txtCivilId;
                this.AcceptButton = btnGet;
            }
        }


        private void authenticateToLocalDomain()
        {
/*
                        WindowsIdentity id = WindowsIdentity.GetCurrent();
                        IdentityReferenceCollection irc = identity.Groups;
                        foreach (IdentityReference ir in irc)
                        {
                            String s = ir.Translate(typeof(NTAccount)).Value;
                            int ii = 0;

                        }
 
                        IdentityReferenceCollection coll = windowsIdentity.Groups;
                        IEnumerator it = coll.GetEnumerator();
                        while (it.MoveNext())
                        {
                            String str = ((IdentityReference)it.Current).Translate(typeof(NTAccount)).Value;
                            int ii = 0;
                        }
*/

            WindowsIdentity windowsIdentity = WindowsIdentity.GetCurrent();
            if (!windowsIdentity.User.Translate(typeof(NTAccount)).Value.Equals(_domain + "\\" + _personId, StringComparison.InvariantCultureIgnoreCase))
            {
                if ((windowsIdentity = LogOn(_domain, _personId, _password)) == null)
                    return;
            }

            //AppDomain domain = System.Threading.Thread.GetDomain();
            //domain.SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal);
            //WindowsPrincipal windowsPrincipal = (WindowsPrincipal)System.Threading.Thread.CurrentPrincipal;



            WindowsPrincipal windowsPrincipal = new WindowsPrincipal(windowsIdentity);

            String authorizationGroup = ConfigurationManager.AppSettings["AuthorizationGroup"];
            if (windowsPrincipal.IsInRole(authorizationGroup))
            {
                _authOk = true;
            } 
            else
            {
                // It happened that IsInRole didn't work (MICROSOFT STUPID!!!!!!),
                // probably, because the application ran on DC
                // try this

                String domainName;
                String groupName;

                int i = windowsIdentity.Name.LastIndexOf("\\");
                if (i != -1)
                {
                    domainName = windowsIdentity.Name.Substring(0, i);

                    foreach (IdentityReference group in windowsIdentity.Groups)
                    {
                        try
                        {
                            groupName = group.Translate(typeof(NTAccount)).Value;
                            if (groupName.Equals(domainName + "\\" + authorizationGroup, StringComparison.InvariantCultureIgnoreCase))
                            {
                                _authOk = true;
                                break;
                            }
                        }
                        catch (IdentityNotMappedException) { }
                    }
                }

                if (!_authOk)
                    toolStripStatusLabelError.Text = "You are not authorized to access data.";

                //string[] roles = GetRoles(windowsPrincipal);
            }
        }

        private static string[] GetRoles(WindowsPrincipal principal)
        {
            principal.IsInRole(WindowsBuiltInRole.User);
            FieldInfo field = typeof(WindowsPrincipal).GetField("m_roles", BindingFlags.NonPublic | BindingFlags.Instance);
            return (string[])field.GetValue(principal);
        }

        private void authenticateToForeignDomain(String domainLocation)
        {
            ImageScanner.ADServices.ADServices proxy = new ImageScanner.ADServices.ADServices();
            proxy.PreAuthenticate = true;
            //            proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;


            String nCr = ConfigurationManager.AppSettings["NetworkCredential"];
            String[] networkCredential = nCr.Split(new char[]{','});

            System.Net.CredentialCache cache = new System.Net.CredentialCache();
            System.Net.NetworkCredential cred = new System.Net.NetworkCredential(networkCredential[0].Trim(), networkCredential[1].Trim(), networkCredential[2].Trim());
            cache.Add(new System.Uri(proxy.Url), "Negotiate", cred);
            proxy.Credentials = cache;
            proxy.ConnectionGroupName = networkCredential[0].Trim();

            try
            {
                if (proxy.IsAuthenticated(domainLocation, _personId, _password))
                {
                    String groups = proxy.GetGroups(domainLocation, _personId);
                    //                    String groups = proxy.GetGroups(domainLocation, "ri.davidenko");
                    String[] groupsArray = groups.Split(new char[] { '|' });

                    String authorizationGroup = ConfigurationManager.AppSettings["AuthorizationGroup"];
                    _authorizationGroup = authorizationGroup;

                    foreach (String str in groupsArray)
                    {
                        if (str.Equals(authorizationGroup))
                        {
                            _authOk = true;
                            break;
                        }
                    }
//                    System.Security.AccessControl.AuthorizationRuleCollection auth = (System.Security.AccessControl.AuthorizationRuleCollection)ConfigurationManager.GetSection("authorization");

                    if (!_authOk)
                        toolStripStatusLabelError.Text = "You are not authorized to access data.";
                }
            }
            catch (System.Web.Services.Protocols.SoapException sex)
            {
                String errorCode = null;
                if (sex.Detail != null)
                {
                    XmlNode node = sex.Detail.SelectSingleNode("error");
                    if (node != null)
                        errorCode = node.Attributes["errorCode"].Value;
                }

                uint uerr = 0;
                if (errorCode != null)
                {
                    uerr = (uint)(Convert.ToInt32(errorCode));
                    //if (uerr == 0x8007052e) // Logon failure: unknown user name or bad password
                    //if (uerr == 0x8007200a) // Logon failure: Your account is not active or disabled
                }

                //                txtError.Text = sex.Message;
                //                txtError.Visible = true;

                toolStripStatusLabelError.Text = sex.Message;
                //                toolStripStatusLabelError.Visible = true;
            }
            catch (Exception ex)
            {
                toolStripStatusLabelError.Text = ex.Message;
                //                toolStripStatusLabelError.Visible = true;

                //                txtError.Text = ex.Message;
                //                txtError.Visible = true;
            }
        }
    }
}
